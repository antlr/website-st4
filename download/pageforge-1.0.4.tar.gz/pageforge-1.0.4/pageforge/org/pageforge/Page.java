/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;
import java.net.URLEncoder;

import org.antlr.stringtemplate.StringTemplate;
import org.pageforge.support.*;
import org.pageforge.service.SessionService;

/** The general notion of a Page; must be contained within a state machine.
 */
public abstract class Page {
    public static final String EVENT_NAME_PREFIX = "event.";
    public static final int ITEMS_PER_PAGE = 20;

    /** In which state machine does this page live? */
    protected PageStateMachine state = null;

    /** The overal page template used to generate a page (not the body) */
    protected StringTemplate pageST = null;

    /** A big buffer that we always write the page to before dumping to servlet output */
    protected StreamBuffer pageStreamBuffer = new StreamBuffer(10000);

    protected String pageName;
    protected int pageNumber=1; // pages are from 1 to n
    protected HttpSession session;
    protected HttpServletRequest request;
    protected HttpServletResponse response;
    protected UserInterface user;

    public UserInterface getUser() {
        return user;
    }

    public Page() { }

    public void init(PageStateMachine psm,
					 String pageName,
                     HttpSession session,
                     HttpServletRequest request,
                     HttpServletResponse response)
        throws Exception
    {
        setEnclosingStateMachine(psm);
        this.pageName = pageName;
        this.session = session;
        this.request = request;
        this.response = response;

        user = SessionService.instance().getUser(session,request,response);
    }

    /** Verify that arguments make sense; implemented by subclass typically.
     *  Allows you to do checks once and use in getTitle, mustBeLoggedIn etc...
     *  This is ONLY called when generating a page not when processing events.
     */
    public void verify() throws VerifyException {
    }

    /** Handle predefined arguments like page and so on.  Do not handle opkey
     *  here because it's really a state machine argument.
     */
    public void handleDefaultArgs() {
        if ( request.getParameter("page")!=null ) {
            pageNumber = getIntParameter("page");
            if ( pageNumber<=0 ) {
                pageNumber = 1;
            }
        }
    }

    /** Event processing.  If user has event.name set than we call processEvent()
     *  not generate().
     */
    public void processEvent(String eventName) throws Exception {
    }

    /** Main service method for generating page */
    public void generate(PrintWriter pageOut) {
        String event = null;
        try {
            if ( mustBeLoggedIn() && user==null ) {
                throw new MustLoginException("You must be logged in to access page: '"+
                                             getTitle()+"'",
                                             getRequestURLAllParameters()
                                             );
            }

            // execute its service method to generate output
            // or process an event and execute a state transition.
            event = getEventName(request);
            if ( event==null ) {
                // GENERATE PAGE
                handleDefaultArgs();

                verify(); // check args before generation

                if ( !hasViewPermission() ) {
                    throw new VerifyException("You do not have permission to see this page.");
                }

                setCacheControl(response);  // BROWSER CACHING

                // Make a buffer big enough for the whole output page (reuse buffer)
                StreamBuffer out = getNewStreamBuffer();

                // write page to stream buffer
                generatePage(out);

                // write stream buffer to servlet output
                pageOut.print(out.toString());
            }
            else {
                // PROCESS EVENT
                System.out.println("process event "+event);
                processEvent(event);
            }
        }
        catch (MustLoginException mle) {
            try {
                doMustLoginRedirect(mle.getMessage(), mle.getReturnURL());
            }
            catch (IOException io) {
                PageDispatcher.getApplication()
                    .pageGenerationError("cannot redirect to must login page",
                                         request.getRequestURL().toString(),
                                         mle);
            }
        }
        catch (VerifyException ve) {
            try {
                doErrorRedirect(ve.getMessage());
            }
            catch (IOException io) {
                PageDispatcher.getApplication()
                    .pageGenerationError("cannot redirect to error page for msg ",
                                         request.getRequestURL().toString(),
                                         ve);
            }
        }
        catch (Exception e) {
            try {
                String eventName = "";
                if ( event!=null ) {
                    eventName = " event="+event;
                }
                PageDispatcher.getApplication().pageGenerationError("Got page exception "+event,
                                                               request.getRequestURL().toString(),
                                                               e);
                doErrorRedirect("problem generating page "+request.getRequestURL());
            }
            catch (IOException io) {
                PageDispatcher.getApplication().pageGenerationError("cannot redirect to error page",
                                                               request.getRequestURL().toString(),
                                                               e);
            }
        }
    }

    /** Generate the overall page; set gutters, etc... here.  This
     *  then calls generateBody(out) to get the body filled in or uses
     *  a string template you return from getBodyStringTemplate.  So, you
     *  can either generate a page directly by writing to out or you can
     *  fill in a string template.
     */
    public void generatePage(StreamBuffer out) throws Exception {
        pageST = getPageStringTemplate();
        if ( pageST!=null ) {
            setDefaultPageAttributes(pageST);

            // set the body string template or write directly to out
            StringTemplate bodyST = getBodyStringTemplate();
            if ( bodyST!=null ) {
                pageST.setAttribute("body", bodyST);
                generateBody(bodyST);
            }
            else {
                // make the body write into a temporary buffer
                StreamBuffer bodyOut = new StreamBuffer(3000);
                generateBody(bodyOut);
                pageST.setAttribute("body", bodyOut);
            }
            // we now have a full page template to dump
            out.print(pageST.toString());
        }
        else {
            StringTemplate bodyST = getBodyStringTemplate();
            // set the body string template or write directly to out
            if ( bodyST!=null ) {
                setDefaultPageAttributes(pageST);
                generateBody(bodyST);
                out.print(bodyST.toString());
            }
            else {
                // make the body write into a temporary buffer
                StreamBuffer bodyOut = new StreamBuffer(3000);
                generateBody(bodyOut);
                out.print(bodyOut.toString());
            }
        }
    }

    /** Override this in your subclass to write directly to the body stream buffer */
    public void generateBody(StreamBuffer out) throws Exception {
    }

    /** Override this in your subclass to set attributes of the body template */
    public void generateBody(StringTemplate bodyST) throws Exception {
    }

    /** Override in your subclass */
    public String getTitle() { return "no title!"; }

    /** The user must be logged in to see this page? */
    public boolean mustBeLoggedIn() {
        return false;
    }

    /** More restrictive than mustBeLoggedIn() and called after verify() so
     *  you have access to verified instance variables.  Set this to false
     *  if, for example, I try to look at somebody else's private email
     *  info.
     */
    public boolean hasViewPermission() {
        return true;
    }

    /** Should the browser be able to cache the page? */
    public boolean noBrowserCaching() {
        return true;
    }

    // MISC

    /** Check that all parameters in the array have values. */
    protected void requireParameters(String[] parameters) throws VerifyException {
        StringBuffer b = new StringBuffer(100);
        int n = 0;
        for (int i=0; i<parameters.length; i++) {
            if ( request.getParameter(parameters[i])==null ||
                 request.getParameter(parameters[i]).length()==0 ) {
                n++;
                b.append(parameters[i]);
                b.append(" ");
            }
        }
        if ( n>0 ) {
            throw new VerifyException("Missing required parameter(s): "+b.toString());
        }
    }

    /** Check that the parameter has a value. */
    protected void requireParameter(String parameter) throws VerifyException {
        if ( request.getParameter(parameter)==null ||
             request.getParameter(parameter).length()==0 )
        {
            throw new VerifyException("Missing required parameter: "+parameter);
        }
    }

    /** Any name that begins with Event. or whatever the const says, is an
     *  event.  "Event.<name>..." yields name.  If a link is used, event=name
     *  will be found.
     */
    protected String getEventName(HttpServletRequest request) {
        if ( request.getParameter("event")!=null ) {
            return request.getParameter("event");
        }
        Enumeration names = request.getParameterNames();
        while (names.hasMoreElements()) {
            String name = (String)names.nextElement();
            if ( name.toLowerCase().startsWith(EVENT_NAME_PREFIX) ) {
                name = name.substring(EVENT_NAME_PREFIX.length(), name.length());
                if ( name.endsWith(".x") || name.endsWith(".y") ) {
                    name = name.substring(0,name.length()-2);
                }
                return name;
            }
        }
        return null;
    }

    /** Override this method to set default template attributes like font tag
     *  etc...  Also, do stuff like pageST.setAttribute("title", getTitle());
     *  A good idea to call super.setDefaultPageAttributes(pageST) or you'll
     *  miss the predefined attributes like "newOpKey".
     *
     *  Currently this method defines:
     *
     *      opKey    -- op key associated with currently running machine/page
     *      newOpKey -- op key you can use in links that start new operations
     *                  emanating from this page.
     */
    public void setDefaultPageAttributes(StringTemplate pageST) {
        long newOpKey = PageStateMachine.getNewOpKey(); // use new op key each page
        pageST.setAttribute("newOpKey", new Long(newOpKey));
        pageST.setAttribute("opKey", new Long(getOpKey()));
    }

    public void setEnclosingStateMachine(PageStateMachine psm) {
        state = psm;
    }

    public void setCacheControl(HttpServletResponse response) {
        if ( noBrowserCaching() ) {
            response.setHeader("Cache-Control","no-cache"); //HTTP 1.1
            response.setHeader("Pragma","no-cache"); //HTTP 1.0
        }
    }

    /** Return the page template instance used to generate this page.  In
     *  generateBody you will set attributes
     */
    public StringTemplate getPageStringTemplate() {
        if ( pageST==null ) {
            pageST = PageDispatcher.getApplication().getStringTemplatesLib(request)
                .getInstanceOf("page");
        }
        return pageST;
    }

    protected StreamBuffer getNewStreamBuffer() {
        pageStreamBuffer.reset();
        return pageStreamBuffer;
    }

    public String getName() {
        return pageName;
    }

    /** All pages in a submachine can specify a page template to use by default. */
    public StringTemplate getBodyStringTemplate() {
        String stName = state.getNodeTemplateName(getName());
        if ( stName!=null ) {
            return PageDispatcher.getApplication().getStringTemplatesLib(request)
                .getInstanceOf(stName);
        }
        return null;
    }

    /** For a given max number of entries and this.pageNumber,
     *  compute links for "1 2 3 4 ... n/ITEMS_PER_PAGE".  Pass in a
     *  data aggregrate that answers url and title for the template.
     *  This page's full URL with all parameters is used as the link
     *  "template".
     */
    public Vector getPageLinks(int n) {
        int numPages = (int)Math.ceil(((double)n) / ITEMS_PER_PAGE);
        if ( numPages==1 ) {
            return null;
        }
        Vector pagelinks = new Vector(numPages);
        String thisPage = getRequestURLAllParameters();
        for (int p=1; p<=numPages; p++) {
            String url = Utils.replaceURLParameter(thisPage, "page", String.valueOf(p));
            if ( p==pageNumber ) {
                url = null; // don't link to current page
            }
            String title = String.valueOf(p);
            Object link = new Link(url,title);
            pagelinks.addElement(link);
        }
        return pagelinks;
    }

    /** As a response, tell browser to redirect to url */
    public void redirect(String url) throws IOException {
        response.sendRedirect(url);
    }

    public void doRedirect(String url) throws IOException {
        response.sendRedirect(url);
    }

    public void doMessageRedirect(String msg) throws IOException {
        String url = PageDispatcher.getApplication().getMessageURL(request)+"?msg="+
                        URLEncoder.encode(msg);
        response.sendRedirect(url);
    }

    public void doMustLoginRedirect(String msg, String returnURL) throws IOException {
        String url = PageDispatcher.getApplication().getMustLoginURL(request)+"?msg="+
                        URLEncoder.encode(msg)+"&redirect="+
                        URLEncoder.encode(returnURL);
        response.sendRedirect(url);
    }

    public void doErrorRedirect(String msg) throws IOException {
        String url = PageDispatcher.getApplication().getErrorURL(request)+"?msg="+
                        URLEncoder.encode(msg);
        response.sendRedirect(url);
    }

    public String getNodeURL(String node) {
        return getNodeURL(state.getName(), node);
    }

    public String getNodeURL(String fsm, String node) {
        return "/"+fsm+"/"+node;
    }

    /** Get the op key for the machine associated with this page */
    public long getOpKey() {
        return state.getOpKey();
    }

    /** Kill the machine associated with this page */
    public void destroyStateMachine() {
        state.destroyStateMachine(session);
    }

    // PARAMETER STUFF

    protected int getIntParameter(String name) {
        String nameStr = request.getParameter(name);
        int v = 0;
        if ( nameStr!=null ) {
            v = Integer.parseInt(nameStr);
        }
        return v;
    }

    protected long getLongParameter(String name) {
        String nameStr = request.getParameter(name);
        long v = 0;
        if ( nameStr!=null ) {
            v = Long.parseLong(nameStr);
        }
        return v;
    }

    protected Vector getIntArrayParameter(String name) {
        String[] values = request.getParameterValues(name);
        if ( values==null ) {
            return null;
        }
        Vector v = new Vector(values.length);
        for (int i=0; i<values.length; i++) {
            v.addElement(Integer.valueOf(values[i]));
        }
        return v;
    }

    // U T I L I T I E S

    /** Return a URL with just the GET parameters */
    public String getRequestURLQuery() {
        String q = request.getQueryString();
        if ( q!=null ) {
            return request.getRequestURI()+"?"+q;
        }
        return request.getRequestURI();
    }

    /** Return a URI (no GET parameters) */
    public String getRequestURI() {
        return request.getRequestURI();
    }

    /** Return a URL with all GET and POST parameters */
    public String getRequestURLAllParameters() {
        return Utils.getRequestURLAllParameters(request,null);
    }

}

