/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge;

import org.pageforge.support.UserInterface;
import org.antlr.stringtemplate.StringTemplateGroup;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import java.io.IOException;

/** How the pageforge communicates with your application */
public interface PageForgeApplication {

    /** Initialize your application.  Call exactly once upon first
     *  URL request to the servlet engine.
     */
    public void initialize();

    /** Do your PageStateMachine.mapMachine() calls to identify the state
     *  machines to support.
     */
    public void setMachineToClassMap();

    /** Return true when you want visitors to visit a meditation ("busy")
     *  page.  Used mainly during long initialization where you want the
     *  user to know the site is up, but currently unavailable.  Make sure
     *  you set the meditation URL below and that after initialization is
     *  complete, this method returns true!
     */
    public boolean openForBusiness();

    /** For testing your server, you do not want emails and such to go out. */
    public boolean isLiveSite(HttpServletRequest request);

    /** How to respond to a 404 error */
    public void error404(ServletContext servletContext,
                         HttpServletRequest request,
                         HttpServletResponse response)
        throws IOException, ServletException;


    /** Called when something horribly wrong has happened such as when
     *  no config files can be found.
     */
    public void panic(String msg);

    /** Called by PageDispatcher whenever there is a problem in the dispatcher */
    public void pageDispatchError(String msg, Exception e);

    /** Called upon each request to the page dispatcher, but called after
     *  any forwarding you specify.
     */
    public void pageDispatchLog(String machineName,
                                String pageName,
                                HttpSession session,
                                HttpServletRequest request,
                                HttpServletResponse response);

    /** Called by Page.generate() when an exception is thrown during generation.
     *  This is NOT called upon VerifyException (args invalid for page).
     *  This is called right before Page.doErrorRedirect() is called.
     */
    public void pageGenerationError(String msg, String pageURL, Exception e);

    /** What is the root directory of your string template library? */
    public StringTemplateGroup getStringTemplatesLib(HttpServletRequest request);

    public String getErrorURL(HttpServletRequest request);

    public String getMessageURL(HttpServletRequest request);

    public String getMeditationURL(HttpServletRequest request);

    public String getMustLoginURL(HttpServletRequest request);

    public String getHomePageURL(HttpServletRequest request);

    /** Return where in the file system you store files to be served.  You
     *  should set your web server to pass all file references to PageDispatcher
     *  except for obvious stuff like "/images/*".  Anything that is not
     *  a valid /machine/state reference is looked up under this root dir.
     */
    public String getDocumentRoot(HttpServletRequest request);

    /** To manage logins etc..., page machine must be able to get a
     *  user by email and by unique hash for (autologin).
     */
    UserInterface getUserByLogin(HttpServletRequest request, String email);

    UserInterface getUserByUniqueHash(HttpServletRequest request, String hash);
}
