/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge;

import java.io.*;
import java.util.*;
import java.net.URL;
import java.net.URLConnection;
import javax.servlet.*;
import javax.servlet.http.*;

/** Map URLs to Page objects.  This is the only dependency your app will
 *  have on the servlet engine.
 *
 *  PAGE MACHINE INTEGRATION INTO SERVLET ENGINE
 *
 *  To hook this into your web server, you just inform the server
 *  to pass all page requests except images and perhaps an error
 *  page to a subclass of this servlet.  In Resin, you do this:
 *
    <servlet-mapping url-pattern='/images/*' servlet-name='com.caucho.server.http.FileServlet'/>
    <servlet-mapping url-pattern='/favicon.ico' servlet-name='com.caucho.server.http.FileServlet'/>

    <servlet-mapping url-pattern='/' servlet-name='MyAppPageDispatcher'/>

    <servlet-mapping url-pattern='/error.jsp'
                     servlet-name='com.caucho.jsp.JspServlet'/>

 *  Where the error.jsp file is used to avoid error loops where an error page
 *  caused an error redirecting to itself infinitely.
 *
 *  PAGE MACHINE INITIALIZATION
 *
 *  Because there is only one servlet in the system, PageDispatcher's
 *  init() method serves as the system wide initialization trigger.
 *  The page machine knows how to initialize your system because you
 *  have implemented createPageForgeApplication().  PageDispatcher sends
 *  the init signal to that application.
 *
 *  Once your application has been initialized, the PageStateMachine is
 *  initialized, which typically just asks your application to set up
 *  the machine name to class map.
 */
public abstract class PageDispatcher extends HttpServlet {
    private static boolean initialized = false;

    protected static PageForgeApplication application = null;

    /** You must subclass PageDispatcher making createPageForgeApplication()
     *  so that we know who to contact to send init signal to.  When building a
     *  server, there is no "main" method that starts up your user code.  The
     *  first page request to the web server forces the load and initialization
     *  of the PageDispatch servlet.  This servlet's init() method is used
     *  to trigger the initialization of user code.  This servlet knows what
     *  user code to init when you tell it via this method.
     *
     *  Technically, this should be a static method (there is only one
     *  application and it is shared with all support), but there is no
     *  way to enforce the rule that you must subclass and implement
     *  a static method.
     *
     *  This method is called exactly once.
     */
    public abstract PageForgeApplication createPageForgeApplication();

    public static PageForgeApplication getApplication() {
        return application;
    }

    public void init()
            throws ServletException
    {
        // guarded test-n-set operation to initialize exactly once.
        // But, servlet engine should only call this once anyway
        synchronized (this) {
            if ( !initialized ) {
                application = createPageForgeApplication();
                getApplication().initialize();
                PageStateMachine.initialize();
                initialized = true;
            }
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        rawDo(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        rawDo(request, response);
    }

    /** Processing of a GET.  Check if open for business; if not, route
     *  to meditation.  If open, check for rewrites.  If no rewrites, go ahead
     *  and service the URI as a /machine/page or regular file.
     */
    public void rawDo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        if ( getApplication()==null ) {
            // do nothing until we have an application to use
            // if load of application class from property failed, rawDo
            // is never executed.
            return;
        }

        // If in init process, jump to meditation; don't touch app code
        if ( !getApplication().openForBusiness() ) {
            redirect(getApplication().getMeditationURL(request), response);
            return;
        }

        boolean redirected = rewrite(request, response);
        if ( redirected ) {
            return; // return since sent somewhere else
        }

        serviceURI(request, response);
    }

    /** Do URL rewrites.  Override this in your dispatcher.  You
     *  can do either a forward or a redirect.  Forward is used
     *  for things like hiding the true location of files; you use
     *  an incoming URL as an ID not the actual file location.
     *
     *  For legacy URLs, you would use a redirect.  That way, users
     *  and spiders can see that you want them to go to a different URL.
     *
     *  Examples:
     *
     *       // Rewrite /grammar/java/java.g to /data/grammar/java/java.g
     *       String uri = request.getRequestURI();
     *       if ( uri.startsWith("/grammar/java/") ) {
     *           forward("/data/"+uri, request, response);
     *           return true;
     *       }
     *
     *       // legacy url; "/image" -> "/img"
     *       if ( uri.startsWith("/image/") ) {
     *           String filename = uri.substring("/image/".length(), uri.length());
     *           redirect("/img/"+filename, response);
     *           return true;
     *       }
     *
     *  Ensure that if you want to redirect all html files, for example,
     *  that you set your web server config to have those files served by
     *  this dispatcher not the normal file servlet.
     */
    protected boolean rewrite(HttpServletRequest request,
                              HttpServletResponse response)
        throws ServletException, IOException
    {
        return false;
    }

    /** Forward to a particular page without changing url in browser. */
    protected void forward(String url,
                           HttpServletRequest request,
                           HttpServletResponse response)
        throws ServletException, IOException
    {
        ServletContext ctx = this.getServletContext();
        RequestDispatcher rd = ctx.getRequestDispatcher(url);
        rd.forward(request, response);
    }

    /** Do a redirect when you need to change page directories so that
     *  relative file names on that target page will work.  This changes
     *  the url in the browser.
     */
    protected void redirect(String url, HttpServletResponse response)
        throws IOException
    {
        response.sendRedirect(url);
    }

    private void serviceURI(HttpServletRequest request,
                            HttpServletResponse response)
            throws ServletException, IOException
    {
        String uri = request.getRequestURI();
        String machineName = "";
        String pageName = "";
        if ( uri!=null && uri.trim().equals("/") ) {
            uri = getApplication().getHomePageURL(request);
        }
        // break apart /machine/page?args into components
        StringTokenizer st = new StringTokenizer(uri, "/?");
        if ( st.hasMoreTokens() ) {
            machineName = st.nextToken();
        }
        if ( st.hasMoreTokens() ) {
            pageName = st.nextToken();
        }
        Class machineClass = null;
        if ( machineName!=null ) {
            machineClass = PageStateMachine.getMachineClass(machineName);
        }
        if ( machineClass!=null && pageName!=null ) {
            try {
                response.setContentType("text/html");
                serviceMachinePage(machineName,
                                   pageName,
                                   request.getSession(),
                                   request,
                                   response);
            }
            catch (Exception e) {
                getApplication().pageDispatchError("Problems launching page: "+machineName+"."+pageName, e);
            }
            return;
        }

        // must be regular file
        if ( fileGET(request, response) ) {
            return;
        }

        // hmmm...no such machine page nor regular file
        getApplication().error404(getServletContext(), request, response);
    }

	/** Dump a file */
	public boolean fileGET(HttpServletRequest request,
						   HttpServletResponse response)
	{
		String uri = request.getRequestURI();

        String contentType = getServletContext().getMimeType(uri);
        if ( contentType!=null ) {
            response.setContentType(contentType);
        }

        String resourceRoot = getApplication().getDocumentRoot(request);
        String completeFilename = resourceRoot+uri;

        File f = new File(completeFilename);
        System.out.println("fileGET("+completeFilename+")");
        if ( !f.exists() ) {
            System.out.println(completeFilename+" does not exist");
            return false;
        }

        response.setContentLength((int)f.length());
		// set last modified header, rounded to second
        response.setDateHeader("Last-Modified", f.lastModified() / 1000 * 1000);
        DataInputStream dis = null;
        try {
            byte[] buf = new byte[4096];
            FileInputStream fr = new FileInputStream(completeFilename);
            BufferedInputStream bis = new BufferedInputStream(fr);
            dis = new DataInputStream(bis);
            OutputStream o = response.getOutputStream();
            int n = dis.read(buf);
            while ( n>0 ) {
                o.write(buf,0,n);
                n = dis.read(buf);
            }
            dis.close();
            fr=null; bis=null; dis=null;
        }
        catch (IOException ioe) {
            getApplication().pageDispatchError("Can't GET file "+uri, ioe);
        }
        finally {
            // ensure everything is closed
            if ( dis!=null ) {
                try {
                    dis.close();
                    dis = null;
                }
                catch (IOException ioe2) {
                    getApplication().pageDispatchError("Can't close file "+uri, ioe2);
                }
            }
        }
        return true;
    }

	/** Given a full URL target, go get the data and spit to output.
	 *  This is a utility method that you can use in your subclass
	 *  dispatcher.  For example, to tunnel all /icons/foo.gif requests
	 *  to another site, put something in rewrite() that does:
	 * 		if ( uri.startsWith("/icons/") )
	 *        tunnelGET("http://foo.com"+uri,response);
	 *      }
	 */
	public void tunnelGET(String target, HttpServletResponse response) {
		InputStream is = null;
		try {
			URL url = new URL(target);
			URLConnection con = url.openConnection();
			is = con.getInputStream();
			pipe(target, is, response);
			is.close();
			is=null;
		}
		catch (Exception e) {
			getApplication().pageDispatchError("Can't GET file "+target, e);
		}
		finally {
			if ( is!=null ) {
				try {
					is.close();
				}
				catch (IOException ioe2) {
					getApplication().pageDispatchError("Can't close "+target, ioe2);
				}
			}
		}
	}

	public void pipe(String targetName, InputStream is, HttpServletResponse response) {
		byte[] buf = new byte[4096];
		DataInputStream dis = null;
		try {
			BufferedInputStream bis = new BufferedInputStream(is);
			dis = new DataInputStream(bis);
			OutputStream o = response.getOutputStream();
			int n = dis.read(buf);
			while ( n>0 ) {
				o.write(buf,0,n);
				n = dis.read(buf);
			}
			dis.close();
			dis=null;
		}
		catch (IOException ioe) {
			getApplication().pageDispatchError("Can't GET "+targetName, ioe);
		}
		finally {
			// ensure everything is closed
			if ( dis!=null ) {
				try {
					dis.close();
					dis = null;
				}
				catch (IOException ioe2) {
					getApplication().pageDispatchError("Can't close "+targetName, ioe2);
				}
			}
		}
	}

	private void serviceMachinePage(String machineName,
									String pageName,
									HttpSession session,
									HttpServletRequest request,
									HttpServletResponse response)
		throws Exception
	{
		getApplication().pageDispatchLog(machineName,
                                         pageName,
                                         session,
                                         request,
                                         response);

        // pages themselves are never persistent; each page is new instance
        Class c = PageStateMachine.getPageClass(machineName, pageName);
        if ( c==null ) {
            getApplication().error404(getServletContext(), request, response);
            return;
        }

        // Are they requesting a particular state machine by opKey?
        long opKey = getRequestedOpKey(request);

        // Persistent machine and previous instance?
        PageStateMachine psm =
            PageStateMachine.restoreStateMachine(session, machineName, opKey);
        if ( psm!=null ) {
            // found previous machine associated with opkey
            System.out.println("Restoring machine "+psm.getName()+" op="+psm.getOpKey());
        }
        else {
            // Either not persistent or no previous instance of this machine
            Class mc = PageStateMachine.getMachineClass(machineName);
            if ( c!=null && mc!=null ) {
                // create machine (associated with requested opKey)
                psm = (PageStateMachine)mc.newInstance();
                psm.setName(machineName);
                psm.setOpKey(opKey);

                if ( psm.persistent() ) {
                    System.out.println("Saving machine "+machineName+" op="+opKey);
                    PageStateMachine.saveStateMachine(session, psm);
                }
            }
            else {
                getApplication().error404(getServletContext(), request, response);
                return;
            }
        }
        Page page = (Page)c.newInstance();
        page.init(psm, pageName, session, request, response);
        page.generate(response.getWriter());
    }

    private long getRequestedOpKey(HttpServletRequest request) {
        long opKey = PageStateMachine.DEFAULT_OPKEY;
        String opKeyStr = request.getParameter("opkey");
        if ( opKeyStr!=null ) {
            if ( opKeyStr!=null ) {
                opKey = Long.parseLong(opKeyStr);
            }
        }
        return opKey;
    }

    public void destroy() {
        // nothing to do
    }

}

