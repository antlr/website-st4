/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.support;

import org.pageforge.lib.html.HTMLUtils;

import java.io.*;

public class FileUtils {

    /** Given an html file name, open it and return the body and title.
     *  The title is returned via a "return arg".
     */
    public static String getHTMLFileBodyAndTitle(String filename,
                                                 StringBuffer title)
        throws Exception
    {
        StringBuffer contents = FileUtils.getFileContents(filename);
		if ( contents==null ) {
			return null;
		}
        String body = HTMLUtils.getHTMLBody(contents.toString(), title);
        return body;
    }

    /** Return the contents of a text file as a big string;  The newlines
     *  in the file are stripped and converted to the local system's
     *  "line.separator" property.
     */
    public static StringBuffer getFileContents(String filename)
        throws IOException
    {
        if ( filename==null ) {
            return null;
        }
        File f = new File(filename);
        if ( !f.exists() ) {
            return null;
        }
        long size = f.length();
        StringBuffer buf = new StringBuffer((int)size);
        FileReader fr = new FileReader(filename);
        BufferedReader br = new BufferedReader(fr);
        String line = br.readLine();
        String newline = System.getProperty("line.separator");
        while ( line!=null ) {
            buf.append(line);
            buf.append(newline);
            line = br.readLine();
        }
        br.close();
        fr.close();

        return buf;
    }

    /** Return the contents of a text file in an array of strings; approx the
     *  size for efficiency of memory alloc.  There are no newline characters
     *  on the end of the lines.
     */
    public static String[] getFileContentsAsLines(String filename)
        throws IOException
    {
        StringBuffer contents = getFileContents(filename);
        if ( contents==null ) {
            return null;
        }
        return Utils.splitIntoLines(contents);
    }

    /** Write the contents of a string to a text file. */
    public static void putFileContents(String filename, String contents)
        throws IOException
    {
        FileWriter fw = new FileWriter(filename);
        fw.write(contents);
        fw.close();
    }

    /** Copy all files in srcDir to dstDir; expects srcDir to exist.
     */
    public static void copyDir(String srcDir,
                               String dstDir,
                               boolean recursive)
            throws IOException
    {
        // System.out.println("Copy dir "+srcDir+" to "+dstDir);
        File a = new File(srcDir);
        File b = new File(dstDir);
		if ( !b.exists() ) {
			b.mkdirs();
		}
        if ( !a.exists() || !b.exists() ||
             !a.isDirectory() || !b.isDirectory() )
        {
            return;
        }
        String[] files = a.list();
        for (int i=0; files!=null && i<files.length; i++) {
            File af = new File(a+"/"+files[i]);
            if ( af.isDirectory() && recursive ) {  // copy subdir?
                // make sure subdirectory exists in destination area
                File bf = new File(b+"/"+files[i]);
                bf.mkdir();
                // copy this subdirectory now too
                copyDir(af.toString(), bf.toString(), true);
            }
            else if ( !af.isDirectory() ) {
                // plain ol' file
                // System.out.println("copyDir: copying file "+srcDir+"/"+files[i]+"->"+dstDir+"/"+files[i]);
                copyFile(srcDir+"/"+files[i], dstDir+"/"+files[i]);
            }
        }
    }

    /** This example is from the book _Java in a Nutshell_ by David Flanagan.
        Written by David Flanagan.  Copyright (c) 1996 O'Reilly & Associates.
        You may study, use, modify, and distribute this example for any purpose.
        This example is provided WITHOUT WARRANTY either expressed or implied.
     */
    public static void copyFile(String source_name, String dest_name)
            throws IOException
    {
        // System.out.println("copyFile "+source_name+" to "+dest_name);
        File source_file = new File(source_name);
        File destination_file = new File(dest_name);
        FileReader source = null;
        FileWriter destination = null;
        char[] buffer;
        int bytes_read;

        try {
            // First make sure the specified source file
            // exists, is a file, and is readable.
            if (!source_file.exists() || !source_file.isFile()) {
                throw new IOException("FileCopy: no such source file or file is a dir: " +
                        source_name);
            }
            if (!source_file.canRead()) {
                throw new IOException("FileCopy: source file " +
                        "is unreadable: " + source_name);
            }

            // If the destination exists, make sure it is a writeable file
            // and ask before overwriting it.  If the destination doesn't
            // exist, make sure the directory exists and is writeable.
            if (destination_file.exists()) {
                if (destination_file.isFile()) {
                    //DataInputStream in = new DataInputStream(System.in);
                    // String response;

                    if (!destination_file.canWrite())
                        throw new IOException("FileCopy: destination " +
                                "file is unwriteable: " + dest_name);
                    /*
                    System.out.print("File " + dest_name +
                    " already exists.  Overwrite? (Y/N): ");
                    System.out.flush();
                    response = in.readLine();
                    if (!response.equals("Y") && !response.equals("y"))
                    throw new FileCopyException("FileCopy: copy cancelled.");
                    */
                }
                else {
                    throw new IOException("FileCopy: destination "
                            + "is not a file: " +  dest_name);
                }
            }
            else {
                File parentdir = destination_file.getParentFile();
                if (!parentdir.exists())
                    throw new IOException("FileCopy: destination "
                            + "directory doesn't exist: " + dest_name);
                if (!parentdir.canWrite())
                    throw new IOException("FileCopy: destination "
                            + "directory is unwriteable: " + dest_name);
            }

            // If we've gotten this far, then everything is okay; we can
            // copy the file.
            source = new FileReader(source_file);
            destination = new FileWriter(destination_file);
            buffer = new char[1024];
            while(true) {
                bytes_read = source.read(buffer,0,1024);
                if (bytes_read == -1) break;
                destination.write(buffer, 0, bytes_read);
            }
        }
        // No matter what happens, always close any streams we've opened.
        finally {
            if (source != null)
                try { source.close(); } catch (IOException e) { ; }
            if (destination != null)
                try { destination.close(); } catch (IOException e) { ; }
        }
    }

}

