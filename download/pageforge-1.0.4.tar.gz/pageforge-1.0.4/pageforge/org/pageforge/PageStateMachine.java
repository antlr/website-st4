/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge;

import javax.servlet.http.HttpSession;
import java.util.*;

public abstract class PageStateMachine {
    public static final String VERSION = "1.0.4";
    public static final String BUILD = "2004-03-23";
    
    public static final int DEFAULT_OPKEY = 1;

    // STATIC DATA (USED FOR ALL MACHINES)
    public static final String EVENT_NAME_PREFIX = "event.";

    /** Maps machine.state to its page class */
    static protected Hashtable stateToPageClassMap = new Hashtable();

    /** Maps machine to it's class */
    static protected Hashtable machineToClassMap = new Hashtable();

    /** An optional StringTemplate may be specified for each node that
     *  is created automatically and made available in the StateMachinePage.
     *
     *  Maps machine.state to its template.
     */
    static protected Hashtable stateToTemplateMap = new Hashtable();

    /** Which operation does this machine belong to?  Each user might open
     *  multiple browsers for a website and do multiple edit operations,
     *  for example.  Must have a way to indicate which window.  A new
     *  operation should start with a new op key.
     */
    protected long opKey = DEFAULT_OPKEY;

    /** Global op key counter used to provide unique op keys to everyone. */
    protected static long opKeyCounter = 1;

    public long getOpKey() {
        return opKey;
    }

    public void setOpKey(long opKey) {
        this.opKey = opKey;
    }

    /** Compute a new operation key and return it; for now it just provides
     *  a stream of sequential integers.  Consequently, all sessions share
     *  the same sequence.
     */
    public static synchronized long getNewOpKey() {
        return opKeyCounter++;
    }

    public static void mapMachine(String machineName, Class machineClass) {
        machineToClassMap.put(machineName, machineClass);
    }

    public static void mapState(String machineName, String pageName, Class nodeClass) {
        stateToPageClassMap.put(machineName+"."+pageName, nodeClass);
    }

    public static void mapState(String machineName,
                                String pageName,
                                Class nodeClass,
                                String template,
                                boolean startState,
                                boolean stopState)
    {
        mapState(machineName, pageName, nodeClass);
        stateToTemplateMap.put(machineName+"."+pageName, template);
    }

    public static void mapState(String machineName, String pageName, Class nodeClass, String template) {
        mapState(machineName, pageName, nodeClass, template, true, false);
    }

    public static Class getPageClass(String machineName, String pageName) {
        System.out.println(machineName+"."+pageName+" maps to page "+
                stateToPageClassMap.get(machineName+"."+pageName));
        return (Class)stateToPageClassMap.get(machineName+"."+pageName);
    }

    public static Class getMachineClass(String machineName) {
        System.out.println(machineName+" maps to machine "+machineToClassMap.get(machineName));
        return (Class)machineToClassMap.get(machineName);
    }

    public static void initialize() {
        PageDispatcher.getApplication().setMachineToClassMap();
    }

    // INSTANCE DATA & METHODS

    public String name = null; // set by machine entry page

    public PageStateMachine() { }

    public PageStateMachine(String machineName) {
        setName(machineName);
    }

    public String getName() { return name; }

    public void setName(String name) {
        this.name = name;
    }

    /** true=>this machine is persistent: each page view within this machine
     *  viewed by a single user session share a single copy of this
     *  machine.  That implies that the instance variables can be used
     *  by all pages within as you cycle between edit->verify->submit
     *  nodes etc...
     */
    public boolean persistent() { return false; }

    /** Get a state machine associated with this session, name, and op key. */
    public static PageStateMachine restoreStateMachine(HttpSession session,
                                                       String machineName,
                                                       long op)
    {
        Map sessionStateMachines = (Map)session.getAttribute("machines");
        if ( sessionStateMachines==null ) {
            return null;
        }
        return (PageStateMachine)sessionStateMachines.get(machineName+"_"+op);
    }

    /** Save a state machine associated with a session, name, and op key. */
    public static void saveStateMachine(HttpSession session,
                                        PageStateMachine machine)
    {
        Map sessionStateMachines = (Map)session.getAttribute("machines");
        if ( sessionStateMachines==null ) {
            // not tracking machines yet, create a map in session
            sessionStateMachines = new HashMap();
            session.setAttribute("machines", sessionStateMachines);
        }
        // save machine into this session's mapping for this name+op
        sessionStateMachines.put(machine.getName()+"_"+machine.getOpKey(), machine);
    }

    /** Remove this page machine from the current session */
    public void destroyStateMachine(HttpSession session)
    {
        System.out.println("attempting remove of "+getName()+" op="+getOpKey());
        Map sessionStateMachines = (Map)session.getAttribute("machines");
        if ( sessionStateMachines!=null ) {
            System.out.println("got machine map "+sessionStateMachines);
            sessionStateMachines.remove(getName()+"_"+getOpKey());
            System.out.println("after remove machine map "+sessionStateMachines);
        }
    }

    public String getNodeTemplateName(String pageName) {
        return (String)stateToTemplateMap.get(getName()+"."+pageName);
    }
}

