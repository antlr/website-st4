/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
// $ANTLR 2.7.2: "rss.g" -> "RSSParser.java"$

    package org.pageforge.lib.rss;
	import java.util.*;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;

public class RSSParser extends antlr.LLkParser       implements RSSParserTokenTypes
 {

protected RSSDescriptor descriptor = null;
protected List items = new LinkedList();

public RSSDescriptor getDescriptor() {
	return descriptor;
}

public List getItems() {
	return items;
}

protected RSSParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public RSSParser(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected RSSParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public RSSParser(TokenStream lexer) {
  this(lexer,1);
}

public RSSParser(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final void rss() throws RecognitionException, TokenStreamException {
		
		
		descriptor();
		{
		_loop3:
		do {
			if ((LA(1)==17)) {
				item();
			}
			else {
				break _loop3;
			}
			
		} while (true);
		}
		match(4);
		match(5);
	}
	
	public final void descriptor() throws RecognitionException, TokenStreamException {
		
		Token  rss = null;
		Token  title = null;
		Token  link = null;
		Token  descr = null;
		Token  lang = null;
		
		rss = LT(1);
		match(TAG);
		if (!(rss.getText().startsWith("<rss")))
		  throw new SemanticException("rss.getText().startsWith(\"<rss\")");
		match(7);
		match(8);
		title = LT(1);
		match(TEXT);
		match(10);
		match(11);
		link = LT(1);
		match(TEXT);
		match(12);
		match(13);
		descr = LT(1);
		match(TEXT);
		match(14);
		match(15);
		lang = LT(1);
		match(TEXT);
		match(16);
		descriptor = new RSSDescriptor(title.getText(),
							link.getText(),
							descr.getText(),
							lang.getText());
	}
	
	public final void item() throws RecognitionException, TokenStreamException {
		
		Token  title = null;
		Token  link = null;
		Token  descr = null;
		
		match(17);
		match(8);
		title = LT(1);
		match(TEXT);
		match(10);
		match(11);
		link = LT(1);
		match(TEXT);
		match(12);
		match(13);
		descr = LT(1);
		match(TEXT);
		match(14);
		match(18);
		items.add( new RSSItem(title.getText(),
						link.getText(),
						descr.getText()) );
			
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"</channel>\"",
		"\"</rss>\"",
		"TAG",
		"\"<channel>\"",
		"\"<title>\"",
		"TEXT",
		"\"</title>\"",
		"\"<link>\"",
		"\"</link>\"",
		"\"<description>\"",
		"\"</description>\"",
		"\"<language>\"",
		"\"</language>\"",
		"\"<item>\"",
		"\"</item>\""
	};
	
	
	}
