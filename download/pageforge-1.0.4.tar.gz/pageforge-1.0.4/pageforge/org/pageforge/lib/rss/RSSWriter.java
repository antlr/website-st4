/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.rss;

import org.antlr.stringtemplate.*;

import java.util.Vector;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;

/** Write RSS 0.91.  XML Looks like this:
<rss version="0.91">
   <channel>
     <title>...</title>
     <link>...</link>
     <description>...</description>
     <language>...</language>
     <item>
       <title>...</title>
       <link>...</link>
       <description>...</description>
     </item>
     <item>
       ...
     </item>
   </channel>
 </rss>

 To write RSS, just create an RSSWriter RSS.generate().

 @see org.pageforge.lib.rss.RSSReader
 */
public class RSSWriter {
    protected String title;
    protected String link;
    protected String description;
    protected String language;
    protected List items = null;

    // the following templates are used generate RSS and are more
    // readable as files, but then it's harder to specify where the files
    // are.

    public static String channelStr =
        "<rss version=\"0.91\">\n"+
        "  <channel>\n"+
        "    <title>$title$</title>\n"+
        "    <link>$link$</link>\n"+
        "    <description>$description$</description>\n"+
        "    <language>$language$</language>\n"+
        "      $items:item(); separator=\"\n\"$\n"+
        "  </channel>\n"+
        "</rss>\n";

    public static String itemStr =
        "<item>\n"+
        "   <title>$attr.title$</title>\n"+
        "   <link>$attr.link$</link>\n"+
        "   <description>$attr.description$</description>\n"+
        " </item>";

    public RSSWriter() {
    }

    public void setDescriptor(String title,
                              String link,
                              String description,
                              String language)
    {
        this.title = title;
        this.link = link;
        this.description = description;
        this.language = language;
    }

    public void setItems(List items) {
        this.items = items;
    }

    public void addItem(String title,
                        String link,
                        String description) {
        if ( items==null ) {
            items = new ArrayList();
        }
        items.add(new RSSItem(title,link,description));
    }

    public void addItem(RSSItem item) {
        if ( items==null ) {
            items = new ArrayList();
        }
        items.add(item);
    }

    public String toString() {
        StringTemplateGroup group = new StringTemplateGroup("rss", ".");
        group.defineTemplate("channel", channelStr);
        group.defineTemplate("item", itemStr);
        StringTemplate rssChannelST = group.getInstanceOf("channel");
        rssChannelST.setAttribute("title", title);
        rssChannelST.setAttribute("link", link);
        rssChannelST.setAttribute("description", description);
        rssChannelST.setAttribute("language", language);
        if ( items!=null ) {
            rssChannelST.setAttribute("items", items);
        }
        return rssChannelST.toString();
    }
}
