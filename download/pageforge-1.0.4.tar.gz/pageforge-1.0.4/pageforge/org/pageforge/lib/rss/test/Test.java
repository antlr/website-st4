/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.rss.test;

import org.pageforge.lib.rss.RSSReader;
import org.pageforge.lib.rss.RSSDescriptor;
import org.pageforge.lib.rss.RSSItem;
import org.pageforge.lib.rss.RSSWriter;

import java.util.*;

public class Test {
    public static void main(String[] args) {
        // Write out some RSS to a string
        RSSWriter rssWriter = new RSSWriter();
        rssWriter.setDescriptor("San Francisco Eats",
                        "http://www.peerscope.com/group/6",
                        "San Francisco restaurants that I like (or really hate).",
                        "en-us");
        rssWriter.addItem("The Meetinghouse - An American Restaurant",
                  "http://www.themeetinghouse.com/home_flash.htm",
                  "I love this restaurant in pacific heights.");
        rssWriter.addItem("Raja Indian Cuisine",
                  "http://rajasf.com/",
                  "The best Indian food in town.  Well, Shalimar is very good too");
        String rssSample = rssWriter.toString();

        System.out.println("-------------- RSS WRITTEN OUT --------------");
        System.out.println(rssSample);

        // Try to read back in.
        System.out.println("-------------- RSS READ IN --------------");
        RSSReader r = null;
        try {
            r = new RSSReader(rssSample);
            RSSDescriptor d = r.getDescriptor();
            System.out.println("descriptor: "+d);
            List items = r.getItems();
            for (int i=0; i<items.size(); i++) {
                RSSItem item = (RSSItem)items.get(i);
                System.out.println(item);
            }
        }
        catch (Exception e) {
            System.out.println("error reading rss: "+e.getMessage());
        }
    }
}
