/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.rss;

import java.util.*;
import java.io.*;

/**
 * Read in RSS 0.91 XML:

 RSSReader r = new RSSReader(new InputStreamReader(System.in));
 RSSDescriptor d = r.getDescriptor();
 System.out.println("descriptor: "+d);
 List items = r.getItems();
 for (int i=0; i<items.size(); i++) {
     RSSItem item = (RSSItem)items.get(i);
     System.out.println(item);
 }

 You'll get RSSDescriptor and RSSItem objects back.
 */

public class RSSReader {
    protected RSSParser parser = null;

    public RSSReader(String rss) throws Exception {
        this( new StringReader(rss) );
    }

    public RSSReader(Reader reader) throws Exception {
        RSSLexer lexer = new RSSLexer(reader);
        parser = new RSSParser(lexer);
        try {
            parser.rss();
        }
        catch (Exception e) {
            // convert ANTLR exceptions to generic
            throw new Exception(e.toString());
        }
    }

    public RSSDescriptor getDescriptor() {
        if ( parser==null ) {
            return null;
        }
        return parser.getDescriptor();
    }

    public List getItems() {
        if ( parser==null ) {
            return null;
        }
        return parser.getItems();
    }
}
