/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.service;

import org.pageforge.Page;
import org.pageforge.support.Utils;

import java.io.*;
import java.util.*;

/** A simple service that sits on top of the LogService.  It has panic,
 *  error, warning, and notice levels.
 *  It also summarizes exceptions in the log and then expands in the
 *  detail log.
 */
public class ErrorService {
    public static String logName = "system";
    public static String detailLogName = "system-detail";

    private ErrorService() {
    }

    public static String getLogName() {
        return logName;
    }

    public static void setLogName(String logName) {
        ErrorService.logName = logName;
    }

    public static String getDetailLogName() {
        return detailLogName;
    }

    public static void setDetailLogName(String detailLogName) {
        ErrorService.detailLogName = detailLogName;
    }

    // PANIC
    public static final String PANIC_PREFIX = "Panic:  ";
    public static final String EXCEPTION_PREFIX = "Exception:  ";

    public static void panic(String msg, Exception e) {
        panic(msg, e, null);
    }

    public static void panic(String msg, Exception e, Page page) {
        try {
            String subj = PANIC_PREFIX + EXCEPTION_PREFIX + msg;
            String body = PANIC_PREFIX + msg + " "+ EXCEPTION_PREFIX +
                Utils.printStackTrace(e);
            rawLogDetailMessage(subj, body);
            // sendEmail(subj, body);
        }
        finally {
            // JGuruApplication.panic();
        }
    }

    // ERROR
    public static final String ERROR_PREFIX = "Error:  ";

    public static void error(String msg) {
        String body = ERROR_PREFIX + msg;
        rawLogMessage(body);
    }

    public static void error(Exception e) {
        String subj = ERROR_PREFIX + EXCEPTION_PREFIX + e.toString();
        String body = ERROR_PREFIX + EXCEPTION_PREFIX + Utils.printStackTrace(e);
        rawLogDetailMessage(subj, body);
    }

    public static void error(String msg, Exception e) {
        error(msg, e, null);
    }

    public static void error(String msg, Exception e, Page page) {
        String subj = ERROR_PREFIX + buildShortMessage(msg, e, page);
        String body =  ERROR_PREFIX + buildDetailMessage(msg, e, page);
        rawLogDetailMessage(subj, body);
    }


    // WARNING
    public static final String WARN_PREFIX = "Warning:  ";

    public static void warning(String msg) {
        rawLogMessage(WARN_PREFIX + msg);
    }

    public static void warning(Exception e) {
        String subj = WARN_PREFIX + EXCEPTION_PREFIX + e.toString();
        String body = WARN_PREFIX + EXCEPTION_PREFIX + Utils.printStackTrace(e);
        rawLogDetailMessage(subj, body);
    }


    public static void warning(String msg, Exception e) {
        warning(msg, e, null);
    }


    public static void warning(String msg, Exception e, Page page) {
        String subj = WARN_PREFIX + buildShortMessage(msg, e, page);
        String body = WARN_PREFIX + buildDetailMessage(msg, e, page);
        rawLogDetailMessage(subj, body);
    }


    // NOTICE
    public static final String NOTICE_PREFIX = "Notice:  ";

    public static void notice(String msg) {
        rawLogMessage(NOTICE_PREFIX + msg);
    }

    public static void notice(String msg, Page pc) {
        String subj = NOTICE_PREFIX + buildShortMessage(msg, null, pc);
        String body = NOTICE_PREFIX + buildDetailMessage(msg, null, pc);
        rawLogDetailMessage(subj, body);
    }

    public static String getTimestamp() {
        GregorianCalendar calendar = new java.util.GregorianCalendar();
        int y = calendar.get(Calendar.YEAR);
        int m = calendar.get(Calendar.MONTH)+1; // zero-based for months
        int d = calendar.get(Calendar.DAY_OF_MONTH);
        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
        int sec = calendar.get(Calendar.SECOND);
        String sy = String.valueOf(y);
        String sm = m<10?"0"+m:String.valueOf(m);
        String sd = d<10?"0"+d:String.valueOf(d);
        String sh = h<10?"0"+h:String.valueOf(h);
        String smin = min<10?"0"+min:String.valueOf(min);
        String ssec = sec<10?"0"+sec:String.valueOf(sec);
        return sy+sm+sd+"_"+sh+"."+smin+"."+ssec;
    }


    // UTIL

    protected static String buildShortMessage(String msg, Exception e,
                                              Page page) {
        if(e != null) {
            return msg+" "+e.getMessage();
        } else {
            return msg;
        }
    }

    protected static String buildDetailMessage(String msg, Exception e,
                                               Page page) {

        ByteArrayOutputStream sbuf = new ByteArrayOutputStream(2000);
        PrintStream sout = new PrintStream(sbuf);
        String result;
        if(e != null) {
            e.printStackTrace(sout);
            result =  msg+"\n"+sbuf.toString();
        } else {
            result = msg;
        }
        if(page != null) {
            result = result + "\n PeerscopePage: \n" + page.toString();
        }
        return result;
    }

    // RAW METHODS

    /** log the message, add timestamp */
    protected static void rawLogMessage(String msg) {
        LogService.log(logName, msg);
    }

    /** log the message to the log detail file, add timestamp */
    protected static void rawLogDetailMessage(String subj, String detail) {
        LogService.log(logName, subj);
        LogService.log(detailLogName, detail);
    }

}
