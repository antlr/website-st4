/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Copyright (c) Non, Inc. 1997, 2000 -- All Rights Reserved

PACKAGE:	IO
FILE:		SMTPClient.java

AUTHOR:		John D. Mitchell, Dec 22, 1997

REVISION HISTORY:
Name	Date		Description
----	----		-----------
JDM	97.12.22   	Initial version.
JDM	2000.02.18	Added "extra" header support.
JDM	2000.02.21	Cleanup & robustness pass.
JDM	2000.02.22	Cleaned-up ugly timestamp creation.
JDM	2000.03.02	Added vetting & cleaning of all addresses.
JDM	2000.03.02	No presumption of localhost on emails.
JDM	2000.03.02	Added version number to mail headers.

NOTES:

Need to add:

* Socket timeouts

* ESMTP support?

* Vet message body for non-8-bit characters.

* Real exception hierarchy.

* Serious test app.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/


package org.pageforge.lib.service;


// Standard Java core packages:

import java.io.* ;
import java.lang.* ;
import java.net.* ;
import java.util.* ;


/**
 ** Basic SMTP client.<br><br>
 **
 ** Note that this class only does checking for expected success
 ** responses from the SMTP server.  No effort at all has been made to
 ** intelligently deal with error responses from the server (like spooling
 ** messages on soft errors).<br><br>
 **
 ** Do <b>not</b> send raw binary data via SMTP!  You must first encode the
 ** binary data into a form suitable for SMTP transmission.  At this time,
 ** this class does not support the popular MIME encoding style but such
 ** support is on the To-Do list. :-)<br><br>
 **
 ** Note that all email addresses <b>must</b> be fully qualified!  I.e.,
 ** <tt>john</tt> and <tt>john@doe</tt> are <b>BAD</b> whereas
 ** <tt>john@doe.flasdf.com</tt> is <b>GOOD</b>.<br><br>
 **
 ** Note also that the email address must contain <b>only</b> the fully
 ** qualifed email address.  No extra bullshit like their name in a string
 ** (i.e., <tt>"John Doe" &ltjohn@doe.flasdf.com&gt</tt> is <b>bad</bd>
 ** while <tt>john@doe.flasdf.com</tt> is <b>good</b>.<br><br>
 **
 ** <pre><code>
 ** //...
 **	    SMTPClient emailer = new SMTPClient() ;
 **	    emailer.connect (mailhost);
 **	    emailer.sendMessage (from, recipient, subject, message);
 **	    emailer.disconnect();
 ** //...
 ** </code></pre><br><br>
 **
 ** Note that rather than opening and closing a connnection for each email
 ** to a specific host, you may open a connnection, send multiple messages
 ** to or through the same host, and then close the connection:<br><br>
 **
 ** <pre><code>
 ** //...
 **	    SMTPClient emailer = new SMTPClient() ;
 **	    emailer.connect (mailhost);
 **	    emailer.sendMessage (from, recipient, subject, message);
 **	    emailer.sendMessage (from, recipient2, subject2,
 **				 "Howdy!\r\nTake care,\r\n\tJohn");
 **	    emailer.disconnect();
 ** //...
 ** </code></pre><br><br>
 **
 ** There is also a more generic form of sendMessage() which takes lists
 ** of direct recipients, public carbon-copy recipients, blind
 ** carbon-copy recipients, and a list of extra SMTP headers:<br><br>
 **
 ** <pre><code>
 ** //...
 **	public Vector recipientList;
 **	public Vector ccList;
 **	public Vector bccList;
 **	public Vector extraHeaders;
 **<br>
 **	recipientList = new Vector();
 **	recipientList.addElement ("john@doe.flasdf.com");
 **	recipientList.addElement ("klepto@klep.to");
 **<br>
 **	ccList = new Vector();
 **	ccList.addElement ("john@mitchell.org");
 **<br>
 **	bccList = new Vector();
 **	bccList.addElement ("dopey@pafmb.com");
 **<br>
 **	extraHeaders = new Vector();
 **	extraHeaders.addElement ("Precedence: bulk");
 **	extraHeaders.addElement ("X-No-Archive: true");
 **<br>
 **	SMTPClient emailer = new SMTPClient() ;
 **	emailer.connect (mailhost);
 **	emailer.sendMessage ("me@here.mydomain",
 **			     recipientList,
 **			     ccList,
 **			     bccList,
 **			     "HHeeellllooooo!",
 **			     "Howdy!\r\nTake care,\r\n\tJohn",
 **			     extraHeaders);
 **	emailer.disconnect();
 ** //...
 ** </code></pre><br><br>
 **
 ** @author	John D. Mitchell, Non, Inc., Dec 22, 1997
 **
 ** @version 0.74
 **
 **/

public class SMTPClient
    {
    // SMTPClient version number.
    //
    // NOTE:  Make sure that you keep this and the javadoc version string
    //	      in sync!
    //
    private static final String versionString = "0.74";


    // Communication channel with the SMTP server.
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;

    // Local host identification.
    private String localHostName;
    private String localHostIP;

    // SMTP TCP port identifier.
    private static final int smtpPort = 25;

    // Hard-coded RFC 821 strings.
    private static final String lineEnd = "\r\n";
    private static final String mesgEnd = "\r\n.\r\n";


    /*
    * Constructors
    */

    /**
     ** Create an SMTP client object.<br><br>
     **
     ** @exception	UnknownHostException
     **/
    public SMTPClient() throws UnknownHostException
    {
        // Figure out the localhost information.
        String clientHost = InetAddress.getLocalHost().toString();
        localHostName = clientHost.substring (0, clientHost.indexOf ("/"));
        localHostIP = clientHost.substring (clientHost.indexOf ("/"));

        // Initialize the streams.
        resetStreams();
    }	// End of SMTPClient().


    /*
    * Public methods.
    */

    /**
     ** Open an SMTP connection to the specified host.<br><br>
     **
     ** @param	String smtpServer -- Name of host to connect to.
     **
     ** @exception	Exception Unable to connect to host.
     **
     ** @see	connnect (String, String)
     **
     **/
    public void connect (String smtpServer)
        throws Exception
    {
        connect (smtpServer, localHostName);
    }	// End of connect().

    /**
     ** Open an SMTP connection to the specified host using the given string as
     ** the greeting.<br><br>
     **
     ** @param	String smtpServer -- Name of host to connect to.
     ** @param	String greetingHost -- Greeting for HELO -- The first part
     **		should be the name of your sending host.
     **
     ** @exception	Exception Unable to connect to host.
     **
     **/
    public void connect (String smtpServer, String greetingHost)
        throws Exception
    {
        doConnect (smtpServer);
        doGreeting (greetingHost);
    }	// End of connect().

    /**
     ** Send an email message from the specified sender to the given
     ** recipient.<br><br>
     **
     ** This is a simple method to send a message to a single recipient -- much
     ** less setup for the simple case than the more generic sending
     ** routine.<br><br>
     **
     ** @param	String From addresss.
     ** @param	String To address.
     ** @param	String Topic of message.
     ** @param	String The message.
     **
     ** @exception	Exception Unable to send the message.
     **
     ** @see	sendMessage (String, String, String, String, Vector)
     ** @see	sendMessage (String, Vector, Vector, Vector, String, String)
     ** @see	sendMessage (String, Vector, Vector, Vector, String,
     **			     String, Vector)
     **
     **/
    public void sendMessage (String sender,
                             String recipient,
                             String subject,
                             String message)
        throws Exception
    {
        Vector toList = new Vector();

        toList.addElement (recipient);

        sendMessage (sender, toList,
                     (Vector) null, (Vector) null,
                     subject, message,
                     (Vector) null);
    }	// End of sendMessage().

    /**
     ** Send an email message from the specified sender to the given
     ** recipient.<br><br>
     **
     ** This is a simple method to send a message to a single recipient -- much
     ** less setup for the simple case than the more generic sending
     ** routine.<br><br>
     **
     ** @param	String From addresss.
     ** @param	String To address.
     ** @param	String Topic of message.
     ** @param	String The message.
     ** @param	Vector List of extra email headers w/ values -- May be empty.
     **
     ** @exception	Exception Unable to send the message.
     **
     ** @see	sendMessage (String, String, String, String)
     ** @see	sendMessage (String, Vector, Vector, Vector, String, String)
     ** @see	sendMessage (String, Vector, Vector, Vector, String,
     **			     String, Vector)
     **
     **/
    public void sendMessage (String sender,
                             String recipient,
                             String subject,
                             String message,
                             Vector extraHeaders)
        throws Exception
    {
        Vector toList = new Vector();

        toList.addElement (recipient);

        sendMessage (sender, toList,
                     (Vector) null, (Vector) null,
                     subject, message, extraHeaders);
    }	// End of sendMessage().

    /**
     ** Send an email message from the specified sender to the various
     ** lists of recipients.<br><br>
     **
     ** This method is the generic routine to send a message to multiple
     ** recipients.<br><br>
     **
     ** @param	String From addresss.
     ** @param	Vector List of To addressees -- Must <b>not</b> be empty.
     ** @param	Vector List of CC addressees -- May be empty.
     ** @param	Vector List of BCC addressess -- May be empty.
     ** @param	String Topic of message.
     ** @param	String The message.
     **
     ** @exception	Exception Unable to send the message.
     **
     ** @see	sendMessage (String, String, String, String)
     ** @see	sendMessage (String, String, String, String, Vector)
     ** @see	sendMessage (String, Vector, Vector, Vector, String,
     **			     String, Vector)
     **
     **/
    public void sendMessage (String from,
                             Vector toList,
                             Vector ccList,
                             Vector bccList,
                             String subject,
                             String message)
        throws Exception
    {
        sendMessage (from, toList, ccList, bccList,
                     subject, message, (Vector) null);
    }	// End of sendMessage().


    /**
     ** Send an email message from the specified sender to the various
     ** lists of recipients.<br><br>
     **
     ** This method is the generic routine to send a message to multiple
     ** recipients with multiple headers.<br><br>
     **
     ** @param	String From addresss.
     ** @param	Vector List of To addressees -- Must <b>not</b> be empty.
     ** @param	Vector List of CC addressees -- May be empty.
     ** @param	Vector List of BCC addressess -- May be empty.
     ** @param	String Topic of message.
     ** @param	String The message.
     ** @param	Vector List of extra email headers w/ values -- May be empty.
     **
     ** @exception	Exception Unable to send the message.
     **
     ** @see	sendMessage (String, String, String, String)
     ** @see	sendMessage (String, String, String, String, Vector)
     ** @see	sendMessage (String, Vector, Vector, Vector, String, String)
     **
     **/
    public void sendMessage (String from,
                             Vector toList,
                             Vector ccList,
                             Vector bccList,
                             String subject,
                             String message,
                             Vector extraHeaders)
        throws Exception
    {
        try
        {
            // Can't have empty toList.
            if (0 >= toList.size())
            {
                throw new Exception
                    ("SMTPClient.sendMessage: Empty recipient list!");
            }

            // Make sure that the From: address is relatively sane.
            from = vetAddress (from);
            toList = vetAddressList (toList);
            ccList = vetAddressList (ccList);
            bccList = vetAddressList (bccList);

            doRSET();

            doFrom (from);

            doRCPT (toList);
            doRCPT (ccList);
            doRCPT (bccList);

            doData (from, toList, ccList, bccList,
                    subject, message, extraHeaders);

            doEOM();
        }
        catch (IOException e)
        {
            throw new Exception ("SMTPClient.SendMessage: IO exception!");
        }
    }	// End of sendMessage().


    /**
     ** Shutdown the existing SMTP connection.<br><br>
     **
     ** @exception	Exception Unable to close connection.
     **
     ** @see	connnect (String)
     **
     **/
    public void disconnect() throws Exception
    {
        // Anything to actually close?
        if (null == socket)
        {
            // Nope, bail.
            return;
        }

        try
        {
            writeln ("QUIT");
            smtpExpect ("221", "SMTPClient.Disconnect: QUIT");
        }
        catch (IOException e)
        {
            throw new Exception ("SMTPClient.Disconnect: IO Exception!");
        }
        finally
        {
            resetStreams();
        }
    }	// End of disconnect().


    /*
    * Private utility methods.
    */

    /*
    * Write the given data string to the SMTP server.
    */
    private void write (String data)
        throws Exception
    {
        out.writeBytes (data);
        out.flush();
    }	// End of write (String).


    /*
    * Write the given line of data to the SMTP server.
    */
    private void writeln (String data)
        throws Exception
    {
        out.writeBytes (data);
        out.writeBytes (lineEnd);
        out.flush();
    }	// End of writeln (String).


    /*
    * Expect the given SMTP response from the server, eat all lines
    * beginning with that response, spew the given message on if there is
    * an error.
    *
    * Should change this to build up and return the server response
    * string.
    */
    private void smtpExpect (String expected, String msg)
        throws Exception
    {
        String curServerResponse = in.readLine();

        if (!curServerResponse.startsWith (expected))
        {
            throw new Exception (msg + ": " + curServerResponse);
        }

        while (curServerResponse.startsWith (expected + "-"))
        {
            curServerResponse = in.readLine();
        }
    }	// End of smtpExpect (String, String).


    /*
    * Reset the data streams making sure to nuke any existing streams.
    */
    private void resetStreams()
    {
        try
        {
            if (null != out)
                out.close();
        }
        catch (Exception e)
        {
            // Ignore it.
        }
        finally
        {
            out = null;
        }

        try
        {
            if (null != in)
                in.close();
        }
        catch (Exception e)
        {
            // Ignore it.
        }
        finally
        {
            in = null;
        }

        try
        {
            if (null != socket)
                socket.close();
        }
        catch (Exception e)
        {
            // Ignore it.
        }
        finally
        {
            socket = null;
        }
    }	// End of resetStreams().

    /*
    * Open up a socket connection to the standard SMTP port on the
    * specified host.
    */
    private void doConnect (String smtpHost) throws Exception
    {
        try
        {
            // Connect to the configured (host, port).
            socket = new Socket (smtpHost, smtpPort);

            // Get data streams.
            in = new DataInputStream (socket.getInputStream());
            out = new DataOutputStream (socket.getOutputStream());
        }
        catch (SecurityException se)
        {
            resetStreams();

            throw new Exception
                ("SMTPClient.Connect: " +
                 "Security exception trying to connect to port #" +
                 smtpPort);
        }
        catch (IOException ioe)
        {
            resetStreams();

            throw new Exception
                ("SMTPClient.Connect: " +
                 "IO exception trying to connect to port #" + smtpPort);
        }
    }	// End of doConnect (host).


    private void doGreeting (String heloHost) throws Exception
    {
        smtpExpect("220", "SMTPClient.Greet: Greeting") ;
        writeln ("HELO " + heloHost);
        smtpExpect ("250",
                    "SMTPClient.Greet: HELO " + heloHost);
    }	// End of doGreeting().


    private void doRSET() throws Exception
    {
        writeln ("RSET");
        smtpExpect ("250", "SMTPClient.SendMessage: RSET");
    }	// End of doRSET().


    private void doFrom (String from) throws Exception
    {
        writeln ("MAIL FROM: <" + from + ">");
        smtpExpect ("250",
                    "SMTPClient.SendMessage: MAIL FROM <" +
                    from + ">");
    }	// End of doFrom().


    private void doRCPT (String to) throws Exception
    {
        writeln ("RCPT TO: <" + to + ">");
        smtpExpect ("250",
                    "SMTPClient.SendMessage: RCPT TO <" +
                    to + ">");
    }	// End of doRCPT (String).


    private void doRCPT (Vector data) throws Exception
    {
        String str = null;
        Enumeration list = null;

        // Any list to work on?
        if (null == data)
        {
            return;
        }

        // Anything in the list?
        list = data.elements();
        while (list.hasMoreElements())
        {
            try
            {
                str = (String) list.nextElement();

                out.writeBytes ("RCPT TO: <");
                out.writeBytes (str);
                writeln (">");
                smtpExpect ("250",
                            "SMTPClient.SendMessage: RCPT TO <" +
                            str + ">");
            }
            catch (ClassCastException cce)
            {
                // Skip invalid list items.
            }
        }
    }	// End of doRCPT (Vector).


    private void doData() throws Exception
    {
        writeln ("DATA");
        smtpExpect ("354", "SMTPClient.SendMessage: DATA");
    }	// End of doData().


    private void doData (String from,
                         Vector toList,
                         Vector ccList,
                         Vector bccList,
                         String subject,
                         String message)
        throws Exception
    {
        doData (from, toList, ccList, bccList,
                subject, message, (Vector) null);
    }	// End of doData (String, Vector x 3, String x 2).


    private void doData (String from,
                         Vector toList,
                         Vector ccList,
                         Vector bccList,
                         String subject,
                         String message,
                         Vector extraHeaderList)
        throws Exception
    {
        try
        {
            doData();

            writeln ("From: " + from);

            writeln ("X-Mailer: net.non.io.SMTPClient-" +
                     versionString + "@" +
                     InetAddress.getLocalHost().toString());

            blastHeaderList (extraHeaderList);

            blastListHeader ("To:", toList);
            blastListHeader ("CC:", ccList);

            writeln ("Subject: " + subject);
            writeln ("Date: " + dateTimeStamp());

            writeln ("");

            writeln (encodeMessage (message));
        }
        catch (IOException e)
        {
            throw new Exception ("SMTPClient.doData: IO exception!");
        }
    }	// End of doData (String, Vector x 3, String x 2, Vector).


    private String dateTimeStamp()
    {
        String[] dayToAbbrev =
            {
                "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"
            };
        String[] monthToAbbrev =
            {
                "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
            };

        Date date = new Date();

        int tzOff = date.getTimezoneOffset();
        String tz = ((0 > tzOff) ? "+" : "-") +
            ((600 > tzOff) ? "0" : "") +
            (tzOff / 60) + "00";

        int rawHours = date.getHours();
        String hours = ((10 > rawHours) ? "0" : "") + rawHours;

        int rawMins = date.getMinutes();
        String minutes = ((10 > rawMins) ? "0" : "") + rawMins;

        int rawSecs = date.getSeconds();
        String seconds = ((10 > rawSecs) ? "0" : "") + rawSecs;

        return (dayToAbbrev [date.getDay()]	+ ", " +
            date.getDate()			+ " " +
            monthToAbbrev [date.getMonth()]	+ " " +
            (1900 + date.getYear())		+ " " +
            hours				+ ":" +
            minutes				+ ":" +
            seconds				+ " " +
            tz);
    }	// End of dateTimeStamp().


    /*
    * Write out the given list of SMTP headers and their values.
    *
    * Note that this method should be used only for headers which
    * have a single value.
    *
    * Note that for headers which may have multiple values, use
    * blastListHeader() instead.
    *
    * Each element of the vector should be a complete SMTP header value.
    * I.e., "Header: value".  Note that there's NO checking to validate
    * that the given vector entries are actually valid headers.
    */
    private void blastHeaderList (Vector data)
        throws Exception
    {
        String	str = null;
        Enumeration list = null;

        // Any list to work on?
        if (null == data)
        {
            return;
        }

        // Process anything in the list.
        list = data.elements();
        while (list.hasMoreElements())
        {
            try
            {
                str = (String) list.nextElement();
                out.writeBytes (str);
                out.writeBytes (lineEnd);
            }
            catch (ClassCastException cce)
            {
                // Currently, just ignore this entry and continue.
            }
        }
    }	// End of blastHeaderList (Vector).


    /*
    * Write out the given list of elements for the specified SMTP data
    * header.
    */
    private void blastListHeader (String header,
                                  Vector data)
        throws Exception
    {
        String str = null;
        Enumeration list = null;

        // Any header to specify?
        if ((null == header) || (header.equals ("")))
        {
            return;
        }

        // Any list to work on?
        if (null == data)
        {
            return;
        }

        // Anything in the list?
        list = data.elements();
        if (list.hasMoreElements())
        {
            // Bail if the first element isn't a String.
            // Since, most likely, the user is just a complete moron.
            try
            {
                str = (String) list.nextElement();

                out.writeBytes (header);
                out.writeBytes (" ");
                out.writeBytes (str);
            }
            catch (ClassCastException cce)
            {
                throw
                    new Exception ("SMTPClient.blastListHeader: " +
                                   "Invalid initial header list element!");
            }

            while (list.hasMoreElements())
            {
                try
                {
                    str = (String) list.nextElement();

                    out.writeBytes (",\r\n\t");
                    out.writeBytes (str);
                }
                catch (ClassCastException cce)
                {
                    // Ignore any problems with the subsequent elements.
                }
            }
            writeln ("");
        }
    }	// End of blastListHeader (String, Vector).


    private void doEOM() throws Exception
    {
        write (mesgEnd);
        smtpExpect ("250", "SMTPClient.SendMessage: EOM");
    }	// End of doEOM().


    /*
    * Check the given email address string for basic sanity.
    */
    private String vetAddress (String address)
        throws Exception
    {
        int length;

        // Can't have a non-existent address.
        if (null == address)
        {
            throw new
                Exception ("SMTPClient:  Non-existent From: address!");
        }

        // Can't have an empty address.
        if (0 >= (length = address.length()))
        {
            throw new Exception ("SMTPClient:  Empty From: address!");
        }


        // Where is the at sign?
        int atLoc = address.indexOf ("@");
        if (-1 == atLoc)
        {
            // No '@' means not a valid address -- all addresses must be
            // fully-qualified.
            throw new Exception ("SMTPClient:  Invalid email address!" +
                                 "\n\t<" + address + ">");
        }

        if (0 == atLoc)
        {
            // Hmm... At the beginning...
            throw new Exception ("SMTPClient:  Bad email address!" +
                                 "\n\t<" + address + ">");
        }

        if (atLoc == length - 1)
        {
            // Hmm... At the end...
            throw new Exception ("SMTPClient:  Invalid email address!" +
                                 "\n\t<" + address + ">");
        }

        // Must already have stuff on both sides of the at sign.
        //
        // Could add more checks...

        // Eat extraneous whitespace at the beginning & end of the
        // address.
        return (address.trim());
    }	// End of vetAddress().


    /*
    * Vet the given vector of strings for relative sanity as email
    * addresses.
    *
    * Note carefully that this method will throw an exception if
    * ANY of the addresses in the list are invalid!
    *
    * Note that the original vector is NOT modified -- a new Vector
    * is returned which contains the vetted list of addresses.
    */
    private Vector vetAddressList (Vector addressList)
        throws Exception
    {
        // Non-existent list?
        if (null == addressList)
        {
            // Okay, nothing to do.
            return null;
        }

        // Empty list?
        if (addressList.isEmpty())
        {
            // Yep, nothing to do.
            //
            // We choose to clean-up this odd case by discarding this
            // vector.
            return null;
        }

        // Assert:  Non-empty address list.

        // Vet each and every address entry in the list.
        String str = null;
        Vector newAddressList = new Vector (addressList.size());
        Enumeration list = addressList.elements();
        while (list.hasMoreElements())
        {
            try
            {
                newAddressList.
                    addElement (vetAddress ((String) list.nextElement()));
            }
            catch (ClassCastException cce)
            {
                throw new
                    Exception ("SMTPClient: Invalid email address list!");
            }
        }

        // Send back the list of vetted addresses.
        return newAddressList;
    }	// End of vetAddressList().


    /*
    * Encode the given message body so that it will make it through the
    * SMTP channel.  Basically this just takes care to make sure that the
    * end-of-line and in-band signalling of SMTP are properly guarded
    * against.  This encoding is as per section 4.5.2 of RFC821.
    */
    private String encodeMessage (String message)
    {
        StringBuffer mesgBuff = new StringBuffer();
        int i, j;


        // Is there a period at the start of the message?
        boolean copyMessage = false;
        if ('.' == message.charAt (0))
        {
            mesgBuff.append ('.');
            copyMessage = true;
        }

        // Qualify any bare linefeeds and troublesome periods.
        i = 0;
        while (0 < (j = message.indexOf ("\n", i)))
        {
            // Copy everything up to that point into the temp. buffer.
            mesgBuff.append (message.substring (i, j));

            // Is it a bare linefeed?
            try
            {
                if ('\r' != message.charAt (j - 1))
                {
                    mesgBuff.append ("\r");
                }
            }
            catch (StringIndexOutOfBoundsException e)
            {
                // Invalid index.  Must be a bare linefeed at the
                // beginning of the string.
                mesgBuff.append ("\r");
            }

            mesgBuff.append ("\n");
            i = j + 1;	// Skip up through the original linefeed.

            // Is there a '.' at the begining of the *next* line?
            try
            {
                if ('.' == message.charAt (i))
                {
                    // Just add in an extra '.' (since the line will get
                    // dealt with in the next iteration of the while
                    // loop).
                    mesgBuff.append (".");
                }
            }
            catch (StringIndexOutOfBoundsException e)
            {
                // Invalid index.  Must be a linefeed at the
                // end of the string.  Do nothing.
            }
        }

        // Anything converted?
        if ((0 < i) || (copyMessage))
        {
            // Copy the remainder of the message.
            mesgBuff.append (message.substring (i));
            message = mesgBuff.toString();
        }

        return message;
    }	// End of encodeMessage (String).


    /** Send an email to somebody.  Added by Terence Parr.
     */
    public static void sendmail(String smtpHost,
                                String from,
                                String to,
                                String subject,
                                String body)
        throws Exception
    {
        SMTPClient message_smtp = new SMTPClient() ;
        message_smtp.connect (smtpHost);
        message_smtp.sendMessage (from,
                                  to,
                                  subject,
                                  body);
        message_smtp.disconnect();
    }


    /** Send an email to somebody w/ BCC.  Added by Jim Coker
     */
    public static void sendmailWithBCC(String smtpHost,
                                       String from,
                                       String to,
                                       String bcc,
                                       String subject,
                                       String body)
        throws Exception
    {
        SMTPClient message_smtp = new SMTPClient() ;
        message_smtp.connect (smtpHost);

        Vector toList = new Vector(1);
        toList.addElement(to);
        Vector ccList = new Vector(0);
        Vector bccList = new Vector(1);
        bccList.addElement(bcc);

        message_smtp.sendMessage(from, toList, ccList, bccList, subject, body);

        message_smtp.disconnect();
    }

    /** Send an email to somebody w/ BCC.  Added by Jim Coker
     */
    public static void sendmail(String smtpHost,
                                String from,
                                Vector toList,
                                Vector ccList,
                                Vector bccList,
                                String subject,
                                String body)
        throws Exception
    {
        SMTPClient message_smtp = new SMTPClient() ;
        message_smtp.connect (smtpHost);

        message_smtp.sendMessage(from, toList, ccList, bccList, subject, body);

        message_smtp.disconnect();
    }

    public static class Test
	{
        public static void main (String[] args)
        {
            try
            {
                String from		= "john@non.net";

                Vector listExtraHeaders = new Vector();
                listExtraHeaders.addElement ("Precedence: bulk");
                listExtraHeaders.addElement ("X-No-Archive: true");

                String host1		= "angola.wpi.com";
                String recipient1	= "john.mitchell@javaworld.com";

                String host2		= "soda.csua.berkeley.edu";
                String recipient2	= "johnm@soda.csua.berkeley.edu";

                String host3		= "mail.non.net";
                String recipient3	= "ru@klep.to";

                SMTPClient message_smtp = new SMTPClient() ;

                message_smtp.connect (host1);

                message_smtp.sendMessage (from,
                                          recipient1,
                                          "Short Test SMTP net.non.smtp",
                                          "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n");

                message_smtp.disconnect();


                message_smtp.connect (host2);

                message_smtp.sendMessage (from,
                                          recipient2,
                                          "Short Test SMTP net.non.smtp",
                                          "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n");

                message_smtp.sendMessage (from,
                                          recipient2,
                                          "Period-only Test SMTP net.non.smtp",
                                          ".\n\n");

                message_smtp.disconnect();

                message_smtp.connect (host3);

                try
                {
                    message_smtp.
                        sendMessage (from, recipient2,
                                     "Recipient FAIL Test SMTP net.non.smtp",
                                     "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n");
                }
                catch (Exception e)
                {
                    System.out.println("*** SMTP Exception: " +
                                       e.getMessage());
                }

                try
                {
                    message_smtp.
                        sendMessage (from + " \t", recipient3,
                                     "Bad From: Test SMTP net.non.smtp",
                                     "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n");
                }
                catch (Exception e)
                {
                    System.out.println("*** SMTP Exception: " +
                                       e.getMessage());
                }

                try
                {
                    message_smtp.
                        sendMessage (from, " \t" + recipient3,
                                     "Bad To: Test SMTP net.non.smtp",
                                     "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n");
                }
                catch (Exception e)
                {
                    System.out.println("*** SMTP Exception: " +
                                       e.getMessage());
                }

                try
                {
                    message_smtp.
                        sendMessage ("johnm", recipient3,
                                     "Bare From: Test SMTP net.non.smtp",
                                     "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n");
                }
                catch (Exception e)
                {
                    System.out.println("*** SMTP Exception: " +
                                       e.getMessage());
                }

                message_smtp.sendMessage (from,
                                          recipient3,
                                          "Short Test SMTP net.non.smtp",
                                          "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n");

                message_smtp.sendMessage (from,
                                          recipient3,
                                          "Period Test SMTP net.non.smtp",
                                          ".aaaaaaaaaaaaa..aaaa\n.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n.");

                message_smtp.
                    sendMessage (from, recipient3,
                                 "Short Test w/headers SMTP net.non.smtp",
                                 "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n",
                                 listExtraHeaders);

                message_smtp.disconnect();


                message_smtp.connect (host2);

                message_smtp.sendMessage (from,
                                          recipient2,
                                          "Long Test SMTP net.non.smtp",
                                          "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n" +
                                          "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n\n" +
                                          "cccccccccccccccccccccccccccccccccccccccccccccccccc\n\n" +
                                          "dddddddddddddddddddddddddddddddddddddddddddddddddd\n\n" +
                                          "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\n\n" +
                                          "ffffffffffffffffffffffffffffffffffffffffffffffffff\n\n" +
                                          "gggggggggggggggggggggggggggggggggggggggggggggggggg\n\n" +
                                          "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n" +
                                          "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n" +
                                          "jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj\n\n" +
                                          "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk\n\n" +
                                          "llllllllllllllllllllllllllllllllllllllllllllllllll\n\n" +
                                          "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm\n\n" +
                                          "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n" +
                                          "oooooooooooooooooooooooooooooooooooooooooooooooooo\n\n" +
                                          "pppppppppppppppppppppppppppppppppppppppppppppppppp\n\n" +
                                          "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq\n\n" +
                                          "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n" +
                                          "ssssssssssssssssssssssssssssssssssssssssssssssssss\n\n" +
                                          "ttttttttttt\n" +
                                          "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n" +
                                          "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n\n" +
                                          "cccccccccccccccccccccccccccccccccccccccccccccccccc\n\n" +
                                          "dddddddddddddddddddddddddddddddddddddddddddddddddd\n\n" +
                                          "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\n\n" +
                                          "ffffffffffffffffffffffffffffffffffffffffffffffffff\n\n" +
                                          "gggggggggggggggggggggggggggggggggggggggggggggggggg\n\n" +
                                          "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n" +
                                          "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n" +
                                          "jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj\n\n" +
                                          "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk\n\n" +
                                          "llllllllllllllllllllllllllllllllllllllllllllllllll\n\n" +
                                          "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm\n\n" +
                                          "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n" +
                                          "oooooooooooooooooooooooooooooooooooooooooooooooooo\n\n" +
                                          "pppppppppppppppppppppppppppppppppppppppppppppppppp\n\n" +
                                          "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq\n\n" +
                                          "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n" +
                                          "ssssssssssssssssssssssssssssssssssssssssssssssssss\n\n" +
                                          "ttttttttttt\n" +
                                          "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n" +
                                          "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n\n" +
                                          "cccccccccccccccccccccccccccccccccccccccccccccccccc\n\n" +
                                          "dddddddddddddddddddddddddddddddddddddddddddddddddd\n\n" +
                                          "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\n\n" +
                                          "ffffffffffffffffffffffffffffffffffffffffffffffffff\n\n" +
                                          "gggggggggggggggggggggggggggggggggggggggggggggggggg\n\n" +
                                          "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n" +
                                          "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n" +
                                          "jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj\n\n" +
                                          "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk\n\n" +
                                          "llllllllllllllllllllllllllllllllllllllllllllllllll\n\n" +
                                          "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm\n\n" +
                                          "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n" +
                                          "oooooooooooooooooooooooooooooooooooooooooooooooooo\n\n" +
                                          "pppppppppppppppppppppppppppppppppppppppppppppppppp\n\n" +
                                          "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq\n\n" +
                                          "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n" +
                                          "ssssssssssssssssssssssssssssssssssssssssssssssssss\n\n" +
                                          "ttttttttttt\n");

                message_smtp.disconnect();


                message_smtp.connect (host1);

                message_smtp.sendMessage (from,
                                          recipient1,
                                          "Long Test SMTP net.non.smtp",
                                          "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n" +
                                          "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n\n" +
                                          "cccccccccccccccccccccccccccccccccccccccccccccccccc\n\n" +
                                          "dddddddddddddddddddddddddddddddddddddddddddddddddd\n\n" +
                                          "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\n\n" +
                                          "ffffffffffffffffffffffffffffffffffffffffffffffffff\n\n" +
                                          "gggggggggggggggggggggggggggggggggggggggggggggggggg\n\n" +
                                          "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n" +
                                          "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n" +
                                          "jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj\n\n" +
                                          "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk\n\n" +
                                          "llllllllllllllllllllllllllllllllllllllllllllllllll\n\n" +
                                          "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm\n\n" +
                                          "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n" +
                                          "oooooooooooooooooooooooooooooooooooooooooooooooooo\n\n" +
                                          "pppppppppppppppppppppppppppppppppppppppppppppppppp\n\n" +
                                          "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq\n\n" +
                                          "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n" +
                                          "ssssssssssssssssssssssssssssssssssssssssssssssssss\n\n" +
                                          "ttttttttttt\n" +
                                          "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n" +
                                          "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n\n" +
                                          "cccccccccccccccccccccccccccccccccccccccccccccccccc\n\n" +
                                          "dddddddddddddddddddddddddddddddddddddddddddddddddd\n\n" +
                                          "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\n\n" +
                                          "ffffffffffffffffffffffffffffffffffffffffffffffffff\n\n" +
                                          "gggggggggggggggggggggggggggggggggggggggggggggggggg\n\n" +
                                          "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n" +
                                          "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n" +
                                          "jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj\n\n" +
                                          "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk\n\n" +
                                          "llllllllllllllllllllllllllllllllllllllllllllllllll\n\n" +
                                          "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm\n\n" +
                                          "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n" +
                                          "oooooooooooooooooooooooooooooooooooooooooooooooooo\n\n" +
                                          "pppppppppppppppppppppppppppppppppppppppppppppppppp\n\n" +
                                          "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq\n\n" +
                                          "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n" +
                                          "ssssssssssssssssssssssssssssssssssssssssssssssssss\n\n" +
                                          "ttttttttttt\n" +
                                          "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n" +
                                          "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n\n" +
                                          "cccccccccccccccccccccccccccccccccccccccccccccccccc\n\n" +
                                          "dddddddddddddddddddddddddddddddddddddddddddddddddd\n\n" +
                                          "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\n\n" +
                                          "ffffffffffffffffffffffffffffffffffffffffffffffffff\n\n" +
                                          "gggggggggggggggggggggggggggggggggggggggggggggggggg\n\n" +
                                          "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n" +
                                          "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n" +
                                          "jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj\n\n" +
                                          "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk\n\n" +
                                          "llllllllllllllllllllllllllllllllllllllllllllllllll\n\n" +
                                          "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm\n\n" +
                                          "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n" +
                                          "oooooooooooooooooooooooooooooooooooooooooooooooooo\n\n" +
                                          "pppppppppppppppppppppppppppppppppppppppppppppppppp\n\n" +
                                          "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq\n\n" +
                                          "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n" +
                                          "ssssssssssssssssssssssssssssssssssssssssssssssssss\n\n" +
                                          "ttttttttttt\n");

                message_smtp.disconnect();
            }
            catch (Exception e)
            {
                System.out.println ("*** SMTP Exception: " +
                                    e.getMessage()) ;
            }
        }
    }
}		// End of class SMTPClient.


