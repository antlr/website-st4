/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.service;


import java.util.List;
import java.util.Vector;


public class EmailService {
    private static String SMTPServer = null;
    private static String SMTPFailoverServer = null;
    private static boolean testMode = true;
    private static List alwaysContact = null;

    private static EmailServiceListener listener =
        /** dummy listener; no output */
        new EmailServiceListener() {
            public void error(String msg, Exception e) {
            }
            public void simulated(String from, String to, String subject, String message) {
            }
            public void log(String from, String to, String subject, String message) {
            }
        };

    private EmailService() {
    }

    public static boolean isTestMode() {
        return testMode;
    }

    /** If in test mode, emails don't actually go out, but listener is
     *  sent simulated() message.
     */
    public static void setTestMode(boolean testMode) {
        EmailService.testMode = testMode;
    }

    /** Even in test mode, you can send mail to a list of emails.  This
     *  is useful for testing your server by allowing email to you, but
     *  not to your users.
     */
    public static void setAlwaysContact(List alwaysContact) {
        EmailService.alwaysContact = alwaysContact;
    }

    public static EmailServiceListener getListener() {
        return listener;
    }

    /** Tell me where logging information should go. */
    public static void setListener(EmailServiceListener listener) {
        EmailService.listener = listener;
    }

    public static String getSMTPServer() {
        return SMTPServer;
    }

    public static void setSMTPServer(String SMTPServer) {
        EmailService.SMTPServer = SMTPServer;
    }

    public static String getSMTPFailoverServer() {
        return SMTPFailoverServer;
    }

    public static void setSMTPFailoverServer(String SMTPFailoverServer) {
        EmailService.SMTPFailoverServer = SMTPFailoverServer;
    }

    /** Launch a thread to send a message/subject to an email list */
    public static void sendEmailNonBlocking(final String from,
                                            final List emailAddrs,
                                            final String subject,
                                            final String message)
    {
        Runnable r = new Runnable() {
            public void run() {
                for (int i = 0; emailAddrs != null && i < emailAddrs.size(); i++) {
                    String email = (String) emailAddrs.get(i);
                    try {
                        sendEmail(from,
                                  email,
                                  subject,
                                  message);
                    }
                    catch (Exception ee) {
                        if (!email.equals("parrt@jguru.com")) {
                            try {
                                sendEmail(
                                    from,
                                    "parrt@jguru.com",
                                    "Error running thread notification",
                                    "Exception in sendEmailNonBlocking: " + ee + "; i'll keep going though");
                            }
                            catch (Exception eee) {
                                // crap out; error even to parrt
                                listener.error("error in sendEmailNonBlocking: can't even email parrt about a problem", eee);
                            }
                        }
                        else {
                            listener.error("error in sendEmailNonBlocking", ee);
                        }
                    }
                }
            }
        };
        Thread mailThread = new Thread(r);
        mailThread.setName("email-"+emailAddrs+"-from-"+from);
        mailThread.start(); // launch loop in thread to send email
    }

    /** Launch a thread to send a message/subject to an email list */
    public static void sendEmail(String from,
                                 List emailAddrs,
                                 String subject,
                                 String message,
                                 boolean showStatus)
        throws Exception {
        int n = emailAddrs.size();
        int chunk = (int) Math.ceil((double) n / 72.0); // chunks per 72 chr wide
        for (int i = 0; emailAddrs != null && i < emailAddrs.size(); i++) {
            String email = (String) emailAddrs.get(i);
            try {
                if (showStatus && i % chunk == 0) {
                    System.out.print('.');
                }
                sendEmail(from,
                          email,
                          subject,
                          message);
            }
            catch (Exception ee) {
                if (!email.equals("parrt@jguru.com")) {
                    try {
                        sendEmail(
                            from,
                            "parrt@jguru.com",
                            "Error running thread notification",
                            "Exception in sendEmail: " + ee + "; i'll keep going though");
                    }
                    catch (Exception eee) {
                        // crap out; error even to parrt
                        ErrorService.error("error in sendEmail: can't even email parrt about a problem", eee);
                    }
                }
                else {
                    ErrorService.error("error in sendEmail", ee);
                }
            }
        }
        if (showStatus) {
            System.out.println();
        }
    }

    public static void sendEmail(String to,
                                 String subject,
                                 String message)
        throws Exception {
        sendEmailWithBcc("notifications@peerscope.com", to, null, subject, message);
    }

    public static void sendEmail(String from,
                                 String to,
                                 String subject,
                                 String message)
        throws Exception {
        sendEmailWithBcc(from, to, null, subject, message);
    }

    public static void sendEmailWithBcc(String to,
                                        String bcc,
                                        String subject,
                                        String message)
        throws Exception {
        sendEmailWithBcc("notifications@peerscope.com", to, bcc, subject, message);
    }

    /** second to last stop before mail goes out...checks for smtp server failure. */
    public static void sendEmailWithBcc(String from,
                                        String to,
                                        String bcc,
                                        String subject,
                                        String message)
        throws Exception {
        String failoverServer = null;
        String smtpServer = getSMTPServer();
        try {
            rawSendmail(smtpServer, from, to, bcc, subject, message);
        }
        catch (Exception e) {
            String msg = e.getMessage();
            System.out.println("error during send mail: " + msg);
            if (msg!=null && msg.indexOf("SMTPClient.Connect") >= 0) {
                System.out.println("smtp " + smtpServer + " failed, trying failover");
                // can't connect to the smtp server
                failoverServer = getSMTPFailoverServer();
                if (failoverServer == null) {
                    System.out.println("no failover smtp throwing exception");
                    // hm...no failover
                    throw e;
                }
            }
            else {
                // don't recognize, rethrow
                throw e;
            }
            // retry to failover
            rawSendmail(failoverServer, from, to, bcc, subject, message);
        }
    }

    private static void rawSendmail(String smtpServer,
                                    String from,
                                    String to,
                                    String bcc,
                                    String subject,
                                    String message)
        throws Exception {
        if ( !((alwaysContact!=null && alwaysContact.contains(to)) || isTestMode()) )
        {
            listener.simulated(from, to, subject, message);
            return;
        }
        if (bcc == null) {
            org.pageforge.lib.service.SMTPClient.sendmail(smtpServer,
                                                      from,
                                                      to,
                                                      subject,
                                                      message);
        }
        else {
            Vector toV = new Vector();
            Vector bccV = new Vector();
            toV.add(to);
            bccV.add(bcc);
            org.pageforge.lib.service.SMTPClient.sendmail(smtpServer,
                                                      from,
                                                      toV,
                                                      null,
                                                      bccV,
                                                      subject,
                                                      message);
        }
        listener.log(from, to, subject, message);
    }
}
