/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.service;

import java.io.*;
import javax.servlet.http.HttpServletRequest;

/** Examples of what you might track in your server. */
public class StatsService {
    protected static final String loginEventStream = "login";
    protected static final String guestLoginEventStream = "guestlogin";
    protected static final String personalizationEventStream = "personalization";
    protected static final String trampolineEventStream = "trampoline";
    protected static final String pageViewEventStream = "pageview";
    protected static final String searchEventStream = "search";

    // S T A T S  L O G G I N G

    public static void login(String personID)
    {
        String msg = "\t"+personID;
        LogService.log("login", msg);
    }

    public static void guestLogin(String uniqueID) throws IOException {
        LogService.log("guestlogin", "\t"+uniqueID);
    }

    public static void trampoline(String source,
                                  String target)
    {
        trampoline(source, target, null);
    }

    public static void trampoline(String source,
                                  String target,
                                  String arrivedFromOffsite)
    {
        if ( arrivedFromOffsite==null ) {
            arrivedFromOffsite = ".";
        }
        if ( source != null ) {
            LogService.log("trampoline",
                           "\t"+target+
                           "\t"+source+
                           "\t"+arrivedFromOffsite);
        }
        else {
            LogService.log("trampoline",
                           "\t"+target+
                           "\t."+
                           "\t"+arrivedFromOffsite);
        }
    }

    /** Record a page view. */
    public static void pageView(HttpServletRequest request,
                                String url)
    {
        String agent = ".";
        String ua = request.getHeader("User-Agent");
        if ( ua!=null && ua.toLowerCase().indexOf("googlebot")>-1 ) {
            agent = "googlebot";
        }
        int i = url.indexOf("&noCache");
        if ( i!=-1 ) {
            url = url.substring(0,i); // remove &noCache
        }
        LogService.log( "pageview",
                        "\t"+url+
                        "\t"+agent);
    }

    public static void search(String srch, String scope, int offset)
    {
        if ( scope==null || scope.length()==0 ) {
            scope = ".";
        }
        if ( offset>0 ) {
            LogService.log("search",
                           "\t"+srch+"\t"+scope+"\t"+offset);
        }
        else {
            LogService.log("search",
                           "\t"+srch+"\t"+scope);
        }
    }

}
