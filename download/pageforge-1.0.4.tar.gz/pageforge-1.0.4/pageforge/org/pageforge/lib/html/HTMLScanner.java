/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.html;

/** Scan HTML in a String looking for substrings of interest like links, titles.
 *  Example:
 *
 * 		HTMLScanner scanner = new HTMLScanner(webPageContents);

        scanner.skipPastText("WHAT'S NEW");
        int endIndex = scanner.indexOfText("<TABLE");

		int n = 0;
        while ( scanner.getCurrentIndex() < endIndex ) {
			scanner.skipPastText("<P>");
			if ( scanner.getCurrentIndex() >= endIndex ) {
				break; // we're done.
			}
			scanner.skipPastText("<A HREF=\"");
			String link = scanner.scarfToText("\"");
			if ( !link.startsWith("http://") ) {
				link = base+link;
			}
			scanner.skipPastText("\">");
			String title = scanner.scarfToTag("</A>");
			scanner.skipPastText("</A>");
			String description=scanner.scarfToText("<P>");
			rv.addElement(new CommonSearchResult(title,description,link));
			n++;
		}

 */
public class HTMLScanner {

    /** holds HTML text to be scanned */
    protected String htmlText;

    /** position pointer */
    protected int pointer = 0;

    public HTMLScanner(String _htmlText) {
        htmlText=_htmlText;
    }

    /** no-arg constructor is for serialization */
    protected HTMLScanner() { }

    /** reset pointer */
    public void resetPointer() {
		pointer = 0;
    }

	public int getCurrentIndex() {
		return pointer;
	}

    public String getCurrentLookahead(int n) {
        StringBuffer buf = new StringBuffer(n);
        for (int i=pointer; i<pointer+n && i<htmlText.length(); i++) {
			char ch = htmlText.charAt(i);
            buf.append(ch);
        }
        return buf.toString();
    }

	public void setCurrentIndex(int i) {
		pointer = i;
	}

    public boolean skipPastTextIfNextIgnoreCase(String t) throws Exception {
        if ( t==null ) {
            return false;
        }
        // do we have room to skip?
        if ( (pointer+t.length())>=htmlText.length() ) {
            throw new Exception("skipPastTextIfPresentIgnoreCase: would jump past end of string");
        }
        if ( htmlText.substring(pointer, pointer+t.length()).equalsIgnoreCase(t) ) {
            pointer += t.length();
            return true;
        }
        return false;
    }

    public void skipPastNextWhiteSpace() throws Exception {
        while ( pointer<htmlText.length() &&
                Character.isWhitespace(htmlText.charAt(pointer)) ) {
            pointer++;
        }
    }

    public void skipPastTag(String tag) throws Exception {
        if (!tag.startsWith("<")) {
            throw new Exception(
                "skipPastTag requires < as the start of string, got "+tag);
		}
		if (tag.endsWith(">")) {
			/*throw new Exception(
			  "Don't end skipPastTag tag with >, got "+tag);*/
			tag = tag.substring(0, tag.length()-1);
		}
		skipPastTextIgnoreCase(tag);
		skipPastText(">");
    }

    public String scarfToTag(String tag) throws Exception {
		if (!tag.startsWith("<")) {
            throw new Exception(
                "scarfToTag requires < as the start of string, got "+tag
            );
		}
		int startIndex = pointer;
		skipToTextIgnoreCase(tag);
		String s =  htmlText.substring(startIndex,pointer);
		return s;
    }

    public String substring(int start, int end) {
        return htmlText.substring(start,end);
    }

    /** skip to given tag.
     *  For example: skipToTextIgnoreCase("<a");
     *  would skip to < of <A fwsgs="sii">
     */
    public void skipToTextIgnoreCase(String text)
		throws Exception
    {
        int index = indexOfTextIgnoreCase(text);
        if(index == -1) {
            throw new Exception("skip To Text Ignore Case failed: " + text);
        }
        else {
            pointer = index;
        }
    }

    public void skipPastTextIgnoreCase(String text)
		throws Exception
	{
		skipPastTextIgnoreCase(text, true);
	}

    public void skipPastTextIgnoreCase(String text, boolean genErrorUponEOF)
		throws Exception
	{
		int index = indexOfTextIgnoreCase(text);
		if( index == -1) {
			if ( genErrorUponEOF ) {
				throw new Exception("skip Past Text Ignore Case failed: " + text);
			}
			else {
				pointer = htmlText.length();
			}
		}
		else {
			pointer = index + text.length();
		}
    }

    public int indexOfText(String text) {
		if ( htmlText==null ) {
			return -1;
		}
		return htmlText.indexOf(text,pointer);
	}

    public int indexOfTextIgnoreCase(String tag)
		throws Exception
    {
		return indexOfTextIgnoreCase(tag, 1);
	}

	/** Find the start of the tag text, direction>=0 means forward,
	 *  else looks backwards from current pointer.
	 */
    public int indexOfTextIgnoreCase(String tag, int direction)
		throws Exception
    {
        int tagCharIndex=0;
        int pointerIndex=pointer;
        do {
			char tagCh = Character.toLowerCase( tag.charAt(tagCharIndex) );
			char ch = Character.toLowerCase( htmlText.charAt(pointerIndex) );

			if (tagCh==ch) {
				if ( htmlText.substring(pointerIndex,pointerIndex+tag.length())
					   .equalsIgnoreCase( tag )
					 )
					{
						return pointerIndex;
					}
			}

			if ( direction>=0 ) {
				pointerIndex++;
			}
			else {
				pointerIndex--;
			}

        } while (pointerIndex>=0 && (pointerIndex+tag.length()) < htmlText.length());
        return -1;
    }

    /** skip the pointer to the given text. */
    public void skipToText(String text) throws Exception {
		int index = htmlText.indexOf(text, pointer);
		if(index == -1) {
			throw new Exception("skip To Text failed: " + text);
		}
		else {
			pointer = index;
		}
    }


    /** skip the pointer to just after the given text.
		Returns false if the text is not found,
		and reports a fatal error.
    */
    public void skipPastText(String text) throws Exception {
		int index = htmlText.indexOf(text,pointer);
		if(index == -1) {
			throw new Exception("skip Past Text failed: " + text);
		}
		else {
			pointer = index + text.length();
		}
    }

    /** What is the line number at index. */
    public int getLineAtIndex(int index) throws Exception {
		char ch = htmlText.charAt(0);
		int line = 1;
		for (int i=0; i < index; i++) {
			ch = htmlText.charAt(i);
			if (ch=='\n') {
				line++;
			}
			if (ch=='\r') {
				line++;

				if (i+1>=htmlText.length()) { break; }
				ch = htmlText.charAt(i);
				if (ch=='\n') {
					i++;
				}
			}
		}
		return line;
    }

    /** Get current line. Mostly for debugging purposes.
     * Cut very long lines at some point.
	 */
    public String getCurrentLine() throws Exception {
        int startI = 0;
        int endI = 0;
        char ch = htmlText.charAt(pointer);
        while ((ch!='\n') && (ch!='\r')) {
			if (pointer-startI == 0) { break; }
			ch = htmlText.charAt(pointer-startI);
			startI++;
        }
        ch = htmlText.charAt(pointer);
        while ((ch!='\n') && (ch!='\r')) {
			if (endI > 1000) { break; }
			ch = htmlText.charAt(pointer+endI);
			endI++;
        }
        return htmlText.substring(pointer-startI, pointer+endI);
    }


    /** skip num steps forward */
    public void skip(int num) {
		pointer += num;
    }


    /** grab the text from the current pointer position
		to the next position.  If the given text is not found,
		null is returned, and a fatal error is reported. */
    public String scarfToText(String text) throws Exception {
		int index = htmlText.indexOf(text,pointer);
		if(index == -1) {
			throw new Exception("scarf To Text failed: " + text);
		}
		else {
			String result = htmlText.substring(pointer,index);
			pointer = index;
			return result;
		}
    }

    public String scarfToTextIgnoreCase(String text) throws Exception {
		int index = indexOfTextIgnoreCase(text);
		if (index == -1) {
			throw new Exception("scarf To Text (ignoring case) failed: " + text);
		}
		else {
			String result = htmlText.substring(pointer,index);
			pointer = index;
			return result;
		}
    }


    /** same as scarfToText, but pointer is incremented
		past text scarfed to.
    */
    public String scarfToTextAndSkip(String text) throws Exception {
		String result = scarfToText(text);
		pointer += text.length();
		return result;
    }

}
