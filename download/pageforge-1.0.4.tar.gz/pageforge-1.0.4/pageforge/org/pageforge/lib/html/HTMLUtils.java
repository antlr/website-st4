/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.html;

import org.pageforge.support.Utils;

import java.io.*;

public class HTMLUtils {
    /** Strip all tags and char escapes from text.  This
     *  handles '>' inside a comment; doesn't terminate comment early ;)
     */
    public static String stripHTML(String text) {
        return stripHTML(text, false);
    }

    public static String stripHTML(String text, boolean stripPRE) {
        StringBuffer buf = new StringBuffer(text.length());
        int i = 0;
        while ( i < text.length() ) {
            if ( (i+3)<text.length() &&
                text.charAt(i)=='<' &&
                text.charAt(i+1)=='!' &&
                text.charAt(i+2)=='-' &&
                text.charAt(i+3)=='-' )
            {
                // found a comment
                // System.out.println("found a comment at char="+i);
                i+=3; // skip <!--
                String cmt = "";
                while ( (i+2)<text.length() &&
                    !(text.charAt(i)=='-' &&
                    text.charAt(i+1)=='-' &&
                    text.charAt(i+2)=='>') )
                {
                    cmt += text.charAt(i);
                    i++;
                }
                i+=3; // skip '-->'
                // System.out.println("exit comment at "+i+": "+cmt);
            }
            else if ( text.charAt(i)=='<' ) {
                i++;
                // toss out tag
                StringBuffer tagName = new StringBuffer(20);
                while ( i<text.length() && text.charAt(i)!='>' ) {
                    tagName.append(text.charAt(i));
                    i++;
                }
                i++; // skip '>'
                if ( buf.length()>0 &&
                    !Character.isWhitespace(buf.charAt(buf.length()-1)) )
                {
                    // make sure we don't glom words together
                    buf.append(' ');  // add whitespace if none prior
                }
                // System.out.println("tagName finished at "+(i-1)+": "+tagName.toString());
                String name = tagName.toString().toUpperCase();
                if ( name.startsWith("SCRIPT") ) {
                    // kill til end tag
                    // System.err.println("Found <SCRIPT");
                    int endScript = text.indexOf("</SCRIPT>", i);
                    if ( endScript>=i ) {
                        // System.err.println("found end tag at "+endScript);
                        i = endScript+"</SCRIPT>".length();
                        // System.err.println("i reset to "+i);
                    }
                }
                else if ( name.startsWith("A") && name.indexOf("HREF=")>0 ) {
                    int endref = Utils.indexOfTextIgnoreCase(text, "</A>", i);
                    if ( endref>=0 ) { // is there an end tag anywhere
                        int nextLink = Utils.indexOfTextIgnoreCase(text, "<A", i);
                        if ( nextLink>=0 && nextLink<endref ) {
                            // if there is another link start before the end </a>
                            // just scarf the <a ...> tag and keep going.
                            i = nextLink;
                        }
                        else if ( (endref-i)<=200 ) {
                            // don't look too far ahead; handle missing </a>
                            buf.append(text.substring(i,endref));
                            i = endref+"</A>".length();
                        }
                    }
                }
                else if ( stripPRE && name.startsWith("PRE") ) {
                    int endScript = text.indexOf("</PRE>", i);
                    int endScript2 = text.indexOf("</pre>", i);
                    if ( endScript>=i ) {
                        i = endScript+"</PRE>".length();
                    }
                    else if ( endScript2>=i ) {
                        i = endScript2+"</PRE>".length();
                    }
                }
                else if ( name.startsWith("FORM") ) {
                    int endScript = Utils.indexOfTextIgnoreCase(text, "</form>", i);
                    if ( endScript!=-1 ) {
                        // scarf til end of form if present.
                        i = endScript+"</form>".length();
                    }
                }
                else if ( name.startsWith("HEAD") ) {
                    int endScript = text.indexOf("</HEAD>", i);
                    int endScript2 = text.indexOf("</head>", i);
                    if ( endScript>=i ) {
                        i = endScript+"</HEAD>".length();
                    }
                    else if ( endScript2>=i ) {
                        i = endScript2+"</HEAD>".length();
                    }
                }
                else if ( name.startsWith("STYLE") ) {
                    int endScript = text.indexOf("</STYLE>", i);
                    int endScript2 = text.indexOf("</style>", i);
                    if ( endScript>=i ) {
                        i = endScript+"</STYLE>".length();
                    }
                    else if ( endScript2>=i ) {
                        i = endScript2+"</STYLE>".length();
                    }
                }
            }
            else if ( (text.charAt(i)=='&'&&(i+5)<text.length()&&text.charAt(i+1)=='#'&&text.charAt(i+5)==';') ||
                (text.charAt(i)=='&'&&(i+4)<=text.length()&&
                (text.substring(i,i+4).equals("&lt;")||
                text.substring(i,i+4).equals("&gt;"))) ||
                (text.charAt(i)=='&'&&(i+5)<=text.length()&&
                text.substring(i,i+5).equals("&amp;")) ||
                (text.charAt(i)=='&'&&(i+6)<=text.length()&&
                text.substring(i,i+6).equals("&quot;")) ||
                (text.charAt(i)=='&'&&(i+6)<=text.length()&&
                text.substring(i,i+6).equals("&nbsp;")) ) {
                // System.out.println("kill from "+text.substring(i,i+3));
                i++;
                // toss out "&blort;"
                while ( i<text.length() && text.charAt(i)!=';' ) {
                    i++;
                }
                i++; // skip ';'
            }
            else if ( Character.isWhitespace(text.charAt(i)) ) {
                // scarf whitespace, leaving a single space
                while ( i<text.length() && Character.isWhitespace(text.charAt(i)) ) {
                    i++;
                }
                if ( buf.length()>0 &&
                    !Character.isWhitespace(buf.charAt(buf.length()-1)) )
                {
                    buf.append(' ');  // add whitespace if none prior
                }
            }
            else {
                buf.append( text.charAt(i) );
                i++;
            }
        }
        return buf.toString();
    }

    /**
     if there is a <![CDATA[, then return the
     stuff inside the tag (terminated by ]]>,
     otherwise, return the string
     */
    public static String stripCData(String data) {
        int cdIndex = data.indexOf("<![CDATA[");
        if(cdIndex == -1) {
            return data;
        } else {
            int cdEndIndex = data.indexOf("]]>");
            if(cdEndIndex == -1) {
                return data.substring(cdIndex+9, data.length());
            } else {
                return data.substring(cdIndex+9, cdEndIndex);
            }
        }
    }

    /** Textarea HTML entities need to have the & char escaped to
     *  &amp; so they appear correctly.  HTML tags seem to stay ok.
     */
    public static String escapeAmpersands(String text) {
        if ( text==null || text.length()==0 ) {
            return text;
        }
        StringBuffer buf = new StringBuffer(500);
        for (int i=0; i<text.length(); i++) {
            if ( text.charAt(i)=='&' ) {
                buf.append("&amp;");
            }
            else {
                buf.append(text.charAt(i));
            }
        }
        return buf.toString();
    }

    public static String escapeHTML(String s) {
        return escapeHTML(s, false);
    }

    public static String escapeHTML(String s, boolean escapeCharEntities) {
        if ( s==null ) {
            return null;
        }
        StringBuffer result = new StringBuffer( s.length() );
        int len = s.length();
        for (int i=0; i<len; i++) {
            char ch = s.charAt(i);
            if (ch=='&') {
                //System.out.println("i: "+i);
                int semiIndex = s.indexOf(';',i);
                //System.out.println("semiIndex: "+semiIndex);
                if (semiIndex > 0) {
                    String entity = s.substring(i, semiIndex+1);
                    entity = entity.toLowerCase();
                    boolean b = false;
                    if(!escapeCharEntities) {
                        b = ( (entity.compareTo("&lt;")==0)
                              || (entity.compareTo("&gt;")==0)
                              || (entity.compareTo("&amp;")==0)
                              || (entity.compareTo("&quot;")==0)
                              || (entity.compareTo("&apos;")==0)
                              || (entity.startsWith("&#"))
                              );
                    }
                    if (b) {
                        i += semiIndex - i;
                        result.append( entity );
                    } else {
                        // result.append("&amp;");
                        result.append('&');
                    }
                }
                else {
                    //result.append("&amp;");
                    result.append('&');
                }
            } else if (ch=='<') {
                result.append("&lt;");
            } else if (ch=='>') {
                result.append("&gt;");
            }
            /*
              else if (ch=='\"') {
                result.append("&quot;");
            }
            */
            else {
                result.append(ch);
            }
        }
        return result.toString();
    }

    /** return a string suitable for inclusion as an html attribute
     *  between quotes.
     */
    public static String escapeForHTMLTagAttributeUse(String s) {
		return Utils.replace(s, "\"", "&quot;");
    }

	/** The following code written by Alex Chaffee.
	 *  Modified slightly by Terence Parr:
     *    changed name and removed code to use hash table for
	 *    smart escaping.
	 *
	 *  Referencing his license per agreement:
	 *
	 * ====================================================================
	 * Copyright (c) 1995-2000 Purple Technology, Inc. All rights
	 * reserved.
	 *
	 * PLAIN LANGUAGE LICENSE: Do whatever you like with this code, free
	 * of charge, just give credit where credit is due. If you improve it,
	 * please send your improvements to code@purpletech.com. Check
	 * http://www.purpletech.com/code/ for the latest version and news.
	 *
	 * LEGAL LANGUAGE LICENSE: Redistribution and use in source and binary
	 * forms, with or without modification, are permitted provided that
	 * the following conditions are met:
	 *
	 * 1. Redistributions of source code must retain the above copyright
	 * notice, this list of conditions and the following disclaimer.
	 *
	 * 2. Redistributions in binary form must reproduce the above
	 * copyright notice, this list of conditions and the following
	 * disclaimer in the documentation and/or other materials provided
	 * with the distribution.
	 *
	 * 3. The names of the authors and the names "Purple Technology,"
	 * "Purple Server" and "Purple Chat" must not be used to endorse or
	 * promote products derived from this software without prior written
	 * permission. For written permission, please contact
	 * server@purpletech.com.
	 *
	 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS AND PURPLE TECHNOLOGY ``AS
	 * IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
	 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
	 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
	 * AUTHORS OR PURPLE TECHNOLOGY BE LIABLE FOR ANY DIRECT, INDIRECT,
	 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
	 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
	 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
	 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
	 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
	 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
	 * OF THE POSSIBILITY OF SUCH DAMAGE.
	 *
	 * ====================================================================
	 *
	 **/
    public static String escapeUNICODE(String s1)
    {
        StringBuffer buf = new StringBuffer();
        int i;
        for (i=0; i<s1.length(); ++i) {
            char ch = s1.charAt(i);
            if (((int)ch) > 128) {
                buf.append("&#" + ((int)ch) + ";");
            }
            else {
                buf.append(ch);
            }
        }
        return buf.toString();
    }

    /** Return just the text in between &lt;body>...&lt;/body> from
     *  an html file contents.  Return the title (if found in &lt;title>...&lt;/title>)
     *  in the buffer argument.  If no <body> tag, return entire file and
     *  no title.
     */
    public static String getHTMLBody(String htmlFileContents,
                                     StringBuffer title)
        throws Exception
    {
        HTMLScanner scanner = new HTMLScanner(htmlFileContents);
        int indexOfTitle = scanner.indexOfTextIgnoreCase("<title>");
        title.setLength(0); // remove anything else in title buffer
        if ( indexOfTitle>=0 ) {
            scanner.skipPastTag("<title>");
            title.append(scanner.scarfToTag("</title>"));
        }
        int indexOfBody = scanner.indexOfTextIgnoreCase("<body");
        String body = null;
        if ( indexOfBody>=0 ) {
            scanner.skipPastTag("<body");
            body = scanner.scarfToTag("</body>");
        }
        else {
            title.setLength(0); // kill title; shouldn't be there w/o body tag
            body = htmlFileContents; // return entire file contents
        }

        return body;
    }

}
