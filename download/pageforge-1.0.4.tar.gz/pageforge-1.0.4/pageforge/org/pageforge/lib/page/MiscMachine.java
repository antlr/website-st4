/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.page;

import org.pageforge.PageStateMachine;
import org.pageforge.Page;
import org.pageforge.support.VerifyException;
import org.pageforge.support.FileUtils;
import org.pageforge.support.StreamBuffer;
import org.antlr.stringtemplate.*;
import org.pageforge.lib.service.EmailService;
import org.pageforge.lib.html.HTMLUtils;

/** A few common and useful pages for your site.  Many of these pages
 *  you'll have to modify to suit; all should be copied into a page
 *  state machine in your site.  These are not designed to be directly
 *  reused (yet?) by referencing this PageStateMachine.
 */
public class MiscMachine extends PageStateMachine {

    static {
        mapState("misc", "message", MessagePage.class, "misc/message");
        mapState("misc", "trampoline", TrampolinePage.class);
        mapState("misc", "contact", ContactPage.class, "misc/contact");
        mapState("misc", "password", RequestPasswordPage.class, "misc/request_password");
        mapState("misc", "get", AddLookNFeelToContentPage.class);
    }

    /** Any page in this machine is of this type */
    public static class MiscMachinePage extends Page {
        /** Do a type conversion for brevity in references.  Damn.  I'd prefer
         *  "state." intead of "state().", but strict typing prevents it.
         *  Must repeat this in every state machine. :(
         */
        protected MiscMachine state() { return (MiscMachine)state; }
    }

    /** An example trampoline page.  To trampoline you specify this as the
     *  link target instead of the actual target.  The actual target is
     *  a parameter.  This records the click-through and then redirects to
     *  the actual target.  For example, you could say:
     *
     * <a href="http://adserver.anAliasToYourSite.com/misc/trampoline?
     *    url=http%3A%2F%2Fwww6.software.ibm.com%2Freg%2Fdevworks%2Fdw-ls-wsprtl-i">
     *
     *  where I have broken the URL into multiple lines for readability.  Further,
     *  note that the url parameter must be URLEncoder.encode()'d.
     *
     *  The use of adserver.anAliasToYourSite.com helps prevent spiders from hitting
     *  your trampoline page, screwing up your stats.  You want
     *  anAliasToYourSite.com to be the same as YourSite.com, but since it
     *  jumps "off site", or appears to, spiders typically won't follow. :)
     */
    public static class TrampolinePage extends MiscMachinePage {
        public void generateBody(StringTemplate bodyST) throws Exception {
            requireParameter("url");
            String src = request.getParameter("src");
            String url = request.getParameter("url");

            if ( url==null ) {
                // log error("no url in trampoline");
                return;
            }
            String id = request.getRemoteAddr();

            /*
            StatsService.trampoline(id,
                                    src,
                                    url+jgurutrack);

            */
            response.sendRedirect(url); // jump to actual target
        }
    }

    public static class ContactPage extends MiscMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public String getTitle() { return "Contact YourSite.com"; }

        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("submit") ) {
                requireParameters(
                             new String[] {"name","comments","email"});
                String email = request.getParameter("email").trim().toLowerCase();
                String comments = request.getParameter("comments");
                String name = request.getParameter("name");

                String contactTarget = "your-site-contact-email@yoursite.com";

                EmailService.sendEmail(email,
                        contactTarget,
                        "yoursite.com contact",
                        name+" wrote:\n\n"+comments);

                doMessageRedirect("Your message concerning has been sent to the appropriate person.");
            }
            else if ( eventName.equals("cancel") ) {
                doRedirect("/");
            }
        }
    }

    public static class RequestPasswordPage extends MiscMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("submit") ) {
                requireParameter("email");
                String email = request.getParameter("email").trim().toLowerCase();
                /*
                StringTemplate message =
                    stringTemplatesLib.getInstanceOf("email/password");
                Member member = MemberService.instance().getMemberByEmail(email);
                if ( member==null ) {
                    doMessageRedirect("Sorry.  I don't have any accounts registered under "+
                                      email+".");
                    return;
                }
                String password = member.getPassword();
                message.setAttribute("password", password);
                message.setAttribute("member", member);

                EmailService.sendEmail("notifications@yoursite.com",
                        email,
                        "Your yoursite password",
                        message.toString());
                */
                doMessageRedirect("Your password has been sent to "+email+".");
            }
        }
        public String getTitle() { return "Request Password"; }
    }

    /** This is the page for displaying messages like confirmations etc... */
    public static class MessagePage extends MiscMachinePage {
        public void generateBody(StringTemplate bodyST) throws Exception {
            requireParameter("msg");
            String msg = request.getParameter("msg");
            bodyST.setAttribute("msg", msg);
        }

        public boolean mustBeLoggedIn() { return false; }

        public String getTitle() { return "Message page"; }
    }

    /** An example page that displays arbitrary HTML files within the look of
     *  your site.  In this example, I have hardcoded my doc root, but you
     *  would normally have this in your config stuff.  Note that this page
     *  effectively demonstrates the separation of URL's from actual file
     *  location.  For example, I use URL "http://yoursite.com/data/foo.html"
     *  but it actually loads from "/usr/local/site/lime/web/data/foo.html".
     *  To use this page, you need to ensure that your server sends all html
     *  pages to your PageDispatcher subclass and then you must override method
     *  PageDispatch.rewrite() like this:
     *       protected boolean rewrite(HttpServletRequest request,
     *                                 HttpServletResponse response)
     *           throws ServletException, IOException
     *       {
     *           // handle .html files
     *           String uri = request.getRequestURI().toLowerCase();
     *
     *           if ( uri.endsWith(".html") ) {
     *               forward("/misc/get?file="+
     *                       uri,
     *                       request,
     *                       response);
     *               return true;
     *           }
     *
     *           return false;
     *       }
     *
     *  This forwards all .html file GET requests to the /misc/get URL, which
     *  executes this page per our setup above:
     *         mapState("misc", "get", AddLookNFeelToContentPage.class);
     */
    public static class AddLookNFeelToContentPage extends MiscMachinePage {
        String title = null;
        String body = null;

        public void verify() throws VerifyException {
            requireParameter("file");
            // I'm hardcoding this root here for simplicity
            // Note that this root has nothing to do with the doc root
            // you set in your web server config.  It can literally point
            // anywhere.
            String documentRoot = "/usr/local/site/lime/data";
            String filename = request.getParameter("file");
            String completeFilename = documentRoot+filename;
            try {
                StringBuffer titleBuf = new StringBuffer(100);
                body = FileUtils.getHTMLFileBodyAndTitle(completeFilename, titleBuf);
                title = titleBuf.toString();
            }
            catch (Exception e) {
                throw new VerifyException("Problems extracting content/title from file "+
                                          filename+": "+HTMLUtils.escapeHTML(e.getMessage()));
            }
        }

        public void generateBody(StreamBuffer out) throws Exception {
            out.print(body);
        }

        public String getTitle() { return title; }
    }

}
