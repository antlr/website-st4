/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.pageforge.lib.page;

import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.io.*;

/** This servlet is an example you can subclass to suit your page tracking,
 *  ad tracking, etc...  For example, you might copy your subclass to /servlet
 *
 * <img width=0 height=0
 *      src="/servlet/org.pageforge.lib.page.YourSubclassOfLogPage?name=ad&company=oracle&loc=skyscraper">
 *
 *  Or, you could set the config of your server to map "/images/log.gif" to
 *  this servlet (better as you don't have to copy this servlet around).  Then
 *  you would use:
 *
 * <img width=0 height=0
 *      src="/images/log.gif?name=ad&company=oracle&loc=skyscraper">
 *
 *  Since spiders do not usually load images, this is a good way to track
 *  de-spidered page views or ad impressions.
 */
public class LogPageServlet extends HttpServlet {
    /** Define a simple, small blank GIF statically here so we don't have
     *  to look for an image file.
     */
    public static final byte[] spacerGIF = {
        0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00, 0x01, 0x00, (byte)0x80,
        0x00, 0x00, (byte)0xff, (byte)0xff, (byte)0xff, 0x00, 0x00, 0x00, 0x21,
        (byte)0xf9, 0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0x2c, 0x00, 0x00, 0x00,
        0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x02, 0x02, 0x44, 0x01, 0x00, 0x3b
    };
    protected static byte[] imageBuffer = spacerGIF;

    /** What to do with incoming data.  note you can nicely get all
     *  the args with request.getQueryString().
     */
    public void log(String logName, HttpServletRequest request) {
        // no logging by default
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        String logName = request.getParameter("name");
        if ( logName==null ) {
            return;
        }
        log(logName, request);

        // SEND AN IMAGE BACK
        response.setContentType("image/gif");
        OutputStream o = response.getOutputStream();
        o.write(imageBuffer,0,imageBuffer.length);
        o.flush();
        o.close();
    }
}
