/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

import org.pageforge.*;
import org.antlr.stringtemplate.*;

/** A sample submachine that is used for the home page.  The url
 *  will be /home/view and then HomeMachine.HomePage.generateBody() method will
 *  be invoked.  The mapState() method defines the machine, "home", and the
 *  state within, "view" plus what string template to use for that page,
 *  "home.content".  The file home.content.st will be searched for in
 *  the SamplePageForgeGlue.templateLib (in this case,
 *  "~parrt/sample/lib/templates/home.content.st".
 */
public class HomeMachine extends PageStateMachine {
    static {
        mapState("home", "view", HomePage.class, "home.content");
    }

    public static class HomePage extends SampleDefaultBehaviorPage {
        public void generateBody(StringTemplate bodyST) throws Exception {
            //requireParameter("name");
            String name = request.getParameter("name");
            if ( name==null ) {
                name = "anonymous";
            }
            bodyST.setAttribute("name", name);

/* UNCOMMENT to see your template hierarchy in a Swing GUI window
StringTemplateTreeView viz =
new StringTemplateTreeView("home",getPageStringTemplate());
viz.setVisible(true);
*/
        }

        public String getTitle() { return "Home page"; }
    }
}
