import org.antlr.stringtemplate.*;
import org.pageforge.*;

public class SampleDefaultBehaviorPage extends Page {
    public void setDefaultPageAttributes(StringTemplate pageST) {
	pageST.setAttribute("title", getTitle());
    }
}
