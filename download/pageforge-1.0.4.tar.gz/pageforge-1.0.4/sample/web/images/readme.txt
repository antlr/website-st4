Your images files go here.  All files are relative to the document root
as defined in the resin config (~parrt/sample/doc) in this sample.
image foo.gif in this dir will be /images/foo.gif via the server.
