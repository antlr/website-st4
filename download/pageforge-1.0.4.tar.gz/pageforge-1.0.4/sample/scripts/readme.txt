It is useful to group scripts like start / stop in here or any
other scripts that look at logs or whatever.

When you run start, you should be able to jump to

http://localhost:8080/home/view

and have your home page show up.  If you get:

------------
500 Servlet Exception

javax.servlet.ServletException: Class `SamplePageDispatcher' was not found
in classpath.
...
------------

then you must make sure that ~parrt/sample/src is in your classpath.  For
example, add this to your .bash_profile:

export CLASSPATH="$CLASSPATH:/Users/parrt/sample/src"

If you get a blank page or another problem, look at /tmp/log/stderr.log, which
usually has a clue.  For example, you might not have your templates visible:

$ cat /tmp/log/stderr.log 
Can't load template page.st
Can't load template home.content.st
