/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.stringtemplate;

import java.io.*;
import java.util.*;

import org.antlr.stringtemplate.language.*;
import org.antlr.stringtemplate.language.*;
import antlr.*;
import antlr.collections.AST;

/** A <TT>StringTemplate</TT> is a "document" with holes in it where you can stick
 *  values.  <TT>StringTemplate</TT> breaks up your template into chunks of text and
 *  attribute expressions, which are by default enclosed in angle brackets:
 * <TT>&lt;</TT><em>attribute-expression</em><TT>&gt;</TT>.  <TT>StringTemplate</TT>
 * ignores everything outside of attribute expressions, treating it as just text to spit
 * out when you call <TT>StringTemplate.toString()</TT>.
 *
 *  <P><TT>StringTemplate</TT> is not a "system" or "engine" or "server"; it's a lib
rary with two classes of interest: <TT>StringTemplate</TT> and <TT>StringTemplat
eGroup</TT>.  You can directly create a <TT>StringTemplate</TT> in Java code or
you can load a template from a file.
<P>
A StringTemplate describes an output pattern/language like an exemplar.
 *  <p>
 *  StringTemplate and associated code is released under the BSD licence.  See
 *  source.  <br><br>
 *  Copyright (c) 2003 Terence Parr<br><br>

 *  A particular instance of a template may have a set of attributes that
 *  you set programmatically.  A template refers to these single or multi-
 *  valued attributes when writing itself out.  References within a
 *  template conform to a simple language with attribute references and
 *  references to other, embedded, templates.  The references are surrounded
 *  by user-defined start/stop strings (default of <...>, but $...$ works
 *  well when referencing attributes in HTML to distinguish from tags).
 *
 *  <p>StringTemplateGroup is a self-referential group of StringTemplate
 *  objects kind of like a grammar.  It is very useful for keeping a
 *  group of templates together.  For example, jGuru.com's premium and
 *  guest sites are completely separate sets of template files organized
 *  with a StringTemplateGroup.  Changing "skins" is a simple matter of
 *  switching groups.  Groups know where to load templates by either
 *  looking under a rootDir you can specify for the group or by simply
 *  looking for a resource file in the current class path.  If no rootDir
 *  is specified, template files are assumed to be resources.  So, if
 *  you reference template foo() and you have a rootDir, it looks for
 *  file rootDir/foo.st.  If you don't have a rootDir, it looks for
 *  file foo.st in the CLASSPATH.  note that you can use org/antlr/misc/foo()
 *  (qualified template names) as a template ref.
 *
 *  <p>StringTemplateErrorListener is an interface you can implement to
 *  specify where StringTemplate reports errors.  Setting the listener
 *  for a group automatically makes all associated StringTemplate
 *  objects use the same listener.  For example,
 *
 *  <font size=2><pre>
 *  StringTemplateGroup group = new StringTemplateGroup("loutSyndiags");
 *  group.setErrorListener(
 *     new StringTemplateErrorListener() {
 *        public void error(String msg, Exception e) {
 *           System.err.println("StringTemplate error: "+
 *               msg+((e!=null)?": "+e.getMessage():""));
 *        }
 *    }
 *  );
 *  </pre></font>
 *
 *  <p>IMPLEMENTATION
 *
 *  <p>A StringTemplate is both class and instance like in Self.  Given
 *  any StringTemplate (even one with attributes filled in), you can
 *  get a new "blank" instance of it.
 *
 *  <p>When you define a template, the string pattern is parsed and
 *  broken up into chunks of either String or attribute/template actions.
 *  These are typically just attribute references.  If a template is
 *  embedded within another template either via setAttribute or by
 *  implicit inclusion by referencing a template within a template, it
 *  inherits the attribute scope of the enclosing StringTemplate instance.
 *  All StringTemplate instances with the same pattern point to the same
 *  list of chunks since they are immutable there is no reason to have
 *  a copy in every instance of that pattern.  The only thing that differs
 *  is that every StringTemplate Java object can have its own set of
 *  attributes.  Each chunk points back at the original StringTemplate
 *  Java object whence they were constructed.  So, there are multiple
 *  pointers to the list of chunks (one for each instance with that
 *  pattern) and only one back ptr from a chunk to the original pattern
 *  object.  This is used primarily to get the group of that original
 *  so new templates can be loaded into that group.
 *
 *  <p>To write out a template, the chunks are walked in order and asked to
 *  write themselves out.  String chunks are obviously just written out,
 *  but the attribute expressions/actions are evaluated in light of the
 *  attributes in that object and possibly in an enclosing instance.
 */
public class StringTemplate {
    public static final String VERSION = "1.0";

    static boolean debugMode = false;

    /** track probable issues like setting attribute that is not referenced. */
    static boolean lintMode = false;

    protected List referencedAttributes = null;

	/** What's the name of this template? */
    protected String name = "anonymous";

    private static int templateCounter=0;
    private static synchronized int getNextTemplateCounter() {
        templateCounter++;
        return templateCounter;
    }

    protected int templateID = getNextTemplateCounter();

    /** Enclosing instance if I'm embedded within another template.
     *  IF-subtemplates are considered embedded as well.
     */
    protected StringTemplate enclosingInstance = null;

    /** If this template is an embedded template such as when you apply
     *  a template to an attribute, then the arguments passed to this
     *  template represent the argument context--a set of values
     *  computed by walking the argument assignment list.  For example,
     *  <name:bold(item=name, foo="x")> would result in an
     *  argument context of {[item=name], [foo="x"]} for this
     *  template.  This template would be the bold() template and
     *  the enclosingInstance would point at the template that held
     *  that <name:bold(...)> template call.  When you want to get
     *  an attribute value, you first check the attributes for the
     *  'self' template then the arg context then the enclosingInstance
     *  like resolving varables in pascal-like language with nested
     *  procedures.
     *
     *  With multi-valued attributes such as <faqList:briefFAQDisplay()>
     *  attribute "i" is set automatically.
     */
    protected Hashtable argumentContext = null;

    public StringTemplateAST getArgumentsAST() {
        return argumentsAST;
    }

    public void setArgumentsAST(StringTemplateAST argumentsAST) {
        this.argumentsAST = argumentsAST;
    }

    /** If this template is embedded in another template, the arguments
     *  must be evaluated just before each application when applying
     *  template to a list of values.  The "attr" attribute must change
     *  with each application so that $names:bold(item=attr)$ works.  If
     *  you evaluate once before starting the application loop then attr
     *  has a single fixed value.  Eval.g saves the AST rather than evaluating
     *  before invoking applyListOfAlternatingTemplates().  Each iteration
     *  of a template application to a multi-valued attribute, these args
     *  are re-evaluated with an initial context of {[attr=...], [i=...]}.
     */
    protected StringTemplateAST argumentsAST = null;

	/** What group originally defined the prototype for this template?
	 *  This affects the set of rules I can refer to.
	 */
	protected StringTemplateGroup group;

	/** Where to report errors */
    StringTemplateErrorListener listener = null;

	/** The original, immutable pattern/language (not really used again after
	 *  initial "compilation", setup/parsing).
	 */
    protected String pattern;

	/** Map an attribute name to its value(s).  These values are set by outside
	 *  code via st.setAttribute(name, value).  StringTemplate is like self in
     *  that a template is both the "class def" and "instance".  When you
     *  create a StringTemplate or setTemplate, the text is broken up into chunks
     *  (i.e., compiled down into a series of chunks that can be evaluated later).
     *  You can have multiple
	 */
    protected Hashtable attributes;

	/** A list of alternating string and ASTExpr references.
	 *  This is compiled to when the template is loaded/defined and walked to
	 *  write out a template instance.
	 */
    protected List chunks;

	protected static StringTemplateGroup defaultGroup =
		new StringTemplateGroup("defaultGroup", ".");

	/** Create a blank template with no pattern and no attributes */
	public StringTemplate() {
		group = defaultGroup; // make sure has a group even if default
        if ( debugMode ) debug("new StringTemplate():"+getTemplateID());
    }

	public StringTemplate(Hashtable initialValues) {
		this();
        if ( debugMode ) debug("new StringTemplate(initialValues):"+getTemplateID());
		attributes = initialValues;
		if ( attributes==null ) {
			attributes = new Hashtable();
		}
    }

	/** Create an anonymous template.  It has no name just
	 *  chunks (which point to this anonymous template) and attributes.
	 */
	public StringTemplate(String template) {
		this(null, template);
        if ( debugMode ) debug("new StringTemplate(template):"+getTemplateID());
    }

	/** Create an anonymous template with no name, but with a group */
	public StringTemplate(StringTemplateGroup group, String template) {
		this();
        if ( debugMode ) debug("new StringTemplate(group, ["+template+"]):"+getTemplateID());
		if ( group!=null ) {
			setGroup(group);
		}
		setTemplate(template);
   }

    /** Make the 'to' template look exactly like the 'from' template
     *  except for the attributes.  This is like creating an instance
     *  of a class in that the executable code is the same (the template
     *  chunks), but the instance data is blank (the attributes).  Do
     *  not copy the enclosingInstance pointer since you will want this
     *  template to eval in a context different from the examplar.
     */
    private void dup(StringTemplate from, StringTemplate to) {
        if ( debugMode ) debug("dup template ID "+from.getTemplateID()+" to get "+to.getTemplateID());
        to.pattern = from.pattern;
		to.chunks = from.chunks;
		to.name = from.name;
		to.group = from.group;
        to.listener = from.listener;
    }

    /** Return a copy of the template only; no hash tables */
	public StringTemplate getInstanceOf() {
		return getInstanceOfWithAttributes(null);
	}

    /** Make an instance of this template; it contains an exact copy of
     *  everything (except the attributes and enclosing instance pointer).
     *  So the new template refers to the previously compiled chunks of this
     *  template but does not have any attribute values.
     */
    public StringTemplate getInstanceOfWithAttributes(Hashtable initialValues) {
		if ( debugMode ) debug("getInstanceOfWithAttributes("+getName()+")");
        StringTemplate t = new StringTemplate(initialValues);
		dup(this, t);
		return t;
    }

    public void setEnclosingInstance(StringTemplate enclosingInstance) {
        this.enclosingInstance = enclosingInstance;
    }

    public Hashtable getArgumentContext() {
        return argumentContext;
    }

    public void setArgumentContext(Hashtable ac) {
        argumentContext = ac;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	public StringTemplateGroup getGroup() {
		return group;
	}

	public void setGroup(StringTemplateGroup group) {
		this.group = group;
	}

    public void setTemplate(String template) {
		this.pattern = template;
		breakTemplateIntoChunks();
    }

    public String getTemplate() {
		return pattern;
    }

	public void setErrorListener(StringTemplateErrorListener listener) {
		this.listener = listener;
	}

    public StringTemplateErrorListener getErrorListener() {
        if ( listener==null ) {
            return group.getErrorListener();
        }
        return listener;
    }

    public void reset() {
		attributes = new Hashtable(); // just throw out table and make new one
    }

	public void removeAttribute(String name) {
		attributes.remove(name);
    }

	/** Set an attribute for this template.  If you set the same
	 *  attribute more than once, you get a multi-valued attribute.
	 *  If you send in a StringTemplate object as a value, it's
	 *  enclosing instance (where it will inherit values from) is
	 *  set to 'this'.  This would be the normal case, though you
	 *  can set it back to null after this call if you want.
	 *  If you send in a List plus other values to the same
	 *  attribute, they all get flattened into one List of values.
     *  If you send in an array, it is converted to a List.  Works
     *  with arrays of objects and arrays of {int,float,double}.
	 */
	public void setAttribute(String name, Object value) {
		if ( debugMode ) debug(getName()+".setAttribute("+name+", "+value+")");
		if ( value==null ) {
			return;
		}
        if ( attributes==null ) {
            attributes = new Hashtable();
        }

        // convert value if array
        if ( value instanceof Object[] ) {
            value = Arrays.asList((Object[])value);
        }
        else if ( value instanceof int[] ) {
            int[] list = (int[])value;
            List v = new ArrayList(list.length);
            for (int i = 0; i < list.length; i++) {
                int elem = list[i];
                v.add(new Integer(elem));
            }
            value = v;
        }
        else if ( value instanceof float[] ) {
            float[] list = (float[])value;
            List v = new ArrayList(list.length);
            for (int i = 0; i < list.length; i++) {
                float elem = list[i];
                v.add(new Float(elem));
            }
            value = v;
        }

        else if ( value instanceof double[] ) {
            double[] list = (double[])value;
            List v = new ArrayList(list.length);
            for (int i = 0; i < list.length; i++) {
                double elem = list[i];
                v.add(new Double(elem));
            }
            value = v;
        }

		// get exactly in this scope (no enclosing)
		Object o = this.attributes.get(name);
		if ( o!=null ) { // it's a multi-value attribute
			//System.out.println("exists: "+name+"="+o);
			ArrayList v = null;
			if ( o instanceof ArrayList ) { // already a List
				v = (ArrayList)o;
				if ( value instanceof List ) {
					// flatten incoming list into existing
					// (do nothing if same List to avoid trouble)
					List v2 = (List)value;
					for (int i = 0; v!=v2 && i < v2.size(); i++) {
						// System.out.println("flattening "+name+"["+i+"]="+v2.elementAt(i)+" into existing value");
						v.add(v2.get(i));
					}
				}
				else {
					v.add(value);
				}
			}
			else {
				// second attribute, must convert existing to ArrayList
				v = new ArrayList(); // make list to hold multiple values
				rawSetAttribute(name, v); // make it pt to list now
				v.add(o);  // add previous single-valued attribute
				if ( value instanceof List ) {
					// flatten incoming list into existing
					List v2 = (List)value;
					for (int i = 0; i < v2.size(); i++) {
						v.add(v2.get(i));
					}
				}
				else {
					v.add(value);
				}
			}
		}
		else {
			rawSetAttribute(name, value);
		}
	}

	protected void rawSetAttribute(String name, Object value) {
		if ( debugMode ) debug(getName()+".rawSetAttribute("+name+", "+value+")");
		if ( value == null ) {
			return;
		}
		if ( value instanceof StringTemplate ) {
			((StringTemplate)value).setEnclosingInstance(this);
		}
		attributes.put(name, value);
	}

	public Object getAttribute(String name) {
		return get(this,name);
    }

    /** Walk the chunks, asking them to write themselves out according
	 *  to attribute values of 'this.attributes'.  This is like evaluating or
     *  interpreting the StringTemplate as a program using the
     *  attributes.  The chunks will be identical (point at same list)
     *  for all instances of this template.
	 */
	public void write(Writer out) throws IOException {
		for (int i=0; chunks!=null && i<chunks.size(); i++) {
			Expr a = (Expr)chunks.get(i);
			a.write(this, out);
		}
        if ( lintMode ) {
            checkForTrouble();
        }
	}

    /** Resolve an attribute reference.  It can be in three possible places:
     *
     *  1. the attribute list for the current template
     *  2. if self is an embedded template, somebody invoked us possibly
     *     with arguments--check the argument context
     *  3. if self is an embedded template, the attribute list for the enclosing
     *     instance
     */
    public static Object get(StringTemplate self, String attribute) {
		if ( self==null ) {
			return null;
		}
        if ( debugMode ) self.debug("get("+self.getName()+":"+self.getTemplateID()+", "+attribute+")");
        if ( debugMode ) self.debug("self.attributes="+self.attributes);

        if ( lintMode ) {
            self.trackAttributeReference(attribute);
        }

        // is it here?
        if ( self.attributes!=null ) {
            Object o = self.attributes.get(attribute);
            if ( o!=null ) {
                if ( debugMode ) self.debug("found it in self: "+o);
                return o;
            }
        }

        // nope, check argument context in case embedded
        Hashtable argContext = self.getArgumentContext();
        if ( argContext!=null && argContext.get(attribute)!=null ) {
            if ( debugMode ) self.debug("found it in arg context: "+argContext.get(attribute));
            return argContext.get(attribute);
        }

		// nope, check enclosingInstance if embedded
		if ( self.enclosingInstance!=null ) {
			return get(self.enclosingInstance, attribute);
		}
        if ( debugMode ) self.debug("couldn't find "+attribute+" in "+self.getName());
		return null;
    }

	/** Walk a template, breaking it into a list of
	 *  chunks: Strings and expressions.
	 */
	protected void breakTemplateIntoChunks() {
		// System.out.println("breakTemplateIntoChunks("+group.getTagStart()+","+group.getTagStop()+"): "+pattern);
		if ( chunks==null ) {
			chunks = new ArrayList();
		}
		StringBuffer chunk = new StringBuffer(100);
		int cp = 0;
		int sz = pattern.length();
		char ts = group.getDelimiterStart().charAt(0);
		int tslen = group.getDelimiterStart().length();
		char tstop = group.getDelimiterStop().charAt(0);
		int tstoplen = group.getDelimiterStop().length();
		int tagfound = 0;
		String ifStart = group.getDelimiterStart()+"if"; // <if(foo)> etc...
		String ifStop = ")"+group.getDelimiterStop();
		int islen = ifStart.length();
    parseTemplate:
		while ( cp<sz ) {  // for each char in template
			// STRING CHUNK
			if ( pattern.charAt(cp)!=ts ) {
				// scarf String chunk and add to overall chunks list
				while ( cp<sz && pattern.charAt(cp)!=ts ) {
					chunk.append(pattern.charAt(cp));
					cp++;
				}
				StringRef sr = new StringRef(chunk.toString());
				chunks.add(sr);
				chunk.setLength(0);
			}
			// IF CHUNK
			else if ( pattern.charAt(cp)==ts &&
				pattern.regionMatches(cp,ifStart,0,islen) ) {
				cp = parseIfChunk(cp,sz);
			}
			// ATTRIBUTE EXPRESSION CHUNK
			else if ( pattern.charAt(cp)==ts && // try to be efficient
				 pattern.regionMatches(cp,group.getDelimiterStart(),0,tslen) ) {
				cp = parseAttributeExpressionChunk(cp,sz);
			}
			// JUNK
			else {
				cp++; // unknown; just skip
			}
		}
	}

	protected int parseAttributeExpressionChunk(int cp, int sz) {
		StringBuffer stat = new StringBuffer(100);
		char ts = group.getDelimiterStart().charAt(0);
		int tslen = group.getDelimiterStart().length();
		char tstop = group.getDelimiterStop().charAt(0);
		int tstoplen = group.getDelimiterStop().length();
		cp += tslen;			// ignore the delim start
		boolean matchingExpr = true;
		while ( matchingExpr && cp < sz) {
			if ( pattern.charAt(cp)==tstop &&
				 pattern.regionMatches(cp,group.getDelimiterStop(),0,tstoplen) ) {
				matchingExpr = false;
			}
            else if ( pattern.charAt(cp)=='"' ) {
				// scarf entire string before continuing to look for end tag
				cp++;
				stat.append( '"' );
				while ( pattern.charAt(cp)!='"' ) {
					if ( pattern.charAt(cp)=='\\' ) {
						stat.append( pattern.charAt(cp) );
						cp++; // Allow escaped quote
					}
					stat.append( pattern.charAt(cp) );
					cp++;
				}
				stat.append( '"' );
				cp++; // skip last quote
			}
            else if ( pattern.charAt(cp)=='{' ) {
				// scarf entire anonymous before continuing to look for end delimiter
                // we'll deal with stuff within later in a nested fashion
				cp++;
				stat.append( '{' );
				while ( pattern.charAt(cp)!='}' ) {
					if ( pattern.charAt(cp)=='\\' ) {
						stat.append( pattern.charAt(cp) );
						cp++; // Allow escaped }
					}
					stat.append( pattern.charAt(cp) );
					cp++;
				}
				stat.append( '}' );
				cp++; // skip last curly
			}
			else {
				stat.append( pattern.charAt(cp) );
				cp++;
			}
		}
		if ( cp>=sz ) {
			error("end delimiter '"+group.getDelimiterStop()+"' not found in template for delimiter starting at index "+cp);
			return sz;
		}
		cp += group.getDelimiterStop().length(); // ignore the delim stop
		ASTExpr a = parseAction(stat.toString());
		if ( a!=null ) {
			chunks.add(a);
		}
		return cp;
	}

	/** Go get the if-chunk, nested template, and endif-chunk.  Leave
	 *  the parsing of if-chunk to parser, but get the pieces.  We can't
	 *  have ANTLR parse this as start/stop char are variables, making it
	 *  slow (would have to use semantic predicates on each char etc...).
     *
     *  The <endif> has to be tracked with a stack nowadays since
     *  I've expanded what an expression can be:
     *
     *  <if(x!=y)> foo <endif>
     *
     *  The subtemplates of conditionals are precompiled when I create
     *  the embedded subtemplate at end of method.
	 */
	protected int parseIfChunk(int cp, int sz) {
		StringBuffer ifchunk = new StringBuffer(100);
		StringBuffer chunk = new StringBuffer(1024);
		char ts = group.getDelimiterStart().charAt(0);
		String ifStop = group.getDelimiterStop();
		int istoplen = ifStop.length();
		char istop = ifStop.charAt(0);

        // grab the conditional expression from the IF action
		cp += group.getDelimiterStart().length();	// ignore the delim start
        int endIFtag = pattern.indexOf(ifStop,cp);
		if ( endIFtag>=sz ) {
			error("end not found for IF action in template starting at index "+cp);
			return sz;
		}
		// we have the tag now
        ifchunk.append(pattern.substring(cp,endIFtag));
        cp = endIFtag;
		cp += group.getDelimiterStop().length(); // jump over the delim stop

		// strip exactly one newline if immediately following <if(var)>
		if ( pattern.charAt(cp)=='\n' ) {
			cp++;
		}
        int endifIndex = findEndif(cp, sz);
        if ( endifIndex>=sz ) {
            return sz;
        }
        // got it end, add to chunk
        chunk.append(pattern.substring(cp,endifIndex));
        cp = endifIndex; // jump past end of endif
        if ( pattern.charAt(cp-1)=='\n' ) {  // remove a \n before endif
            chunk.setLength( chunk.length()-1 );
        }
        cp += "<endif>".length();

        // cp points to char following endif now.
        if ( debugMode ) {
            debug("conditional "+ifchunk.toString()+", chunk='"+
						   chunk.toString()+"'");
        }

		ConditionalExpr c = (ConditionalExpr)parseAction(ifchunk.toString());
		if ( c!=null ) {
            // create and precompile a subtemplate
			StringTemplate subtemplate =
				new StringTemplate(group,chunk.toString());
            subtemplate.setEnclosingInstance(this);
            subtemplate.setName(ifchunk+" chunk");
			c.setSubTemplate(subtemplate);
			chunks.add(c);
		}

		return cp;
	}

    /** Return the index of the appropriately nested <endif> for current IF.
     *  The cp comes in at the first char beyond the <if(expr)> action.
     */
    private int findEndif(int cp, int sz) {
        char ts = group.getDelimiterStart().charAt(0);
        int level = 0;
        String ifStart = group.getDelimiterStart()+"if("; // "<if("
        int islen = ifStart.length();
        String endif =
            group.getDelimiterStart()+"endif"+group.getDelimiterStop();
        int endiflen = endif.length();
        // grab conditional chunk. Scarf til endif @ level 0
        while ( cp<sz ) {
            if ( pattern.charAt(cp)==ts ) {
                if ( pattern.regionMatches(cp,endif,0,endiflen) ) {
                    if ( level==0 ) {
                        // found matching <endif>, return index
                        return cp;
                    }
                    // else, a nested one; drop level by one and continue
                    level--;
                    cp += endiflen;
                }
                else if ( pattern.regionMatches(cp,ifStart,0,islen) ) {
                    // found another IF, jump over and bump nesting level
                    cp += islen;
                    int e = pattern.indexOf(group.getDelimiterStop(), cp);
                    if ( e>=sz ) {
                        error("end of IF not found for IF action in template starting at index "+cp);
                        return sz;
                    }
                    cp = e;
                    level++;
                }
            }
            cp++;
        }
        error("endif not found for IF action in template starting at index "+cp);
        return sz;
    }

    private ASTExpr parseAction(String action) {
		StringTemplateLanguageLexer lexer =
			new StringTemplateLanguageLexer(new StringReader(action.toString()));
		StringTemplateLanguageParser parser =
			new StringTemplateLanguageParser(lexer, this);
        parser.setASTNodeClass("org.antlr.stringtemplate.language.StringTemplateAST");
		ASTExpr a = null;
		try {
			Hashtable options = parser.action();
            AST tree = parser.getAST();
            if ( tree!=null ) {
                if ( tree.getType()==StringTemplateLanguageParser.CONDITIONAL ) {
                    a = new ConditionalExpr(tree);
                }
                else {
                    a = new ASTExpr(tree,options);
                }
            }
		}
		catch (RecognitionException re) {
			error("Can't parse chunk: "+action.toString(), re);
		}
		catch (TokenStreamException tse) {
			error("Can't parse chunk: "+action.toString(), tse);
		}
		return a;
	}

    public int getTemplateID() {
        return templateID;
    }

    public Hashtable getAttributes() {
        return attributes;
    }

    public void setAttributes(Hashtable attributes) {
		this.attributes = attributes;
	}

	// U T I L I T Y  R O U T I N E S

    public void error(String msg) {
        error(msg, null);
    }

    public void warning(String msg) {
        if ( getErrorListener()!=null ) {
            getErrorListener().warning(msg);
        }
        else {
            System.err.println("StringTemplate: warning: "+msg);
        }
    }

    public void debug(String msg) {
        if ( getErrorListener()!=null ) {
            getErrorListener().debug(msg);
        }
        else {
            System.err.println("StringTemplate: debug: "+msg);
        }
    }

	public void error(String msg, Exception e) {
		if ( getErrorListener()!=null ) {
			getErrorListener().error(msg,e);
		}
		else {
			if ( e!=null ) {
                System.err.println("StringTemplate: error: "+msg+": "+e.getMessage());
            }
            else {
                System.err.println("StringTemplate: error: "+msg);
            }
		}
    }

    /** Make StringTemplate check your work as it evaluates templates.
     *  Problems are sent to error listener.   Currently warns when
     *  you set attributes that are not used.
     */
    public static void setLintMode(boolean lint) {
        StringTemplate.lintMode = lint;
    }

    public static boolean inLintMode() {
        return lintMode;
    }

    public static boolean isDebugMode() {
        return debugMode;
    }

    public static void setDebugMode(boolean debug) {
        StringTemplate.debugMode = debug;
    }

    /** Indicates that 'name' has been referenced in this template. */
    protected void trackAttributeReference(String name) {
        if ( referencedAttributes==null ) {
            referencedAttributes = new ArrayList();
        }
        referencedAttributes.add(name);
    }

    /** Executed after evaluating a template.  For now, checks for setting
     *  of attributes not reference.
     */
    public void checkForTrouble() {
        // we have table of set values and list of values referenced
        // compare, looking for SET BUT NOT REFERENCED ATTRIBUTES
        if ( attributes==null ) {
            return;
        }
        Enumeration names = attributes.keys();
        // if in names and not in referenced attributes, trouble
        while ( names.hasMoreElements() ) {
            String name = (String)names.nextElement();
            if ( referencedAttributes!=null &&
                !referencedAttributes.contains(name) )
            {
                warning(getName()+": set but not used: "+name);
            }
        }
        // can do the reverse, but will have lots of false warnings :(
    }

    public String toDebugString() {
        return chunks.toString();
    }

	public String toString() {
		StringWriter buf = new StringWriter();
		try {
			write(buf);
		}
		catch (IOException io) {
			System.err.println("Got IOException writing to StringWriter????");
		}
		return buf.toString();
    }

}
