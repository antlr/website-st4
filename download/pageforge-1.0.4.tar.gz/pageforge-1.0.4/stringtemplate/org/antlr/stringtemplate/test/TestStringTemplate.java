/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.stringtemplate.test;

import org.antlr.stringtemplate.StringTemplateGroup;
import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateErrorListener;
import org.antlr.stringtemplate.test.TestSuite;

import java.io.FileWriter;
import java.util.Vector;
import java.util.ArrayList;
import java.util.List;

public class TestStringTemplate extends TestSuite {

    public TestStringTemplate() {
    }

    public void runTests() throws Exception {
        runTest("testExprInParens");
        runTest("testMultipleAdditions");
        runTest("testCollectionAttributes");
        runTest("testParenthesizedExpression");
        runTest("testApplyTemplateNameExpression");
        runTest("testTemplateNameExpression");
        runTest("testMissingEndDelimiter");
        runTest("testSetButNotRefd");
        runTest("testNullTemplateToMultiValuedApplication");
        runTest("testNullTemplateApplication");
        runTest("testChangingAttrValueTemplateApplicationToVector");
        runTest("testChangingAttrValueRepeatedTemplateApplicationToVector");
        runTest("testTemplateApplicationAsRHSOfAssignment");
        runTest("testAlternatingTemplateApplication");
        runTest("testParameterAndAttributeScoping");
        runTest("testExpressionAsRHSOfAssignment");
        runTest("testComplicatedSeparatorExpr");
        runTest("testApplyRepeatedAnonymousTemplateWithForeignTemplateRefToMultiValuedAttribute");
        runTest("testAttributeRefButtedUpAgainstEndifAndWhitespace");
        runTest("testApplyAnonymousTemplateToMultiValuedAttribute");
        runTest("testStringCatenationOnSingleValuedAttribute");
        runTest("testMultiValuedAttributeWithSeparator");
        runTest("testApplyingTemplateFromDiskWithPrecompiledIF");
        runTest("testSingleValuedAttributes");
        runTest("testIFTemplate");
        runTest("testNestedIFTemplate");
        runTest("testApplyTemplateToSingleValuedAttribute");
        runTest("testApplyTemplateToSingleValuedAttributeWithDefaultAttribute");
        runTest("testApplyAnonymousTemplateToSingleValuedAttribute");
        runTest("testRepeatedApplicationOfTemplateToSingleValuedAttribute");
        runTest("testRepeatedApplicationOfTemplateToMultiValuedAttributeWithSeparator");
        runTest("testFindTemplateInCLASSPATH");
        runTest("testMultiValuedAttributeWithAnonymousTemplateUsingIndexVariableI");
        runTest("testStringLiteralAsAttribute");
        runTest("testObjectPropertyReference");
    }

    public void testExprInParens() throws Exception {
        // specify a template to apply to an attribute
        // Use a template group so we can specify the start/stop chars
        StringTemplateGroup group =
            new StringTemplateGroup("dummy", ".", "$", "$");
        StringTemplate bold = group.defineTemplate("bold", "<b>$attr$</b>");
        StringTemplate duh = new StringTemplate(group, "$(\"blort: \"+(list)):bold()$");
        duh.setAttribute("list", "a");
        duh.setAttribute("list", "b");
        duh.setAttribute("list", "c");
        // System.out.println(duh);
        String expecting = "<b>blort: abc</b>";
        assertTrue(duh.toString().equals(expecting));
    }

    public void testMultipleAdditions() throws Exception {
        // specify a template to apply to an attribute
        // Use a template group so we can specify the start/stop chars
        StringTemplateGroup group =
            new StringTemplateGroup("dummy", ".", "$", "$");
        group.defineTemplate("link", "<a href=\"$url$\"><b>$title$</b></a>");
        StringTemplate duh =
            new StringTemplate(group,
                "$link(url=\"/member/view?ID=\"+ID+\"&x=y\"+foo, title=\"the title\")$");
        duh.setAttribute("ID", "3321");
        duh.setAttribute("foo", "fubar");
        String expecting = "<a href=\"/member/view?ID=3321&x=yfubar\"><b>the title</b></a>";
        assertTrue(duh.toString().equals(expecting));
    }

    public void testCollectionAttributes() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate bold = group.defineTemplate("bold", "<b>$attr$</b>");
        StringTemplate t =
            new StringTemplate(group, "$data$, $data:bold()$, "+
                                      "$list:bold():bold()$, $array$, $a2$, $a3$, $a4$");
        Vector v = new Vector();
        v.addElement("1");
        v.addElement("2");
        v.addElement("3");
        List list = new ArrayList();
        list.add("a");
        list.add("b");
        list.add("c");
        t.setAttribute("data", v);
        t.setAttribute("list", list);
        t.setAttribute("array", new String[] {"x","y"});
        t.setAttribute("a2", new int[] {10,20});
        t.setAttribute("a3", new float[] {1.2f,1.3f});
        t.setAttribute("a4", new double[] {8.7,9.2});
        //System.out.println(t);
        String expecting="123, <b>1</b><b>2</b><b>3</b>, "+
            "<b><b>a</b></b><b><b>b</b></b><b><b>c</b></b>, xy, 1020, 1.21.3, 8.79.2";
        assertTrue(t.toString().equals(expecting));
    }

    public void testParenthesizedExpression() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate bold = group.defineTemplate("bold", "<b>$attr$</b>");
        StringTemplate t = new StringTemplate(group, "$(first+last):bold()$");
        t.setAttribute("first", "Joe");
        t.setAttribute("last", "Schmoe");
        //System.out.println(t);
        String expecting="<b>JoeSchmoe</b>";
        assertTrue(t.toString().equals(expecting));
    }

    public void testApplyTemplateNameExpression() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate bold = group.defineTemplate("foobar", "foo$attr$bar");
        StringTemplate t = new StringTemplate(group, "$data:(name+\"bar\")()$");
        t.setAttribute("data", "Ter");
        t.setAttribute("data", "Tom");
        t.setAttribute("name", "foo");
        //System.out.println(t);
        String expecting="fooTerbarfooTombar";
        assertTrue(t.toString().equals(expecting));
    }

    public void testTemplateNameExpression() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate bold = group.defineTemplate("foo", "hi there!");
        StringTemplate t = new StringTemplate(group, "$(name)()$");
        t.setAttribute("name", "foo");
        //System.out.println(t);
        String expecting="hi there!";
        assertTrue(t.toString().equals(expecting));
    }

    public void testMissingEndDelimiter() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        final StringBuffer errorOutput = new StringBuffer(500);
        group.setErrorListener(
            new StringTemplateErrorListener() {
                public void error(String msg, Exception e) {
                    if ( e!=null ) {
                        errorOutput.append(msg+e);
                    }
                    else {
                        errorOutput.append(msg);
                    }
                }
                public void warning(String msg) {
                    errorOutput.append(msg);
                }
                public void debug(String msg) {
                    errorOutput.append(msg);
                }
            }
        );
        StringTemplate t = new StringTemplate(group, "stuff $a then more junk etc...");
        String expectingError="end delimiter '$' not found in template for delimiter starting at index 30";
        //System.out.println("error: '"+errorOutput+"'");
        //System.out.println("expecting: '"+expectingError+"'");
        assertTrue(errorOutput.toString().equals(expectingError));
    }

    public void testSetButNotRefd() throws Exception {
        StringTemplate.setLintMode(true);
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate t = new StringTemplate(group, "$a$ then $b$ and $c$ refs.");
        t.setAttribute("a", "Terence");
        t.setAttribute("b", "Terence");
        t.setAttribute("cc", "Terence"); // oops...should be 'c'
        final String newline = System.getProperty("line.separator");
        final StringBuffer errorOutput = new StringBuffer(500);
        t.setErrorListener(
            new StringTemplateErrorListener() {
                public void error(String msg, Exception e) {
                    errorOutput.append(msg+e);
                }
                public void warning(String msg) {
                    errorOutput.append(msg);
                }
                public void debug(String msg) {
                    errorOutput.append(msg);
                }
            }
        );
        String expectingError="anonymous: set but not used: cc";
        String result = t.toString();    // result is irrelevant
        //System.out.println("error: '"+errorOutput+"'"); // filled after t.toString()
        //System.out.println("expecting: '"+expectingError+"'");
        StringTemplate.setLintMode(false);
        assertTrue(errorOutput.toString().equals(expectingError));
    }

    public void testNullTemplateApplication() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate t = new StringTemplate(group, "$names:bold(x=attr)$");
        t.setAttribute("names", "Terence");
        //System.out.println(t);
        String expecting=""; // bold not found...empty string
        assertTrue(t.toString().equals(expecting));
    }

    public void testNullTemplateToMultiValuedApplication() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate t = new StringTemplate(group, "$names:bold(x=attr)$");
        t.setAttribute("names", "Terence");
        t.setAttribute("names", "Tom");
        //System.out.println(t);
        String expecting=""; // bold not found...empty string
        assertTrue(t.toString().equals(expecting));
    }

    public void testChangingAttrValueTemplateApplicationToVector() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate italics = group.defineTemplate("italics", "<i>$x$</i>");
        StringTemplate bold = group.defineTemplate("bold", "<b>$x$</b>");
        StringTemplate t = new StringTemplate(group, "$names:bold(x=attr)$");
        t.setAttribute("names", "Terence");
        t.setAttribute("names", "Tom");
        //System.out.println(t);
        String expecting="<b>Terence</b><b>Tom</b>";
        assertTrue(t.toString().equals(expecting));
    }

    public void testChangingAttrValueRepeatedTemplateApplicationToVector() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("dummy", ".", "$", "$");
        StringTemplate bold = group.defineTemplate("bold", "<b>$item$</b>");
        StringTemplate italics = group.defineTemplate("italics", "<i>$it$</i>");
        StringTemplate members =
                new StringTemplate(group, "$members:bold(item=attr):italics(it=attr)$");
        members.setAttribute("members", "Jim");
        members.setAttribute("members", "Mike");
        members.setAttribute("members", "Ashar");
        //System.out.println("members="+members);
        String expecting = "<i><b>Jim</b></i><i><b>Mike</b></i><i><b>Ashar</b></i>";
        assertTrue(members.toString().equals(expecting));
    }

    public void testAlternatingTemplateApplication() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("dummy", ".", "$", "$");
        StringTemplate listItem = group.defineTemplate("listItem", "<li>$attr$</li>");
        StringTemplate bold = group.defineTemplate("bold", "<b>$attr$</b>");
        StringTemplate italics = group.defineTemplate("italics", "<i>$attr$</i>");
        StringTemplate item =
                new StringTemplate(group, "$item:bold(),italics():listItem()$");
        item.setAttribute("item", "Jim");
        item.setAttribute("item", "Mike");
        item.setAttribute("item", "Ashar");
        //System.out.println("ITEM="+item);
        String expecting = "<li><b>Jim</b></li><li><i>Mike</i></li><li><b>Ashar</b></li>";
        assertTrue(item.toString().equals(expecting));
    }

    public void testExpressionAsRHSOfAssignment() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate hostname = group.defineTemplate("hostname", "$machine$.jguru.com");
        StringTemplate bold = group.defineTemplate("bold", "<b>$x$</b>");
        StringTemplate t = new StringTemplate(group, "$bold(x=hostname(machine=\"www\"))$");
        String expecting="<b>www.jguru.com</b>";
        assertTrue(t.toString().equals(expecting));
    }

    public void testTemplateApplicationAsRHSOfAssignment() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate hostname = group.defineTemplate("hostname", "$machine$.jguru.com");
        StringTemplate bold = group.defineTemplate("bold", "<b>$x$</b>");
        StringTemplate italics = group.defineTemplate("italics", "<i>$attr$</i>");
        StringTemplate t = new StringTemplate(group, "$bold(x=hostname(machine=\"www\"):italics())$");
        String expecting="<b><i>www.jguru.com</i></b>";
        assertTrue(t.toString().equals(expecting));
    }

    public void testParameterAndAttributeScoping() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate italics = group.defineTemplate("italics", "<i>$x$</i>");
        StringTemplate bold = group.defineTemplate("bold", "<b>$x$</b>");
        StringTemplate t = new StringTemplate(group, "$bold(x=italics(x=name))$");
        t.setAttribute("name", "Terence");
        //System.out.println(t);
        String expecting="<b><i>Terence</i></b>";
        assertTrue(t.toString().equals(expecting));
    }

    public void testComplicatedSeparatorExpr() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate bold = group.defineTemplate("bulletSeparator", "</li>$foo$<li>");
        // make separator a complicated expression with args passed to included template
        StringTemplate t =
            new StringTemplate(group,
                               "<ul>$name; separator=bulletSeparator(foo=\" \")+\"&nbsp;\"$</ul>");
        t.setAttribute("name", "Ter");
        t.setAttribute("name", "Tom");
        t.setAttribute("name", "Mel");
        //System.out.println(t);
        String expecting = "<ul>Ter</li> <li>&nbsp;Tom</li> <li>&nbsp;Mel</ul>";
        assertTrue(t.toString().equals(expecting));
    }

    public void testAttributeRefButtedUpAgainstEndifAndWhitespace() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate a = new StringTemplate(group,
                                              "$if (!firstName)$$email$$endif$");
        a.setAttribute("email", "parrt@jguru.com");
        String expecting = "parrt@jguru.com";
        assertTrue(a.toString().equals(expecting));
    }

    public void testStringCatenationOnSingleValuedAttribute() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate bold = group.defineTemplate("bold", "<b>$attr$</b>");
        StringTemplate a = new StringTemplate(group, "$name+\" Parr\":bold()$");
        StringTemplate b = new StringTemplate(group, "$bold(attr=name+\" Parr\")$");
        a.setAttribute("name", "Terence");
        b.setAttribute("name", "Terence");
        String expecting = "<b>Terence Parr</b>";
        assertTrue(a.toString().equals(expecting) && b.toString().equals(expecting));
    }

    public void testApplyingTemplateFromDiskWithPrecompiledIF()
            throws Exception
    {
        String newline = System.getProperty("line.separator");
        // write the template files first to /tmp
        FileWriter fw = new FileWriter("/tmp/page.st");
        fw.write("<html><head>"+newline);
        //fw.write("  <title>PeerScope: $title$</title>"+newline);
        fw.write("</head>"+newline);
        fw.write("<body>"+newline);
        fw.write("$if(member)$User: $member:terse()$$endif$"+newline);
        fw.write("</body>"+newline);
        fw.write("</head>"+newline);
        fw.close();

        fw = new FileWriter("/tmp/terse.st");
        fw.write("$attr.firstName$ $attr.lastName$ (<tt>$attr.email$</tt>)"+newline);
        fw.close();

        // specify a template to apply to an attribute
        // Use a template group so we can specify the start/stop chars
        StringTemplateGroup group =
                new StringTemplateGroup("dummy", "/tmp", "$", "$");

        StringTemplate a = group.getInstanceOf("page");
        a.setAttribute("member", new Connector());
        String expecting = "<html><head>"+newline+
                "</head>"+newline+
                "<body>"+newline+
                "User: Terence Parr (<tt>parrt@jguru.com</tt>)"+newline+
                "</body>"+newline+
                "</head>";
        //System.out.println(a);
        assertTrue(a.toString().equals(expecting));
    }

    public void testMultiValuedAttributeWithAnonymousTemplateUsingIndexVariableI()
            throws Exception
    {
        StringTemplateGroup tgroup =
                new StringTemplateGroup("dummy", ".", "$", "$");
        StringTemplate t =
                new StringTemplate(tgroup,
                                   "List:\n"+
                                   "$names:{<br>$i+1$. $attr$\n}$");
        t.setAttribute("names", "Terence");
        t.setAttribute("names", "Jim");
        t.setAttribute("names", "Sriram");
        String newline = System.getProperty("line.separator");
        //System.out.println(t);
        String expecting =
                "List:"+newline+
                "<br>1. Terence"+newline+
                "<br>2. Jim"+newline+
                "<br>3. Sriram"+newline;
        assertTrue(t.toString().equals(expecting));
    }

    public void testFindTemplateInCLASSPATH() throws Exception {
        // Look for templates in CLASSPATH as resources
        StringTemplateGroup mgroup =
                new StringTemplateGroup("method stuff", "<", ">");
        StringTemplate m = mgroup.getInstanceOf("org.antlr.stringtemplate/test/method");
        // "method.st" references body() so "body.st" will be loaded too
        m.setAttribute("visibility", "public");
        m.setAttribute("name", "foobar");
        m.setAttribute("returnType", "void");
        m.setAttribute("statements", "i=1;"); // body inherits these from method
        m.setAttribute("statements", "x=i;");
        String newline = System.getProperty("line.separator");
        String expecting =
                "public void foobar() {"+newline+
                "\t// start of a body"+newline+
                "\ti=1; x=i;"+newline+
                "\t// end of a body"+newline+
                "}";
        assertTrue(m.toString().equals(expecting));
    }

    public void testApplyTemplateToSingleValuedAttribute() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate bold = group.defineTemplate("bold", "<b>$x$</b>");
        StringTemplate name = new StringTemplate(group, "$name:bold(x=name)$");
        name.setAttribute("name", "Terence");
        assertTrue(name.toString().equals("<b>Terence</b>"));
    }

    public void testStringLiteralAsAttribute() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate bold = group.defineTemplate("bold", "<b>$attr$</b>");
        StringTemplate name = new StringTemplate(group, "$\"Terence\":bold()$");
        assertTrue(name.toString().equals("<b>Terence</b>"));
    }

    public void testApplyTemplateToSingleValuedAttributeWithDefaultAttribute() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("test", "$", "$");
        StringTemplate bold = group.defineTemplate("bold", "<b>$attr$</b>");
        StringTemplate name = new StringTemplate(group, "$name:bold()$");
        name.setAttribute("name", "Terence");
        assertTrue(name.toString().equals("<b>Terence</b>"));
    }

    public void testApplyAnonymousTemplateToSingleValuedAttribute() throws Exception {
        // specify a template to apply to an attribute
        // Use a template group so we can specify the start/stop chars
        StringTemplateGroup group =
                new StringTemplateGroup("dummy", ".", "$", "$");
        StringTemplate item =
                new StringTemplate(group, "$item:{<li>$attr$</li>}$");
        item.setAttribute("item", "Terence");
        assertTrue(item.toString().equals("<li>Terence</li>"));
    }

    public void testApplyAnonymousTemplateToMultiValuedAttribute() throws Exception {
        // specify a template to apply to an attribute
        // Use a template group so we can specify the start/stop chars
        StringTemplateGroup group =
                new StringTemplateGroup("dummy", ".", "$", "$");
        StringTemplate list =
                new StringTemplate(group, "<ul>$items$</ul>");
        // demonstrate setting arg to anonymous subtemplate
        StringTemplate item =
                new StringTemplate(group, "$item:{<li>$attr$</li>}; separator=\",\"$");
        item.setAttribute("item", "Terence");
        item.setAttribute("item", "Jim");
        item.setAttribute("item", "John");
        list.setAttribute("items", item); // nested template
        assertTrue(list.toString().equals("<ul><li>Terence</li>,<li>Jim</li>,<li>John</li></ul>"));
    }

    public void testRepeatedApplicationOfTemplateToSingleValuedAttribute() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("dummy", ".", "$", "$");
        StringTemplate search = group.defineTemplate("bold", "<b>$attr$</b>");
        StringTemplate item =
                new StringTemplate(group, "$item:bold():bold()$");
        item.setAttribute("item", "Jim");
        assertTrue(item.toString().equals("<b><b>Jim</b></b>"));
    }

    public void testRepeatedApplicationOfTemplateToMultiValuedAttributeWithSeparator() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("dummy", ".", "$", "$");
        StringTemplate search = group.defineTemplate("bold", "<b>$attr$</b>");
        StringTemplate item =
                new StringTemplate(group, "$item:bold():bold(); separator=\",\"$");
        item.setAttribute("item", "Jim");
        item.setAttribute("item", "Mike");
        item.setAttribute("item", "Ashar");
        // first application of template must yield another vector!
        //System.out.println("ITEM="+item);
        assertTrue(item.toString().equals("<b><b>Jim</b></b>,<b><b>Mike</b></b>,<b><b>Ashar</b></b>"));
    }

    // ### NEED A TEST OF ATTR ASSIGNED TO ARG?
    // ### NEED A TEST OF SEPARATOR AS TEMPLATE?

    public void testMultiValuedAttributeWithSeparator() throws Exception {
        StringTemplate query;

        // if column can be multi-valued, specify a separator
        StringTemplateGroup group =
            new StringTemplateGroup("dummy", ".", "<", ">");
        query = new StringTemplate(group, "SELECT <distinct> <column; separator=\", \"> FROM <table>;");
        query.setAttribute("column", "name");
        query.setAttribute("column", "email");
        query.setAttribute("table", "User");
        // uncomment next line to make "DISTINCT" appear in output
        // query.setAttribute("distince", "DISTINCT");
        // System.out.println(query);
        assertTrue(query.toString().equals("SELECT  name, email FROM User;"));
    }

    public void testSingleValuedAttributes() throws Exception {
        // all attributes are single-valued:
        StringTemplate query =
                new StringTemplate("SELECT $column$ FROM $table$;");
        query.setAttribute("column", "name");
        query.setAttribute("table", "User");
        // System.out.println(query);
        assertTrue(query.toString().equals("SELECT name FROM User;"));
    }

    public void testIFTemplate() throws Exception {
        StringTemplateGroup group =
            new StringTemplateGroup("dummy", ".", "<", ">");
        StringTemplate t =
            new StringTemplate(group,
                      "SELECT <column> FROM PERSON "+
					  "<if(cond)>WHERE ID=<id><endif>;");
		t.setAttribute("column", "name");
		t.setAttribute("cond", "true");
		t.setAttribute("id", "231");
        assertTrue(t.toString().equals("SELECT name FROM PERSON WHERE ID=231;"));
    }

    public void testNestedIFTemplate() throws Exception {
        String newline = System.getProperty("line.separator");
        StringTemplateGroup group =
            new StringTemplateGroup("dummy", ".", "<", ">");
        StringTemplate t =
            new StringTemplate(group,
                "ack<if(a)>"+newline+
                "foo"+newline+
                "<if(!b)>stuff<endif>"+newline+
                "<if(b)>no<endif>"+newline+
                "junk"+newline+
                "<endif>"
            );
        t.setAttribute("a", "blort");
        // leave b as null
        //System.out.println("t="+t);
        String expecting =
                "ackfoo"+newline+
                "stuff"+newline+
                ""+newline+
                "junk";
        assertTrue(t.toString().equals(expecting));
    }

    public class Connector {
        public int getID() { return 1; }
        public String getFirstName() { return "Terence"; }
        public String getLastName() { return "Parr"; }
        public String getEmail() { return "parrt@jguru.com"; }
        public String getBio() { return "Superhero by night..."; }
        public boolean getCanEdit() { return false; }
    }

    public class Connector2 {
        public int getID() { return 2; }
        public String getFirstName() { return "Tom"; }
        public String getLastName() { return "Burns"; }
        public String getEmail() { return "tombu@jguru.com"; }
        public String getBio() { return "Superhero by day..."; }
        public boolean getCanEdit() { return true; }
    }

    public void testObjectPropertyReference() throws Exception {
        StringTemplateGroup group =
                new StringTemplateGroup("dummy", ".", "$", "$");
        String newline = System.getProperty("line.separator");
        StringTemplate t =
                new StringTemplate(
                        group,
                        "<b>Name: $p.firstName$ $p.lastName$</b><br>"+newline+
                        "<b>Email: $p.email$</b><br>"+newline+
                        "$p.bio$"
                );
        t.setAttribute("p", new Connector());
        //System.out.println("t is "+t.toString());
        String expecting =
                "<b>Name: Terence Parr</b><br>"+newline+
                "<b>Email: parrt@jguru.com</b><br>"+newline+
                "Superhero by night...";
        assertTrue(t.toString().equals(expecting));
    }

    public void testApplyRepeatedAnonymousTemplateWithForeignTemplateRefToMultiValuedAttribute() throws Exception {
        // specify a template to apply to an attribute
        // Use a template group so we can specify the start/stop chars
        StringTemplateGroup group =
            new StringTemplateGroup("dummy", ".", "$", "$");
        group.defineTemplate("link", "<a href=\"$url$\"><b>$title$</b></a>");
        StringTemplate duh =
            new StringTemplate(group,
        "start|$p:{$link(url=\"/member/view?ID=\"+attr.ID, title=attr.firstName)$ $if(attr.canEdit)$canEdit$endif$}:"+
        "{$attr$<br>\n}$|end");
        duh.setAttribute("p", new Connector());
        duh.setAttribute("p", new Connector2());
        String newline = System.getProperty("line.separator");
        //System.out.println(duh);
        String expecting = "start|<a href=\"/member/view?ID=1\"><b>Terence</b></a> <br>"+newline+
            "<a href=\"/member/view?ID=2\"><b>Tom</b></a> canEdit<br>"+newline+
            "|end";
        assertTrue(duh.toString().equals(expecting));
    }

}
