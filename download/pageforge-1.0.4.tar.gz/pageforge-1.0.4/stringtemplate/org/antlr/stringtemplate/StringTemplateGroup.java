/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.stringtemplate;

import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateErrorListener;

import java.util.Hashtable;
import java.util.Enumeration;
import java.io.*;

/** Manages a group of named mutually-referential StringTemplate objects.
 *  Currently the templates must all live under a directory so that you
 *  can reference them as foo.st or gutter/header.st.  To refresh a
 *  group of templates, just create a new StringTemplateGroup and start
 *  pulling templates from there.  Or, set the refresh interval.
 *
 *  Use getInstanceOf(template-name) to get a string template
 *  to fill in.
 *
 *  The name of a template is the file name minus ".st" ending if present
 *  unless you name it as you load it.
 */
public class StringTemplateGroup {
    /** What's the start of an attribute expression within a template?
     *  This one is good for HTML as it stands out, though I like
     *  <expr> even still.
     */
    private static final String DEFAULT_DELIMITER_START = "$";
    private static final String DEFAULT_DELIMITER_STOP = "$";

	/** What is the group name */
	protected String name;

    /** Maps template name to StringTemplate object */
    private Hashtable templates = null;

    /** Under what directory should I look for templates?  If null,
	 *  to look into the CLASSPATH for templates as resources.
     */
    private String rootDir = null;

	/** Where to report errors.  All string templates in this group
	 *  use this error handler by default.
	 */
	StringTemplateErrorListener listener = DEFAULT_ERROR_LISTENER;

    public static StringTemplateErrorListener DEFAULT_ERROR_LISTENER =
        new StringTemplateErrorListener() {
            public void error(String s, Exception e) {
                System.err.println(s);
                if ( e!=null ) {
                    e.printStackTrace(System.err);
                }
            }
            public void warning(String s) {
                System.out.println(s);
            }
            public void debug(String s) {
                System.out.println(s);
            }
        };

	/** Maps group name to delimiter start String for that group */
    private String delimiterStart = DEFAULT_DELIMITER_START;
    private String delimiterStop = DEFAULT_DELIMITER_STOP;

	/** Used to indicate that the template doesn't exist.
	 *  We don't have to check disk for it; we know it's not there.
	 */
	private static final StringTemplate NOT_FOUND_ST =
		new StringTemplate();

    /** How long before tossing out all templates in seconds. */
    private int refreshIntervalInSeconds = Integer.MAX_VALUE/1000; // default: no refreshing from disk
    private long lastCheckedDisk = 0L;

    /** Create a group manager for some templates, all of which are
     *  at or below the indicated directory.
     */
	public StringTemplateGroup(String name, String rootDir) {
        this.name = name;
		this.rootDir = rootDir;
        templates = new Hashtable();
        lastCheckedDisk = System.currentTimeMillis();
    }

	/** Create a group manager for some templates, all of which are
	 *  loaded as resources via the classloader.
	 */
	public StringTemplateGroup(String name) {
        this(name,null);
    }

	/** Create a group manager for some templates, all of which are
	 *  loaded as resources via the classloader.
	 */
	public StringTemplateGroup(String name,
                               String delimiterStart,
                               String delimiterStop)
    {
		this(name,null,delimiterStart,delimiterStop);
	}

    public StringTemplateGroup(String name,
							   String rootDir,
                               String delimiterStart,
                               String delimiterStop)
    {
        this(name, rootDir);
        this.delimiterStart = delimiterStart;
        this.delimiterStop = delimiterStop;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDelimiterStop() {
		return delimiterStop;
	}

	public String getDelimiterStart() {
		return delimiterStart;
	}

	public StringTemplate getInstanceOf(String name) {
		StringTemplate st = getInstanceOf(name, null);
		return st;
	}

	public StringTemplate getInstanceOf(String name, Hashtable initialValues) {
		StringTemplate st = getTemplate(name);
        if ( st==null ) {
            return null;
        }
        return st.getInstanceOfWithAttributes(initialValues);
    }

	public StringTemplate getEmbeddedInstanceOf(StringTemplate enclosingInstance,
                                                String name)
    {
		return getEmbeddedInstanceOf(enclosingInstance,name,null);
	}

	public StringTemplate getEmbeddedInstanceOf(StringTemplate enclosingInstance,
                                                String name,
												Hashtable initialValues)
    {
        StringTemplate st = getTemplate(name);
        if ( st==null ) {
            return null;
        }
        if ( initialValues!=null ) {
			st = st.getInstanceOfWithAttributes(initialValues);
		}
		else {
			st = st.getInstanceOf();
		}
        st.setEnclosingInstance(enclosingInstance);
        return st;
    }

	/** Get the template called 'name' from the group.  If not found,
     *  attempt to load/save.  If not found on disk, then record that it's
     *  NOT_FOUND so we don't waste time looking again later.  If we've gone
     *  past refresh interval, flush and look again.
     */
    public StringTemplate getTemplate(String name) {
        if ( StringTemplate.debugMode ) listener.debug("getTemplate("+name+")");
        checkRefreshInterval();
		StringTemplate st = (StringTemplate)templates.get(name);
        if ( st==null ) {
			// not there?  Attempt to load
            try {
                if ( StringTemplate.debugMode ) listener.debug("Attempting load of: "+getFileNameFromTemplateName(name));
                loadTemplate(getFileNameFromTemplateName(name));
            }
            catch (IOException ioe) {
                if ( StringTemplate.debugMode ) listener.debug("Can't load template "+getFileNameFromTemplateName(name));
                error("Can't load template "+getFileNameFromTemplateName(name),
                      ioe);
                // remember that this sucker doesn't exist
                templates.put(name, NOT_FOUND_ST);
            }
            st = (StringTemplate)templates.get(name);
			if ( st==NOT_FOUND_ST || st==null ) {
				return null;  // still not there, return null
			}
        }
		else if ( st==NOT_FOUND_ST ) {
			return null;
		}

		return st;
	}

    private void checkRefreshInterval() {
        boolean timeToFlush=refreshIntervalInSeconds==0 ||
                (System.currentTimeMillis()-lastCheckedDisk)>=refreshIntervalInSeconds*1000;
        if ( timeToFlush ) {
            // throw away all pre-compiled references
            templates.clear();
            lastCheckedDisk = System.currentTimeMillis();
        }
    }

    protected StringTemplate loadTemplate(String name, BufferedReader r)
            throws IOException
    {
        String line;
        String nl = System.getProperty("line.separator");
        StringBuffer buf = new StringBuffer(300);
        while ((line = r.readLine()) != null) {
            buf.append(line);
            buf.append(nl);
        }
		// strip newlines etc.. from front/back since filesystem
		// may add newlines etc...
		String pattern = buf.toString().trim();
		if ( pattern.length()==0 ) {
			error("no text in template '"+name+"'");
			return null;
		}
        return defineTemplate(name, pattern);
    }

    /** Load a template whose name is derived from the template filename.
     *  Remove the ".st" suffix and any path info on the front.
     */
    public StringTemplate loadTemplate(String fileName)
		throws IOException
    {
        String name = getTemplateNameFromFileName(fileName);
		if ( rootDir==null ) {
			ClassLoader cl = this.getClass().getClassLoader();
			InputStream is = cl.getResourceAsStream(fileName);
			if ( is==null ) {
				error("can't load '"+fileName+"' as resource");
				return null;
			}
			return loadTemplate(name, new BufferedReader(new InputStreamReader(is)));
		}
		return loadTemplate(name, rootDir+"/"+fileName);
    }

	public String getFileNameFromTemplateName(String templateName) {
		return templateName+".st";
	}

	/** Convert a filename relativePath/name.st to relativePath/name. */
	public String getTemplateNameFromFileName(String fileName) {
		String name = fileName;
		/*
		int slash = name.lastIndexOf("/");
		if ( slash>=0 ) {
			name = fileName.substring(slash+1, name.length());
		}
		*/
		int suffix = name.lastIndexOf(".st");
		if ( suffix>=0 ) {
			name = name.substring(0, suffix);
		}
		return name;
	}

	public StringTemplate loadTemplate(String name, String fileName)
		throws IOException
    {
		FileReader fr = new FileReader(fileName);
		return loadTemplate(name, new BufferedReader(fr));
    }

    /** Define an examplar template; precompiled and stored
     *  with no attributes.
     */
    public StringTemplate defineTemplate(String name,
                                         String template)
    {
		if ( StringTemplate.debugMode ) listener.debug(getName()+".defineTemplate("+name+")");
        StringTemplate st = new StringTemplate();
        st.setName(name);
		st.setGroup(this);
        st.setTemplate(template);
		st.setErrorListener(listener);
        templates.put(name, st);
        return st;
    }

    public int getRefreshInterval() {
        return refreshIntervalInSeconds;
    }

    /** How often to refresh all templates from disk.  This is a crude
     *  mechanism at the moment--just tosses everything out at this
     *  frequency.  Set interval to 0 to refresh constantly (no caching).
     *  Set interval to a huge number like MAX_INT to have no refreshing
     *  at all (DEFAULT); it will cache stuff.
     */
    public void setRefreshInterval(int refreshInterval) {
        this.refreshIntervalInSeconds = refreshInterval;
    }

	public void setErrorListener(StringTemplateErrorListener listener) {
		this.listener = listener;
	}

    public StringTemplateErrorListener getErrorListener() {
        return listener;
    }

	public void error(String msg) {
		error(msg, null);
	}

	public void error(String msg, Exception e) {
		if ( listener!=null ) {
			listener.error(msg,e);
		}
		else {
			System.err.println("StringTemplate: "+msg+": "+e);
		}
    }

    public String toString() {
        StringBuffer buf = new StringBuffer();
        Enumeration t = templates.keys();
        while ( t.hasMoreElements() ) {
            String tname = (String)t.nextElement();
            buf.append("==== TEMPLATE "+tname+"\n");
            StringTemplate st = (StringTemplate)templates.get(tname);
			if ( st!=NOT_FOUND_ST ) {
				buf.append(st.getTemplate());
				buf.append("====\n");
			}
        }
        return buf.toString();
    }

/*
public StringTemplate loadTemplate(String name, String resourceName)
            throws IOException
    {
		InputStream is =
			ClassLoader.getSystemResourceAsStream(resourceName);
		if ( is==null ) {
			throw new FileNotFoundException(resourceName);
		}
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader bf = new BufferedReader(isr);
        String line;
        String nl = System.getProperty("line.separator");
        StringBuffer buf = new StringBuffer(1024);
        while ((line = bf.readLine()) != null) {
            buf.append(line);
            buf.append(nl);
        }
        return defineTemplate(name, buf.toString());
    }
*/
}
