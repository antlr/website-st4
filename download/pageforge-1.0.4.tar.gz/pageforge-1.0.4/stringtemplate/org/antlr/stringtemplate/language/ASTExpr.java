/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.stringtemplate.language;

import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateGroup;
import org.antlr.stringtemplate.language.Expr;
import org.antlr.stringtemplate.language.StringTemplateAST;
import org.antlr.stringtemplate.language.StringTemplateLanguageEvaluator;

import java.io.Writer;
import java.io.IOException;
import java.io.StringWriter;
import java.util.*;
import java.lang.reflect.Method;

import antlr.collections.AST;
import antlr.RecognitionException;

/** A single string template expression enclosed in $...; separator=...$
 *  parsed into an AST chunk to be evaluated.
 */
public class ASTExpr extends Expr {
    public static final String DEFAULT_ATTRIBUTE_NAME = "attr";
    public static final String DEFAULT_INDEX_VARIABLE_NAME = "i";

    AST exprTree = null;

    /** store separator etc... */
    Hashtable options = null;

    public ASTExpr() {
    }

    public ASTExpr(AST exprTree, Hashtable options) {
        this.exprTree = exprTree;
        this.options = options;
    }

    /** To write out the value of an ASTExpr, invoke the evaluator in eval.g
     *  to walk the tree writing out the values.  For efficiency, don't
     *  compute a bunch of strings and then pack them together.  Write out directly.
     */
    public void write(StringTemplate self, Writer out) throws IOException {
        if ( exprTree==null || self==null || out==null ) {
            return;
        }
        //System.out.println("evaluating tree: "+exprTree.toStringList());
        StringTemplateLanguageEvaluator eval =
                new StringTemplateLanguageEvaluator(self,this,out);
        try {
            eval.action(exprTree); // eval and write out tree
        }
        catch (RecognitionException re) {
            self.error("can't evaluate tree: "+exprTree.toStringList(), re);
        }
    }

    // HELP ROUTINES CALLED BY EVALUATOR TREE WALKER

    public Object applyListOfAlternatingTemplates(StringTemplate self,
                                                  Object attributeValue,
                                                  List templatesToApply)
    {
        if ( attributeValue==null || templatesToApply==null || templatesToApply.size()==0 ) {
            return null; // do not apply if missing templates or empty value
        }
        //System.out.println("list of templates: "+templatesToApply);
        StringTemplate embedded = null;
        Hashtable argumentContext = null;

        if ( attributeValue instanceof List ) {
            List attributeList = (List)attributeValue;
            List resultVector = new ArrayList(attributeList.size());
            for (int i=0; i< attributeList.size(); i++) {
                Object ithValue = attributeList.get(i);
                if ( ithValue==null ) {
                    // weird...a null value in the list; ignore
                    continue;
                }
                int templateIndex = i % templatesToApply.size(); // rotate through
                embedded = (StringTemplate)templatesToApply.get(templateIndex);
                argumentContext = new Hashtable();
                argumentContext.put(DEFAULT_ATTRIBUTE_NAME, ithValue);
                argumentContext.put(DEFAULT_INDEX_VARIABLE_NAME, new Integer(i));
                embedded.setArgumentContext(argumentContext);
                evaluateArguments(embedded);
                /*
                System.out.println("applyTemplate("+embedded.getName()+", args="+argumentContext+
                        " to attribute value "+attributeValue);
                */
                Object value = embedded.toString();  // apply template
                resultVector.add(value);
                // can try to save embedded string template one day instead of
                // doing a toString().
            }
            return resultVector;
        }
        else {
            /*
            System.out.println("setting attribute "+DEFAULT_ATTRIBUTE_NAME+" in arg context of "+
            embedded.getName()+
            " to "+attributeValue);
            */
            embedded = (StringTemplate)templatesToApply.get(0);
            argumentContext = new Hashtable();
            argumentContext.put(DEFAULT_ATTRIBUTE_NAME, attributeValue);
            argumentContext.put(DEFAULT_INDEX_VARIABLE_NAME, new Integer(0));
            embedded.setArgumentContext(argumentContext);
            evaluateArguments(embedded);
            return embedded;
        }
    }

    /** Return o.getPropertyName() given o and propertyName.  Special case:
     *  If the method returns a boolean, then you must return NULL if boolean is false.
     *  Otherwise, it will always return an object and IF statements never fail.
     */
    public Object getObjectProperty(StringTemplate self, Object o, String propertyName) {
        if ( o==null || propertyName==null ) {
            return null;
        }
        Class c = o.getClass();
        String methodName = "get"+
                Character.toUpperCase(propertyName.charAt(0))+
                propertyName.substring(1,propertyName.length());
        Object value = null;
        try {
            Method m = c.getMethod(methodName, null);
            value = m.invoke(o,null);
            if ( StringTemplate.isDebugMode() ) self.debug(methodName+"() returns "+value+"<"+value.getClass().getName()+">");
            if ( m.getReturnType()==boolean.class ) {
                if ( ((Boolean)value).booleanValue()==false ) {
                    value = null; // kill value to imply false in StringTemplate IF statement
                }
            }
        }
        catch (Exception e) {
            self.error("Can't get property "+propertyName+" using method "+methodName+
                       " from "+c.getName()+" instance.", e);
        }
        return value;
    }

    /** For strings or other objects, catenate and return.
     *  For Integer, add and return Integer.
     */
    public Object add(Object a, Object b) {
        if ( a==null ) { // a null value means don't do cat, just return other value
            return b;
        }
        else if ( b==null ) {
            return a;
        }
        if ( a instanceof Integer && b instanceof Integer ) {
            return new Integer(((Integer)a).intValue()+((Integer)b).intValue());
        }
        return a.toString() + b.toString();
    }

    /** Call a string template with args and get text result */
    public String getTemplateText(StringTemplate self,
                                  String templateName,
                                  Hashtable argumentContext)
    {
        StringTemplateGroup group = self.getGroup();
        StringTemplate embedded = group.getEmbeddedInstanceOf(self, templateName);
        if ( embedded==null ) {
            self.error("cannot make emedded instance of "+templateName);
            return null;
        }
        embedded.setArgumentContext(argumentContext);
        String text = embedded.toString();
        return text;
    }

    /** How to spit out an object.  If it's not a StringTemplate nor a
     *  List, just do o.toString().  If it's a StringTemplate,
     *  do o.write(out).  If it's a Vector, do a write(out,
     *  o.elementAt(i)) for all elements.  Note that if you do
     *  something weird like set the values of a multivalued tag
     *  to be vectors, it will effectively flatten it.
     *
     *  If self is an embedded template, you might have specified
     *  a separator arg; used when is a vector.
     */
    public void writeAttribute(StringTemplate self, Object o, Writer out) {
        Object separator = null;
        if ( options!=null ) {
            separator = options.get("separator");
        }
        write(self,o,out,separator);
    }

    protected void write(StringTemplate self, Object o, Writer out, Object separator) {
        if ( o==null ) {
            return;
        }
        try {
            if ( o instanceof StringTemplate ) {
                ((StringTemplate)o).write(out);
            }
            else if ( o instanceof List ) {
                Iterator e = ((List)o).iterator();
                String separatorString = null;
                if ( separator!=null ) {
                    separatorString = computeSeparator(self, separator);
                }
                while ( e.hasNext() ) {
                    write(self, e.next(), out, separator);
                    if ( e.hasNext() ) {
                        if ( separator!=null ) {
                            out.write(separatorString);
                        }
                    }
                }
            }
            else {
                out.write(o.toString());
            }
        }
        catch (IOException io) {
            self.error("problem writing object: "+o, io);
        }
    }

    /** A separator is normally just a string literal, but is still an AST that
     *  we must evaluate.  The separator can be any expression such as a template
     *  include or string cat expression etc...
     */
    protected String computeSeparator(StringTemplate self, Object separator) {
        if ( separator==null ) {
            return null;
        }
        if ( separator instanceof StringTemplateAST ) {
            StringTemplateAST separatorTree = (StringTemplateAST)separator;
            // must evaluate, writing to a string so we can hand on to it
            ASTExpr e = new ASTExpr(separatorTree,null);
            StringWriter sw = new StringWriter();
            try {
                e.write(self,sw);
            }
            catch (IOException ioe) {
                self.error("can't evaluate separator expression", ioe);
            }
            return sw.toString();
        }
        else {
            // just in case we expand in the future and it's something else
            return separator.toString();
        }
    }

    protected void evaluateArguments(StringTemplate self) {
        StringTemplateAST argumentsAST = self.getArgumentsAST();
        if ( argumentsAST==null || argumentsAST.getFirstChild()==null ) {
            // return immediately if missing tree or no actual args
            return;
        }
        StringTemplateLanguageEvaluator eval =
                new StringTemplateLanguageEvaluator(self,this,null);
        try {
            // using any initial argument context (such as when attr is set),
            // evaluage the arg list like bold(item=attr).  Since we pass
            // in any existing arg context, that context gets filled with
            // new values.  With bold(item=attr), context becomes:
            // {[attr=...],[item=...]}.
            Hashtable ac = eval.argList(argumentsAST, self.getArgumentContext());
            self.setArgumentContext(ac);
        }
        catch (RecognitionException re) {
            self.error("can't evaluate tree: "+argumentsAST.toStringList(), re);
        }
    }
}
