/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.entity;

import com.jguru.peerscope.service.MemberService;

/** A group descriptor; something owned by a Member that describes
 *  the group of similarly-minded people.  This is not a list
 *  of links etc...; it is just the descriptor for the list
 *  roughly as stored in the db.
 */
public class GroupDescriptor extends Entity {
    public static final int PRIVATE_ACCESS = 1; // default
    public static final int PUBLIC_ACCESS = 2;
    public static final String[] accessDisplayNames = {null,"private","public"};

    protected int ownerID;
    protected String name;
    protected int access;
    protected String description;

    public int getAccess() {
        return access;
    }

    public String getAccessDisplayName() {
        return accessDisplayNames[getAccess()];
    }

    public void setAccess(int access) {
        this.access = access;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOwnerID() {
        return ownerID;
    }

    public void setOwnerID(int ownerID) {
        this.ownerID = ownerID;
    }

    public Member getOwner() {
        Member member = MemberService.instance().getMember(getOwnerID());
        System.out.println("owner of group is"+member);
        return member;
    }

    public String toString() {
        return super.toString()+": "+name+" owner="+ownerID+", "+description+"\n";
    }
}
