/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.testing;

import com.jguru.peerscope.service.StorageService;
import com.jguru.peerscope.service.GroupService;
import com.jguru.peerscope.entity.Member;
import com.jguru.peerscope.entity.GroupDescriptor;
import com.jguru.peerscope.support.QueryResultSet;

import java.util.Vector;
import java.sql.SQLException;

public class TestStorageService {
    public String testName = null;
    int failures = 0;

    public static class FailedAssertionException extends Exception {}

    public void assertTrue(boolean test) throws FailedAssertionException {
        if ( !test ) {
            throw new FailedAssertionException();
        }
    }

    int terID, melID, tombuID;
    int antlrID, jguruID;
    int e1,e2,e3,e4;

    public static void main(String[] args) {
        TestStorageService test = null;
        try {
            test = new TestStorageService();
            test.runTests();
        }
        catch (FailedAssertionException fae) {
            System.out.println("FAILED "+test.testName+":");
            fae.printStackTrace();
        }
        catch (Exception e) {
            System.out.println("Exception during test "+test.testName);
            e.printStackTrace();
        }
        System.out.println("failures: "+test.failures);
    }

    protected void runTests() throws Exception {
        setUp();
        testRawInserts();
        testGetUsers();
        testGetGroups();
        testGetMembership();
        testGetEntries();
        testRawDeletes();
        tearDown();
    }

    public void setUp() throws Exception {
        boolean isOk = StorageService.setupDBBroker();
        assertTrue(isOk);
    }

    protected void tearDown() throws Exception {
        StorageService.shutdown();
    }

    public void testRawDeletes() throws Exception {
        testName = "raw deletes";
        StorageService storage = StorageService.instance();
        storage.open();
        storage.deleteMember(tombuID);
        storage.deleteMember(terID);
        storage.deleteMember(melID);
        assertTrue(storage.getMember(tombuID)==null);
        assertTrue(storage.getMember(melID)==null);
        assertTrue(storage.getMember(terID)==null);

        storage.deleteGroupDescriptor(antlrID);
        storage.deleteGroupDescriptor(jguruID);
        assertTrue(storage.getGroupDescriptor(antlrID)==null);
        assertTrue(storage.getGroupDescriptor(jguruID)==null);

        storage.deleteGroupSubscription(terID, antlrID);
        storage.deleteGroupSubscription(tombuID, antlrID);
        storage.deleteGroupSubscription(terID, jguruID);
        storage.deleteGroupSubscription(melID, jguruID);
        storage.deleteGroupSubscription(tombuID, jguruID);

        storage.deleteGroupEntry(e1);
        storage.deleteGroupEntry(e2);
        storage.deleteGroupEntry(e3);
        storage.deleteGroupEntry(e4);

        storage.close();
    }

    public void testRawInserts() throws Exception {
        testName = "raw inserts";
        StorageService storage = StorageService.instance();
        storage.open();
        // first make sure there is a user (unique one so no clobbering)
        terID = storage.insertMember("Terencexxx", "Parrxxx", "parrt@jguru.comxxx", "ickxxx", "uniquehash");
        Member u = storage.getMember(terID);
        assertTrue(u!=null);
        assertTrue(u.getFirstName().equals("Terencexxx"));
        assertTrue(u.getLastName().equals("Parrxxx"));
        assertTrue(u.getEmail().equals("parrt@jguru.comxxx"));
        assertTrue(u.getPassword().equals("ickxxx"));
        tombuID = storage.insertMember("Tomxxx", "Burnsxxx", "tombu@jguru.comxxx", "ickxxx", "uniquehash");
        u = storage.getMember(tombuID);
        assertTrue(u!=null);
        assertTrue(u.getFirstName().equals("Tomxxx"));
        assertTrue(u.getLastName().equals("Burnsxxx"));
        assertTrue(u.getEmail().equals("tombu@jguru.comxxx"));
        assertTrue(u.getPassword().equals("ickxxx"));
        melID = storage.insertMember("Melxxx", "Bermanxxx", "mel@jguru.comxxx", "ickxxx", "uniquehash");
        u = storage.getMember(melID);
        assertTrue(u!=null);
        assertTrue(u.getFirstName().equals("Melxxx"));
        assertTrue(u.getLastName().equals("Bermanxxx"));
        assertTrue(u.getEmail().equals("mel@jguru.comxxx"));
        assertTrue(u.getPassword().equals("ickxxx"));

        // add descriptors (unique bogus one)
        antlrID = storage.insertGroupDescriptor("antlrxxx", terID, GroupDescriptor.PUBLIC_ACCESS, "testingxxx");
        GroupDescriptor d = storage.getGroupDescriptor(antlrID);
        assertTrue(d!=null);
        assertTrue(d.getName().equals("antlrxxx"));
        assertTrue(d.getOwnerID()==terID);
        assertTrue(d.getDescription().equals("testingxxx"));

        jguruID = storage.insertGroupDescriptor("jguruxxx", tombuID, GroupDescriptor.PRIVATE_ACCESS, "jguru testingxxx");
        d = storage.getGroupDescriptor(jguruID);
        assertTrue(d!=null);
        assertTrue(d.getName().equals("jguruxxx"));
        assertTrue(d.getOwnerID()==tombuID);
        assertTrue(d.getDescription().equals("jguru testingxxx"));

        // add some membership data
        storage.subscribeToGroup(terID, antlrID, GroupService.RW_ACCESS);
        storage.subscribeToGroup(tombuID, antlrID, GroupService.RW_ACCESS);
        storage.subscribeToGroup(terID, jguruID, GroupService.RW_ACCESS);
        storage.subscribeToGroup(melID, jguruID, GroupService.RW_ACCESS);
        storage.subscribeToGroup(tombuID, jguruID, GroupService.RW_ACCESS);

        e1 = storage.insertGroupEntry(terID,antlrID,"antlr home site", "http://www.antlr.org", "cool site");
        e2 = storage.insertGroupEntry(terID,jguruID,"jguru home site", "http://www.jguru.com", "the site");
        e3 = storage.insertGroupEntry(melID,jguruID,"know spam", "http://www.knowspam.net", "tom is working on this site");
        e4 = storage.insertGroupEntry(tombuID,jguruID,"nytimes article", "http://www.nytimes.com", "article on spam");
        storage.close();
    }

    public void testGetUsers() {
        testName = "get users";
        StorageService storage = StorageService.instance();
        storage.open();
        Vector v = storage.getAllMembers();
        System.out.println(v);
        storage.close();
    }

    public void testGetMembership() {
        testName = "get membership";
        StorageService storage = StorageService.instance();
        storage.open();
        QueryResultSet rs = storage.getAllMemberships();
        System.out.println(rs);
        storage.close();
    }

    public void testGetGroups() {
        testName = "get groups";
        StorageService storage = StorageService.instance();
        storage.open();
        Vector v = storage.getAllGroupDescriptors();
        System.out.println(v);
        storage.close();
    }

    public void testGetEntries() {
        testName = "get entries";
        StorageService storage = StorageService.instance();
        storage.open();
        Vector v = storage.getAllGroupEntries();
        System.out.println(v);
        storage.close();
    }

}
