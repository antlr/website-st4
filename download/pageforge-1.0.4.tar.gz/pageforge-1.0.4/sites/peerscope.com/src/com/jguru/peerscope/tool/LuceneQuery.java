/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.tool;

import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Hits;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.DateField;
import org.apache.lucene.document.Field;

import java.util.GregorianCalendar;
import java.util.Vector;
import java.util.Date;
import java.util.Enumeration;
import java.io.IOException;

import com.jguru.peerscope.support.SearchResultItem;

/** Isolated piece of code to do a lucene query. */
public class LuceneQuery {
    public static final String ACCESS_FIELD = "access";
    public static final String ID_FIELD = "ID";
    public static final String GROUPID_FIELD = "groupID";
    public static final String URL_FIELD = "url";
    public static final String TITLE_FIELD = "title";
    public static final String DATE_FIELD = "date";
    public static final String DESCRIPTION_FIELD = "description";
    public static final String SEARCH_DB_ROOT = "/var/data/peerscope/search";

    public static void main(String[] args) {
        String query = args[0];
        luceneSearch(query,0,10000);
    }

    public static void luceneSearch(String luceneQuery, // not keywords
                                     int offset,
                                     int batchSize)
    {
        System.out.println("search: "+luceneQuery);
        if ( luceneQuery==null || luceneQuery.trim().length()==0 ) {
            return;
        }
        if ( offset<0 ) {
            offset = 0;
        }
        Searcher searcher = null;
        boolean error = false;
        try {
            searcher =
                    new IndexSearcher(SEARCH_DB_ROOT);
            Analyzer analyzer = new StandardAnalyzer();

            Query parsedLuceneQuery =
                    QueryParser.parse(luceneQuery, DESCRIPTION_FIELD, analyzer);

            System.out.println("lucene searching for: '" +
                    parsedLuceneQuery.toString(DESCRIPTION_FIELD)+"'");
            Hits hits = searcher.search(parsedLuceneQuery);

            System.out.println(new GregorianCalendar().getTime()+": has "+
                    hits.length() + " total matching documents");

            if ( hits==null || hits.length()==0 ) {
                System.out.println("0 results");
                return;
            }

            int numberOfResults = 0;
            int totalNumberOfResults = hits.length();
            if (offset+batchSize > hits.length() ) {
                numberOfResults = hits.length()-offset;
            }
            else {
                numberOfResults = batchSize;
            }
            System.out.println("num results= "+numberOfResults);

            if ( numberOfResults<=0 ) {
                System.out.println("Bad num results in lucene query '"+
                        luceneQuery+"':"+
                        "offset="+offset+", batchSize="+batchSize+", hits.length()="+
                        hits.length()+
                        ", numresults="+numberOfResults);
                return;
            }

            System.out.println("totalNumberOfResults: "+totalNumberOfResults);
            System.out.println("numberOfResults: "+numberOfResults);
            for (int i = offset; i<(totalNumberOfResults); i++) {
                Enumeration fields = hits.doc(i).fields();
                StringBuffer buf = new StringBuffer();
                buf.append("score:"+hits.score(i));
                while (fields.hasMoreElements()) {
                    Field field = (Field) fields.nextElement();
                    String fieldName = field.name();
                    buf.append(" "+fieldName+":"+hits.doc(i).get(fieldName));
                }
                System.out.println(buf);
            }

            searcher.close();
            searcher = null;
        }
        catch (Exception e) {
            System.out.println("problem searching for '"+luceneQuery+"': "+e);
            // try to close search db
            if ( searcher!=null ) {
                try {
                    searcher.close();
                }
                catch (Exception ee) {
                    System.out.println("problem closing search index for '"+
                            luceneQuery+"':"+ee);
                }
            }
        }
        finally {
            if ( searcher!=null ) {
                try {
                    searcher.close();
                }
                catch (Exception e) {
                    System.out.println("problem closing search index for '"+
                            luceneQuery+"':"+e);
                }
            }
        }
    }

    private static SearchResultItem createSearchResultItem(Document doc) throws IOException {
        SearchResultItem item = new SearchResultItem();
        item.setID(Integer.parseInt(doc.get(ID_FIELD)));
        item.setGroupID(Integer.parseInt(doc.get(GROUPID_FIELD)));
        item.setURL(doc.get(URL_FIELD));
        item.setTitle(doc.get(TITLE_FIELD));
        item.setDescription(doc.get(DESCRIPTION_FIELD));
        item.setAccess(Integer.parseInt(doc.get(ACCESS_FIELD)));
        String createdStr = doc.get(DATE_FIELD);
        Date created = null;
        if ( createdStr!=null ) {
            created = DateField.stringToDate(createdStr);
        }
        item.setCreated(created);
        return item;
    }

}
