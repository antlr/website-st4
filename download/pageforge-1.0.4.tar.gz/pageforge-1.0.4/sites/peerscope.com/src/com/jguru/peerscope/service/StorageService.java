/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.service;

import com.jguru.peerscope.entity.Member;
import com.jguru.peerscope.entity.GroupDescriptor;
import com.jguru.peerscope.entity.GroupEntry;
import com.jguru.peerscope.support.EntityDBException;
import com.jguru.peerscope.support.QueryResultSet;
import org.antlr.stringtemplate.StringTemplate;

import java.util.Vector;
import java.sql.*;

/** A persistence layer for peerscope.
 *
 *  Stores stuff in a database for now.  If I ever need to switch, I can easily
 *  just replace this class.  No point in making a big switch to swap in/out
 *  various persistence layers.  Waste of time.
 */
public class StorageService {
    public static final int MIN_CONNECTIONS=5, MAX_CONNECTIONS=40;
	public static final int BROKER_CLEANUP_INTERVAL=2; // two days
	public static final String BROKER_LOG_FILE = "/var/log/peerscope/db/portal.log";

    private static DBConnectionBroker broker = null;

    static {
        setupDBBroker();
    }

    private StorageService() {
        System.out.println("Create StorageService");
    }

    /** Always return a new object so we can have multiple DB connections */
    public static synchronized StorageService instance() {
        return new StorageService();
    }

    /** Each StorageService object has a connection to the DB */
    protected Connection connection = null;

    public Connection open() {
        System.out.println("open DB");
        // check to see if we can get a connection
		connection = broker.getConnection();
		if ( connection == null ) {
			ErrorService.instance().panic("can't get connection", null, null);
		}
        return connection;
    }

    public void close() {
        System.out.println("close DB");
		if ( connection!=null ) {
			broker.freeConnection(connection);
		}
        connection = null;
    }

    protected QueryResultSet query(String query) throws SQLException {
        QueryResultSet result = null;
        Statement stat = null;
        ResultSet rs = null;
        try {
            stat = connection.createStatement();
            rs = stat.executeQuery(query);
            ResultSetMetaData meta = rs.getMetaData();
            int cols = meta.getColumnCount();
            result = new QueryResultSet(100,cols);
            while ( rs.next() ) {
                // walk sql result set making a groovy QueryResultSet
                // which also lets us close out the DB resource while
                // retaining all the data.
                Object[] row = new Object[cols];
                for (int i=1; i<=cols; i++) {
                    row[i-1] = rs.getObject(i); // get ith object from db
                }
                result.addRow(row);
            }
            rs.close();
            rs=null;
            stat.close();
            stat=null;
            connection.commit();
        }
        finally {
            if ( rs!=null ) {rs.close();}
            if ( stat!=null ) {stat.close();}
        }
        return result;
    }

    // DESCRIPTOR

    public int insertGroupDescriptor(String name,
                                       int ownerID,
                                       int access,
                                       String description) {
        int ID = 0;
        try {
            connection.setAutoCommit(false);
            if ( description==null || description.length()==0 ) {
                description="";
            }
            String s="INSERT INTO DESCRIPTOR (ID,CREATED,OWNER,NAME,ACCESS,DESCRIPTION) "+
                     "VALUES (?,?,?,?,?,?)";
            PreparedStatement pstat = connection.prepareStatement(s);
            ID = getUniqueEntityID();
            pstat.setInt(1,ID);
            pstat.setTimestamp(2,getCurrentTimestamp());
            pstat.setInt(3,ownerID);
            pstat.setString(4,name);
            pstat.setInt(5,access);
            pstat.setString(6,description);
			int rows = pstat.executeUpdate();
            pstat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error inserting group descriptor ",sqle);
		}
        catch (EntityDBException db) {
			error("Error getting unique ID ",db);
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back ",e2);
			}
		}
        return ID;
    }

    public void deleteGroupDescriptor(int ID) {
        delete("DESCRIPTOR", ID);
    }

    public Vector getAllGroupDescriptors() {
        System.out.println("get all descriptors");
        Vector results = new Vector(100);
        try {
            connection.setAutoCommit(false);
            String q="SELECT * FROM DESCRIPTOR";
			Statement stat = connection.createStatement();
            ResultSet rs = stat.executeQuery(q);
            while ( rs.next() ) {
                GroupDescriptor descr = new GroupDescriptor();
                descr.setID(rs.getInt("ID"));
                descr.setCreated(rs.getTimestamp("created"));
                descr.setName(rs.getString("name"));
                descr.setOwnerID(rs.getInt("owner"));
                descr.setAccess(rs.getInt("access"));
                descr.setDescription(rs.getString("description"));
                results.addElement(descr);
            }
            rs.close();
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error getting group descriptors: ",sqle);
            results = null;
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}
        return results;
    }

    public GroupDescriptor getGroupDescriptor(int ID) {
        GroupDescriptor descr = null;
        try {
            connection.setAutoCommit(false);
            String q="SELECT * FROM DESCRIPTOR where ID="+ID;
			Statement stat = connection.createStatement();
			ResultSet rs = stat.executeQuery(q);
			if ( !rs.next() ) {
				error("No such descriptor for ID: "+ID);
			}
            else {
                descr = new GroupDescriptor();
                descr.setID(rs.getInt("ID"));
                descr.setCreated(rs.getTimestamp("created"));
                descr.setName(rs.getString("name"));
                descr.setOwnerID(rs.getInt("owner"));
                descr.setAccess(rs.getInt("access"));
                descr.setDescription(rs.getString("description"));
            }
            rs.close();
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error inserting entity: ",sqle);
            descr = null;
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}

        return descr;
    }

    // MEMBER

    public Vector getAllMembers() {
        Vector results = new Vector(100);
        try {
            connection.setAutoCommit(false);
            String q="SELECT * FROM MEMBER";
			Statement stat = connection.createStatement();
			ResultSet rs = stat.executeQuery(q);
			while ( rs.next() ) {
                Member m = new Member();
                m.setID(rs.getInt("ID"));
                m.setNotifications(rs.getInt("notifications"));
                m.setCreated(rs.getTimestamp("created"));
                m.setFirstName(rs.getString("firstName"));
                m.setLastName(rs.getString("lastName"));
                m.setEmail(rs.getString("email"));
                m.setPassword(rs.getString("password"));
                m.setUniqueHash(rs.getString("uniqueHash"));
                results.addElement(m);
            }
            rs.close();
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error getting members: ",sqle);
            results = null;
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}
        return results;
    }

    public Member getMember(int ID) {
        return getMember("ID="+ID);
    }

    public Member getMemberByUniqueHash(String hash) {
        return getMember("uniqueHash='"+hash+"'");
    }

    public Member getMemberByEmail(String email) {
        if ( email==null ) {
            return null;
        }
        email = email.trim().toLowerCase();
        return getMember("email='"+email+"'");
    }

    private Member getMember(String condition) {
        Member m = null;
        try {
            connection.setAutoCommit(false);
            String q="SELECT * FROM MEMBER where "+condition;
            System.out.println("getMember("+q+")");
			Statement stat = connection.createStatement();
			ResultSet rs = stat.executeQuery(q);
			if ( !rs.next() ) {
				error("No such member for "+condition);
			}
            else {
                m = new Member();
                m.setID(rs.getInt("ID"));
                m.setNotifications(rs.getInt("notifications"));
                m.setCreated(rs.getTimestamp("created"));
                m.setFirstName(rs.getString("firstName"));
                m.setLastName(rs.getString("lastName"));
                m.setEmail(rs.getString("email"));
                m.setPassword(rs.getString("password"));
                m.setUniqueHash(rs.getString("uniqueHash"));
            }
            rs.close();
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error inserting entity: ",sqle);
            m = null;
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}

        return m;
    }

    public int insertMember(String firstName,
                            String lastName,
                            String email,
                            String password,
                            String uniqueHash) {
        int ID = 0;
        try {
            System.out.println("Attempt insert of "+email);
            connection.setAutoCommit(false);
            String s="INSERT INTO MEMBER (ID,CREATED,FIRSTNAME,LASTNAME,EMAIL,"+
                     "PASSWORD,UNIQUEHASH,NOTIFICATIONS) VALUES (?,?,?,?,?,?,?,?)";
            PreparedStatement pstat = connection.prepareStatement(s);
            ID = getUniqueEntityID();
            if ( firstName!=null ) {
                firstName = firstName.trim();
            }
            if ( lastName!=null ) {
                lastName = lastName.trim();
            }
            email = email.trim().toLowerCase();
            pstat.setInt(1,ID);
            pstat.setTimestamp(2,getCurrentTimestamp());
            pstat.setString(3,firstName);
            pstat.setString(4,lastName);
            pstat.setString(5,email);
            pstat.setString(6,password);
            pstat.setString(7,uniqueHash);
            pstat.setInt(8,EmailService.NOTIFICATIONS_PER_ENTRY);
            System.out.println("about to insert member: "+email);
			int rows = pstat.executeUpdate();
            System.out.println("inserted member: "+email);
            pstat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error inserting member: ",sqle);
		}
        catch (EntityDBException db) {
			error("Error getting unique ID: ",db);
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}
        return ID;
    }

    public void updateMember(int memberID,
                             String firstName,
                             String lastName,
                             String email,
                             String password,
                             int notifications)
    {
        try {
            System.out.println("Attempt update of "+email);
            connection.setAutoCommit(false);
            String s="UPDATE MEMBER SET FIRSTNAME=?,LASTNAME=?,EMAIL=?,PASSWORD=?"+
                     ", NOTIFICATIONS=? WHERE ID="+memberID;
            PreparedStatement pstat = connection.prepareStatement(s);
            if ( firstName!=null ) {
                firstName = firstName.trim();
            }
            if ( lastName!=null ) {
                lastName = lastName.trim();
            }
            email = email.trim().toLowerCase();
            pstat.setString(1,firstName);
            pstat.setString(2,lastName);
            pstat.setString(3,email);
            pstat.setString(4,password);
            pstat.setInt(5,notifications);
            System.out.println("about to update member: "+email);
			int rows = pstat.executeUpdate();
            System.out.println("updated member: "+email);
            pstat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error updating member: ",sqle);
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}
    }

    public void updateGroupEntry(int entryID,
                                   String title,
                                   String url,
                                   String comments) {
        try {
            System.out.println("Attempt update of entry "+entryID);
            connection.setAutoCommit(false);
            String s="UPDATE ENTRY SET TITLE=?,URL=?,COMMENTS=? "+
                    "WHERE ID="+entryID;
            PreparedStatement pstat = connection.prepareStatement(s);
            if ( url!=null ) {
                url = url.trim();
            }
            pstat.setString(1,title);
            pstat.setString(2,url);
            pstat.setString(3,comments);
            int rows = pstat.executeUpdate();
            System.out.println("updated entry: "+entryID);
            pstat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
            error("Error updating entry "+entryID, sqle);
        }
        finally {
            try {connection.rollback();} catch (SQLException e2) {
                error("Error rolling back: ",e2);
            }
        }
    }

    public void hideGroupEntry(int entryID) {
        try {
            System.out.println("Attempt update of entry "+entryID);
            connection.setAutoCommit(false);
            String s="UPDATE ENTRY SET HIDDEN=? WHERE ID="+entryID;
            PreparedStatement pstat = connection.prepareStatement(s);
            pstat.setInt(1,1);
            int rows = pstat.executeUpdate();
            System.out.println("hid entry: "+entryID);
            pstat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
            error("Error hiding entry "+entryID, sqle);
        }
        finally {
            try {connection.rollback();} catch (SQLException e2) {
                error("Error rolling back: ",e2);
            }
        }
    }

    public void deleteMember(int ID) {
        delete("MEMBER", ID);
    }

    public void subscribeToGroup(int memberID, int groupID, int access) {
        int ID = 0;
        try {
            connection.setAutoCommit(false);
            String s="INSERT INTO MEMBERSHIP (MEMBER,WHICHGROUP,ACCESS) "+
                    "VALUES (?,?,?)";
            PreparedStatement pstat = connection.prepareStatement(s);
            ID = getUniqueEntityID();
            pstat.setInt(1,memberID);
            pstat.setInt(2,groupID);
            pstat.setInt(3,access);
            int rows = pstat.executeUpdate();
            pstat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
            error("Error inserting member into group group",sqle);
        }
        catch (EntityDBException db) {
            error("Error getting unique ID ", db);
        }
        finally {
            try {connection.rollback();} catch (SQLException e2) {
                error("Error rolling back ",e2);
            }
        }
    }

    public void unSubscribeFromGroup(int memberID, int groupID) {
        int ID = 0;
        try {
            connection.setAutoCommit(false);
            String s="DELETE FROM MEMBERSHIP WHERE MEMBER="+memberID+
                    " AND WHICHGROUP="+groupID;
            Statement stat = connection.createStatement();
            int rows = stat.executeUpdate(s);
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
            error("Error deleting membership access ",sqle);
        }
        finally {
            try {connection.rollback();} catch (SQLException e2) {
                error("Error rolling back ",e2);
            }
        }
    }

    public void updateMembershipAccessRights(int memberID, int groupID, int access) {
        int ID = 0;
        try {
            connection.setAutoCommit(false);
            String s="UPDATE MEMBERSHIP SET ACCESS="+access+" WHERE MEMBER="+memberID+
                    " AND WHICHGROUP="+groupID;
            Statement stat = connection.createStatement();
            int rows = stat.executeUpdate(s);
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
            error("Error updating membership access ",sqle);
        }
        finally {
            try {connection.rollback();} catch (SQLException e2) {
                error("Error rolling back ",e2);
            }
        }
    }

    public void deleteGroupSubscription(int memberID, int groupID) {
        try {
            connection.setAutoCommit(false);
            String q="DELETE FROM MEMBERSHIP where whichgroup="+groupID+" AND member="+memberID;
            Statement stat = connection.createStatement();
            System.out.println(q);
            int rows = stat.executeUpdate(q);
            if ( rows!=1 ) {
                error("No such membership for whichgroup="+groupID+" AND member="+memberID);
            }
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
            error("Error deleting entity: ",sqle);
        }
        finally {
            try {connection.rollback();} catch (SQLException e2) {
                error("Error rolling back: ",e2);
            }
        }
    }

    public QueryResultSet getAllMemberships() {
        QueryResultSet rs = null;
        try {
            rs = query("SELECT MEMBER,WHICHGROUP,ACCESS FROM MEMBERSHIP");
        }
        catch (SQLException sqle) {
            error("Error getting membership: ", sqle);
            rs = null;
        }
        return rs;
    }

    /* Return a Vector<Integer> for a particular member;  Consult MEMBERSHIP table. */
    /*
    public Vector getMembershipGroupDescriptorIDs(int memberID) {
        Vector results = new Vector(100);
        try {
            connection.setAutoCommit(false);
            String q="SELECT WHICHGROUP FROM MEMBERSHIP WHERE MEMBER="+memberID;
			Statement stat = connection.createStatement();
			ResultSet rs = stat.executeQuery(q);
			if ( !rs.next() ) {
				error("No group descriptors for member="+memberID);
			}
            else {
                results.addElement(new Integer(rs.getInt(1)));
            }
            rs.close();
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error inserting entity: ",sqle);
            results = null;
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}
        return results;
    }
    */

    // ENTRIES

    public Vector getGroupEntriesForAuthorInGroup(int memberID, int groupID) {
        return getGroupEntriesForCondition("WHERE author="+memberID+" AND whichgroup="+groupID);
    }

    public Vector getAllGroupEntries() {
        return getGroupEntriesForCondition("");
    }

    public Vector getGroupEntriesForAuthor(int ID) {
        return getGroupEntriesForCondition("WHERE author="+ID);
    }

    /** Return a Vector of GroupEntry objects */
    public Vector getGroupEntries(int ID) {
        return getGroupEntriesForCondition("WHERE whichgroup="+ID);
    }

    public GroupEntry getGroupEntry(int ID) {
        Vector v = getGroupEntriesForCondition("WHERE ID="+ID);
        if ( v==null || v.size()==0 ) {
            return null;
        }
        return (GroupEntry)v.elementAt(0);
    }

    protected Vector getGroupEntriesForCondition(String condition) {
        Vector results = new Vector(100);
        try {
            connection.setAutoCommit(false);
            String and = "WHERE";
            if ( condition.length()>0 ) {
                and = "AND";
            }
            String q="SELECT * FROM ENTRY "+condition+" "+and+" (hidden is null OR hidden=0) ORDER BY CREATED DESC";
			Statement stat = connection.createStatement();
			ResultSet rs = stat.executeQuery(q);
			while ( rs.next() ) {
                if ( rs.getInt("whichgroup")==0 ) {
                    error("group of 0 for entry: "+rs.getInt("ID"));
                    continue;
                }
                GroupEntry e = new GroupEntry();
                e.setID(rs.getInt("ID"));
                e.setGroupID(rs.getInt("whichgroup"));
                e.setCreated(rs.getTimestamp("created"));
                e.setAuthorID(rs.getInt("author"));
                e.setGroupID(rs.getInt("whichgroup"));
                e.setTitle(rs.getString("title"));
                e.setUrl(rs.getString("url"));
                e.setComments(rs.getString("comments"));
                results.addElement(e);
            }
            rs.close();
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error inserting entity: ",sqle);
            results = null;
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}
        return results;
    }

    public void deleteGroupEntry(int ID) {
        delete("ENTRY", ID);
    }

    public int insertGroupEntry(int authorID,
                                  int groupID,
                                  String title,
                                  String url,
                                  String comments)
    {
        int ID = 0;
        try {
            connection.setAutoCommit(false);
            String s="INSERT INTO ENTRY (ID,CREATED,AUTHOR,WHICHGROUP,TITLE,URL,COMMENTS) "+
                     "VALUES (?,?,?,?,?,?,?)";
            PreparedStatement pstat = connection.prepareStatement(s);
            ID = getUniqueEntityID();
            pstat.setInt(1,ID);
            pstat.setTimestamp(2,getCurrentTimestamp());
            pstat.setInt(3,authorID);
            pstat.setInt(4,groupID);
            pstat.setString(5,title);
            pstat.setString(6,url);
            pstat.setString(7,comments);
			int rows = pstat.executeUpdate();
            pstat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error inserting group entry: ",sqle);
		}
        catch (EntityDBException db) {
			error("Error getting unique ID: ",db);
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}
        return ID;
    }

    // GENERIC

    public void delete(String table, int ID) {
        try {
            connection.setAutoCommit(false);
            String q="DELETE FROM "+table+" where ID="+ID;
			Statement stat = connection.createStatement();
            System.out.println(q);
			int rows = stat.executeUpdate(q);
			if ( rows!=1 ) {
				error("No such descriptor for ID or other problem in "+table+": "+ID);
			}
            stat.close();
            connection.commit();
        }
        catch (SQLException sqle) {
			error("Error deleting entity: ",sqle);
		}
		finally {
			try {connection.rollback();} catch (SQLException e2) {
				error("Error rolling back: ",e2);
			}
		}
    }

    /** Get a unique EID.
     */
    private int getUniqueEntityID()
		throws SQLException, EntityDBException
    {
		CallableStatement cstat = connection.prepareCall(
										 "call getNextEntityID"
										 );
		int EID = 0;
		try {
			ResultSet rs = cstat.executeQuery();
			rs.next();
			EID = rs.getInt("ID");
            rs.close();
            cstat.close();
            cstat=null;
            connection.commit();
		}
		finally {
			if ( cstat!=null ) {
				cstat.close();
			}
		}
		return EID;
    }

    // DATABASE MISC

    public static java.sql.Timestamp getCurrentTimestamp() {
		return new java.sql.Timestamp(getCurrentDateInMS());
    }

    public static long getCurrentDateInMS() {
		java.util.Date date = new java.util.GregorianCalendar().getTime();
		long msdate = date.getTime();
		return msdate;
    }

    /** Initialize the connection pool; only allow one thread to come in
	 *  here at a time so only one person sees broker as null.  Return
     *  true if all is well else false.
	 */
	public synchronized static boolean setupDBBroker() {
		boolean isOk = true;
        if ( broker!=null ) {
			return isOk; // already setup; prevent multiple start ups
		}

		// First time? Set up connection broker
		String dbURL = "jdbc:solid://127.0.0.1:1317";
		String driver = "solid.jdbc.SolidDriver";
		String username = "dba";
		String password = "squeal";
		String logFile = BROKER_LOG_FILE;
		try {
			broker = new DBConnectionBroker(driver, dbURL, username, password,
											MIN_CONNECTIONS, MAX_CONNECTIONS,
											logFile,
											BROKER_CLEANUP_INTERVAL);
		}
		catch (Exception e) {
			ErrorService.instance().panic("can't get DB broker", e, null);
            isOk = false;
		}
		if ( broker==null ) {
			ErrorService.instance().panic("can't get DB broker", null, null);
            isOk = false;
		}
        return isOk;
	}

	public synchronized static void shutdown() throws SQLException {
		broker.destroy(1000);
	}

    public static void error(String err) {
		ErrorService.instance().error(err);
    }

    public static void error(String err, Exception e) {
		ErrorService.instance().error(err, e);
    }
}
