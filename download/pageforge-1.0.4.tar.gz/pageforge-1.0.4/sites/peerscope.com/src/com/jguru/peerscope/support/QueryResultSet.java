/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.support;

import java.util.Vector;
import java.util.Hashtable;

/** This object stores rows of data (Vector<Object[]>) like a db query ResultSet, but is not
 *  at all dependent on SQL types.  It is a generic set of rows of columns.
 */
public class QueryResultSet {
    public static final int INITIAL_NUM_ROWS = 100;
    protected Vector rows = null;
    protected int columns = 0;
    protected String[] columnNames;
    protected boolean distinct = false;

    /** Type name from which the columns come from */
    protected String tableName;

    public QueryResultSet() {
    }

    public QueryResultSet(int c) {
		columns = c;
    }

    public QueryResultSet(int r, int c) {
		rows = new Vector(r);
		columns = c;
    }

    /** Create a result set from two String vectors; make into Vector
     *  of arrays
     */
    public QueryResultSet(Vector a, Vector b) {
		// make sure vectors are same size
		b.ensureCapacity(a.size());
		a.ensureCapacity(b.size());
		columns = 2;
		for (int i=0; i<a.size(); i++) {
			Object[] arr = new Object[2];
			arr[0] = a.elementAt(i);
			arr[1] = b.elementAt(i);
			addRow(arr);
		}
    }

    public int numRows() {
		if ( rows==null ) {
			return 0;
		}
		return rows.size();
    }

    public void setTableName(String type) {
		this.tableName = type;
    }

    public String getTableName() {
		return tableName;
    }

    public void setColumnNames(String[] names) {
		columnNames = names;
    }

    public String[] getColumnNames() {
		return columnNames;
    }

    public void setDistinct(boolean d) {
		distinct = d;
    }

    public boolean isDistinct() {
		return distinct;
    }

    public int getColumnIndex(String name) {
		if ( columnNames==null ) {
			return -1;
		}
		for (int i=0; i<columnNames.length; i++) {
			if ( columnNames[i].equals(name) ) {
				return i;
			}
		}
		return -1;
    }

    public String getColumnName(int i) {
		if ( columnNames==null ) {
			throw new IllegalArgumentException("Column name list is empty");
		}
		return columnNames[i];
    }

    public Object getObject(int r, int c) {
		if ( rows==null ) {
			throw new IllegalArgumentException("QueryResultSet is empty");
		}
		Object[] row = (Object[]) rows.elementAt(r);
		if ( row==null ) {
			return null;
		}
		return row[c];
    }

    public void setObject(Object o, int r, int c) {
		if ( rows==null ) {
			throw new IllegalArgumentException("QueryResultSet is empty");
		}
		if ( r<0 || r>=rows.size() ) {
			throw new IllegalArgumentException("row "+r+" does not exist");
		}
		Object[] row = (Object[]) rows.elementAt(r);
		if ( row==null ) {
			throw new IllegalArgumentException("row "+r+" does not exist");
		}
		if ( c<0 || c>=columns ) {
			throw new IllegalArgumentException("column "+c+" does not exist in row "+r);
		}
		row[c]=o;
    }

    public void setColumns(int c) {
		columns = c;
    }

    public int numColumns() {
		return columns;
    }

    public Vector getRows() {
		return rows;
    }

    public Object[] getRow(int i) {
		if ( rows==null ) {
			throw new IllegalArgumentException("QueryResultSet is empty");
		}
		return (Object[]) rows.elementAt(i);
    }

    public void addRow(Object[] row) {
		if ( rows==null ) {
			rows = new Vector(INITIAL_NUM_ROWS);
		}
		rows.addElement(row);
    }

    public String toString() {
		StringBuffer buf = new StringBuffer(30000);
		if ( tableName!=null ) {
			buf.append("Rows of "+tableName+" properties\n");
		}
		for (int col=0; columnNames!=null && col<columnNames.length; col++) {
			buf.append('\t');
			buf.append(columnNames[col]);
		}
		buf.append('\n');
		for (int r=0; r<numRows(); r++) {
			Object[] data = (Object[])rows.elementAt(r);
			for (int c=0; c<columns; c++) {
				buf.append('\t');
				buf.append(data[c]);
				/*
				if ( data[c]!=null ) {
					buf.append("("+data[c].getClass().getName()+")");
				}
				*/
			}
			buf.append('\n');
		}
		return buf.toString();
    }

    /** Return a column of data as a vector */
    public Vector toVector(String colName) {
		return toVector(getColumnIndex(colName));
    }

    /** Return a column of data as a vector */
    public Vector toVector(int col) {
		Vector v = new Vector(50);
		if ( col<0 ) {
			throw new IllegalArgumentException("negative column index to toVector()");
		}
		for (int r=0; r<numRows(); r++) {
			Object[] data = (Object[])rows.elementAt(r);
			Object value = data[col];
			v.addElement(value);
		}
		return v;
    }

    /** Create a hash table that maps one column to another.  You
     *  must specify the from and to columns to use.  For example,
     *     authorNameToID = rs.toMap("name","ID");
     */
    public Hashtable toMap(String fromProp, String toProp) {
		return toMap(getColumnIndex(fromProp), getColumnIndex(toProp));
    }

    /** Create a hash table that maps one column to another.  You
     *  must specify the from and to columns indices to use.  For example,
     *     authorNameToID = rs.toMap(1,2);
     */
    public Hashtable toMap(int fromCol, int toCol) {
		if ( fromCol<0 || toCol<0 ) {
			throw new IllegalArgumentException("negative column index to toMap()");
		}
		Hashtable h = new Hashtable(100);
		for (int r=0; r<numRows(); r++) {
			Object[] data = (Object[])rows.elementAt(r);
			Object key = data[fromCol];
			Object value = data[toCol];
			// do not add it no data there
			if ( value!=null ) {
				h.put(key, value);
			}
		}
		return h;
    }

    /** Sort result set by a column name */
    public void sort(final String colName) {
		sort(getColumnIndex(colName), 1);
    }

    public void sort(final String colName, int direction) {
		sort(getColumnIndex(colName), direction);
    }

    public void sort(final int col) {
		sort(col, 1);
    }

    /** Sort result set by a column index; direction: -1 reverse, 1 normal */
    public void sort(final int col, final int direction) {
		com.jguru.peerscope.support.QuickSortCompare compare =
			new com.jguru.peerscope.support.QuickSortCompare() {
					public boolean isGreaterOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						String a = (String)sa1[col];
						String b = (String)sa2[col];
						return a.compareTo(b) >= 0;
					}
					public boolean isLessOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						String a = (String)sa1[col];
						String b = (String)sa2[col];
						return a.compareTo(b) <= 0;
					}
				};
        com.jguru.peerscope.support.QuickSortCompare compareInteger =
			new com.jguru.peerscope.support.QuickSortCompare() {
					public boolean isGreaterOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						int a = ((Integer)sa1[col]).intValue();
						int b = ((Integer)sa2[col]).intValue();
						return a>=b;
					}
					public boolean isLessOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						int a = ((Integer)sa1[col]).intValue();
						int b = ((Integer)sa2[col]).intValue();
						return a<=b;
					}
				};
        com.jguru.peerscope.support.QuickSortCompare compareLong =
			new com.jguru.peerscope.support.QuickSortCompare() {
					public boolean isGreaterOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						long a = ((Long)sa1[col]).intValue();
						long b = ((Long)sa2[col]).intValue();
						return a>=b;
					}
					public boolean isLessOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						long a = ((Long)sa1[col]).intValue();
						long b = ((Long)sa2[col]).intValue();
						return a<=b;
					}
				};
		com.jguru.peerscope.support.QuickSortCompare reverseCompare =
			new com.jguru.peerscope.support.QuickSortCompare() {
					public boolean isGreaterOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						String a = (String)sa1[col];
						String b = (String)sa2[col];
						return a.compareTo(b) <= 0;
					}
					public boolean isLessOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						String a = (String)sa1[col];
						String b = (String)sa2[col];
						return a.compareTo(b) >= 0;
					}
				};
        com.jguru.peerscope.support.QuickSortCompare reverseCompareInteger =
			new com.jguru.peerscope.support.QuickSortCompare() {
					public boolean isGreaterOrEqual(Object obj1, Object obj2) {
						// System.out.println("comparing "+obj1+", "+obj2);
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						int a = ((Integer)sa1[col]).intValue();
						int b = ((Integer)sa2[col]).intValue();
						return a<=b;
					}
					public boolean isLessOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						int a = ((Integer)sa1[col]).intValue();
						int b = ((Integer)sa2[col]).intValue();
						return a>=b;
					}
				};
        com.jguru.peerscope.support.QuickSortCompare reverseCompareLong =
			new com.jguru.peerscope.support.QuickSortCompare() {
					public boolean isGreaterOrEqual(Object obj1, Object obj2) {
						// System.out.println("comparing "+obj1+", "+obj2);
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						long a = ((Long)sa1[col]).intValue();
						long b = ((Long)sa2[col]).intValue();
						return a<=b;
					}
					public boolean isLessOrEqual(Object obj1, Object obj2) {
						Object[] sa1 = (Object[]) obj1;
						Object[] sa2 = (Object[]) obj2;
						long a = ((Long)sa1[col]).intValue();
						long b = ((Long)sa2[col]).intValue();
						return a>=b;
					}
				};
		if ( this.rows==null || this.rows.size()==0 ) {
			return;
		}
		if ( direction == -1 ) {
            if ( ((Object[])this.rows.elementAt(0))[col] instanceof Integer ) {
				com.jguru.peerscope.support.QuickSort.sort(this.rows, reverseCompareInteger);
			}
            else if ( ((Object[])this.rows.elementAt(0))[col] instanceof Long ) {
				com.jguru.peerscope.support.QuickSort.sort(this.rows, reverseCompareLong);
			}
			else {
				com.jguru.peerscope.support.QuickSort.sort(this.rows, reverseCompare);
			}
		}
		else {
            if ( ((Object[])this.rows.elementAt(0))[col] instanceof Integer ) {
				com.jguru.peerscope.support.QuickSort.sort(this.rows, compareInteger);
			}
            else if ( ((Object[])this.rows.elementAt(0))[col] instanceof Long ) {
				com.jguru.peerscope.support.QuickSort.sort(this.rows, compareLong);
			}
			else {
				com.jguru.peerscope.support.QuickSort.sort(this.rows, compare);
			}
		}
    }
}
