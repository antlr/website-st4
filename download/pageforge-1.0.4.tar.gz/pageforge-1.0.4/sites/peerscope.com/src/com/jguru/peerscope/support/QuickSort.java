/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
//////////////////////////////////////////////////////////////
//
// QuickSort sorts a vector of objects using each element's
// toString() method.
//
// Vector v = new Vector();
// v.addElement("X");
// ...
// v.addElement("M");
// QuickSort.sort(v);  // static usage
//   _or_
// QuickSort qs = new QuickSort(v);  // instance usage
// qs.sort();
//
// Author: Jerry Smith
//
//////////////////////////////////////////////////////////////

package com.jguru.peerscope.support;

import java.util.Enumeration;
import java.util.Stack;
import java.util.Vector;

public class QuickSort {
	private Vector v;

	private QuickSortCompare compare = // the default compare tool
		new QuickSortCompare() {
				public boolean isGreaterOrEqual(Object obj1, Object obj2) {
					return obj1.toString().compareTo(obj2.toString()) >= 0;
				}
				public boolean isLessOrEqual(Object obj1, Object obj2) {
					return obj1.toString().compareTo(obj2.toString()) <= 0;
				}
			};

	private static QuickSortCompare reverseCompareInteger =
		new com.jguru.peerscope.support.QuickSortCompare() {
				public boolean isGreaterOrEqual(Object obj1, Object obj2) {
					Integer a = (Integer)obj1;
					Integer b = (Integer)obj2;
					return a.compareTo(b) < 0; // true if actually less than
				}
				public boolean isLessOrEqual(Object obj1, Object obj2) {
					Integer a = (Integer)obj1;
					Integer b = (Integer)obj2;
					return a.compareTo(b) > 0; // true if actually greater than
				}
			};

	public static void sort(Vector v) {
		QuickSort qs = new QuickSort(v);
		qs.sort();
	}

	public static void reverseSortInteger(Vector v) {
		QuickSort qs = new QuickSort(v, reverseCompareInteger);
		qs.sort();
	}

	public static void sort(Vector v, QuickSortCompare compare) {
		QuickSort qs = new QuickSort(v, compare);
		qs.sort();
	}

	public QuickSort(Vector v) {
		this.v = v;
	}

	public QuickSort(Vector v, QuickSortCompare compare) {
		this.v = v;
		this.compare = compare;
	}

	public QuickSort() {
	}

	public void setVector(Vector v) {
		this.v = v;
	}

	public void sort() {
		Bounds b;
		int i, j;
		Stack s = new Stack();
		s.push(new Bounds(0, v.size() - 1));
		while (!s.empty()) {
			b = (Bounds) s.pop();
			while (b.upper > b.lower) {
				j = rearrange(b.lower, b.upper);
				if (j - b.lower > b.upper - j) {
					i = b.upper;
					b.upper = j - 1;
					s.push(b);
					b = new Bounds(j + 1, i);
				}
				else {
					i = b.lower;
					b.lower = j + 1;
					s.push(b);
					b = new Bounds(i, j - 1);
				}
			} // upper > lower
		} // not empty
	}

	private int rearrange(int lower, int upper) {
		Object obj = v.elementAt(lower);
		int j = lower; // somewhat inefficient for almost-sorted data
		int up = upper;
		int down = lower;
		while (true) {
			while (up > down && compare.isGreaterOrEqual(v.elementAt(up), obj))
				up--;
			j = up;
			if (up == down)
				break;
			v.setElementAt(v.elementAt(up), down);
			while (down < up && compare.isLessOrEqual(v.elementAt(down), obj))
				down++;
			j = down;
			if (down == up)
				break;
			v.setElementAt(v.elementAt(down), up);
		}
		v.setElementAt(obj, j);
		return j;
	}

	public static void main(String[] args) {
		//
		// default toString() comparison of objects in a vector:
		//
		Vector v = new Vector();
		v.addElement("Sue");
		v.addElement("Tom");
		v.addElement("Dick");
		v.addElement("Tom");
		v.addElement("Jane");
		QuickSort.sort(v);
		Enumeration e = v.elements();
		System.out.println("Sorted:");
		while (e.hasMoreElements())
			System.out.println(e.nextElement());
		//
		// comparison based on element two of tuples in a vector:
		//
		QuickSortCompare compare =
			new QuickSortCompare() {
					public boolean isGreaterOrEqual(Object obj1, Object obj2) {
						String[] sa1 = (String[]) obj1;
						String[] sa2 = (String[]) obj2;
						return sa1[1].compareTo(sa2[1]) >= 0;
					}
					public boolean isLessOrEqual(Object obj1, Object obj2) {
						String[] sa1 = (String[]) obj1;
						String[] sa2 = (String[]) obj2;
						return sa1[1].compareTo(sa2[1]) <= 0;
					}
				};
		v = new Vector();
		v.addElement(new String[] {"Sue", "San"});
		v.addElement(new String[] {"Tom", "Terrific"});
		v.addElement(new String[] {"Sandy", "Beach"});
		v.addElement(new String[] {"Tom", "Terrific"});
		v.addElement(new String[] {"Fred", "Flounder"});
		QuickSort.sort(v, compare);
		e = v.elements();
		System.out.println("Sorted:");
		while (e.hasMoreElements()) {
			String[] str = (String[]) e.nextElement();
			System.out.println(str[0] + " " + str[1]);
		}
	}

	class Bounds {
		int lower, upper;

		Bounds(int lower, int upper) {
			this.lower = lower;
			this.upper = upper;
		}

		Bounds(Bounds b) {
			lower = b.lower;
			upper = b.upper;
		}
	}
}
