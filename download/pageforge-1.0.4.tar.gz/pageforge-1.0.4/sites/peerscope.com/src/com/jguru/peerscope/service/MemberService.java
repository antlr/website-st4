/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.service;

import org.pageforge.service.SessionService;
import com.jguru.peerscope.support.QueryResultSet;
import com.jguru.peerscope.support.MultivaluedHashtable;
import com.jguru.peerscope.entity.Member;
import com.jguru.peerscope.entity.GroupDescriptor;
import com.jguru.peerscope.entity.GroupEntry;
import org.antlr.stringtemplate.StringTemplate;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Cookie;
import java.util.Hashtable;
import java.util.Vector;

public class MemberService {
    public static final String COOKIE_AUTOLOGIN = "auto_login";
    public static final String COOKIE_HASH = "unique_id";

    public static final String SESSION_INIT = "peerscope_init";
    public static final String SESSION_MEMBERCONTEXT = "peerscope_membercontext";
    public static final String SESSION_LOGGEDIN = "peerscope_loggedin";
    public static final String SESSION_ADMIN_LOGGEDIN = "peerscope_admin_loggedin";

    private static MemberService _instance;

    public static synchronized MemberService instance() {
		if(_instance == null) {
			_instance = new MemberService();
		}
		return _instance;
    }

    /** Map Integer member IDs to Member objects */
    protected Hashtable members = null;

    protected Hashtable mapEmailToMember = null;

    protected Hashtable mapUniqueHashToMember = null;

    /** Map Integer member IDs to Vector<Integer> of descriptor IDs include RO and RW memberships */
    protected MultivaluedHashtable memberGroupList = null;

    /** Map Integer member IDs to Vector<Integer> of descriptor IDs include only RW memberships.
     *  This is the list to pull up in the feed popup.
     */
    protected MultivaluedHashtable memberRWGroupList = null;

    /** Map Integer descriptor IDs to Vector<Integer> of member IDs with RW memberships only */
    protected MultivaluedHashtable groupMemberList = null;

    private MemberService() {
        System.out.println("Create MemberService");
        StorageService storage = StorageService.instance();
        storage.open();

        // MEMBERS
        Vector v = storage.getAllMembers();
        // map member IDs to members
        members = new Hashtable(1001);
        mapEmailToMember = new Hashtable(1001);
        mapUniqueHashToMember = new Hashtable(1001);
        for (int i=0; i<v.size(); i++) {
            Member u = (Member)v.elementAt(i);
            cacheAndIndex(u);
        }

        // MEMBERSHIP
        QueryResultSet rs = storage.getAllMemberships();
        memberGroupList = new MultivaluedHashtable(1001);
        memberRWGroupList = new MultivaluedHashtable(1001);
        groupMemberList = new MultivaluedHashtable(1001);
        for (int r=0; r<rs.numRows(); r++) {
            Integer memberID = (Integer)rs.getObject(r,0);
            Integer groupID = (Integer)rs.getObject(r,1);
            Integer access = (Integer)rs.getObject(r,2);
            cacheAndIndex(memberID, groupID, access);
        }

        storage.close();
    }

    private void cacheAndIndex(Integer memberID, Integer groupID, Integer access) {
        memberGroupList.put(memberID, groupID);
        if ( access.intValue()==GroupService.RW_ACCESS ) {
            groupMemberList.put(groupID, memberID); // reverse index
            memberRWGroupList.put(memberID, groupID);
        }
    }

    private void cacheAndIndex(Member u) {
        members.put(new Integer(u.getID()), u);
        mapEmailToMember.put(u.getEmail(), u);
        mapUniqueHashToMember.put(u.getUniqueHash(), u);
    }

    /** Let's other managers indicate when a group's membership has changed. */
    public void notifyMembershipAddition(int memberID, int groupID, int access) {
        cacheAndIndex(new Integer(memberID), new Integer(groupID), new Integer(access));
    }

    /** Wack a membership just before updating cache; to make sure no dups */
    private void invalidateMembership(Integer memberID, Integer groupID) {
        memberGroupList.remove(memberID, groupID);
        groupMemberList.remove(groupID, memberID); // reverse index
        memberRWGroupList.remove(memberID, groupID);
    }

    /** Wack index refs to a member. */
    private void invalidateMember(Member member) {
        /*
        System.out.println("invalidateMember...");
        System.out.println("members: "+members);
        System.out.println("mapEmailToMember: "+mapEmailToMember);
        System.out.println("mapUniqueHashToMember: "+mapUniqueHashToMember);
        */
        members.remove(new Integer(member.getID()));
        mapEmailToMember.remove(member.getEmail());
        mapUniqueHashToMember.remove(member.getUniqueHash());
        /*
        System.out.println("after members: "+members);
        System.out.println("after mapEmailToMember: "+mapEmailToMember);
        System.out.println("after mapUniqueHashToMember: "+mapUniqueHashToMember);
        */
    }

    /** register at min an email; generate password if necessary. */
    protected Member registerMemberDoNotEmail(String firstName,
                                              String lastName,
                                              String email,
                                              String password)
    {
        StorageService storage = StorageService.instance();
        storage.open();
        String hash = SessionService.instance().computeUniqueHash(email,password);
        System.out.println("creating hash for new user: "+hash);
        int ID = storage.insertMember(firstName,lastName,email,password,hash);
        // now reload from DB and cache
        Member member = storage.getMember(ID);
        storage.close();
        System.out.println("registered: "+member);

        cacheAndIndex(member);

        return member;
    }

    /** register at min an email; generate password if necessary. */
    public Member updateMember(int memberID,
                               String firstName,
                               String lastName,
                               String email,
                               String password,
                               int notifications)
    {
        // first invalidate OLD indices
        Member oldMember = getMember(memberID);
        invalidateMember(oldMember);

        StorageService storage = StorageService.instance();
        storage.open();
        storage.updateMember(memberID,firstName,lastName,email,password,notifications);
        // now reload from DB and cache
        Member member = storage.getMember(memberID);
        storage.close();
        System.out.println("updated: "+member);

        // insert new member object into caches
        cacheAndIndex(member);

        return member;
    }

    public Member registerMember(String firstName,
                                 String lastName,
                                 String email,
                                 String password)
    {
        Member member =
                registerMemberDoNotEmail(firstName,
                                         lastName,
                                         email,
                                         password);
        sendRegistrationEmail(member);
        return member;
    }

    /** Given an email address add that person to the RW subscriber list
     *  for a group.  If the person is not registered, register their
     *  email and send them email asking them to complete registration.
     */
    public void subscribeEmailToGroup(int groupID,
                                        String email,
                                        String note)
    {
        if ( email==null ) {
            return;
        }
        email = email.trim().toLowerCase();
        Member member = getMemberByEmail(email);
        if ( member==null ) {
            // register if not already registered
            System.out.println("registering new member: "+email);
            String password = generatePassword();
            member = registerMemberDoNotEmail(null,null,email,password);
            GroupDescriptor cd = GroupService.instance().getGroupDescriptor(groupID);
            sendRegistrationAndMembershipEmail(member, cd, note);
        }
        // now actually do the membership entry
        // if person is already a member of this list, do nothing
        if ( isRWMemberOfGroup(member.getID(), groupID) ) {
            System.out.println(email+" already RW member of group "+groupID);
            return; // already there...nothing to do.
        }
        StorageService storage = StorageService.instance();
        storage.open();
        // if person is already a member but RO, update to be RW
        if ( isROMemberOfGroup(member.getID(), groupID) ) {
            System.out.println(email+" is RO (updating) member of group "+groupID);
            storage.updateMembershipAccessRights(member.getID(), groupID, GroupService.RW_ACCESS);
        }
        else {
            System.out.println(email+" becoming RW (new) member of group "+groupID);
            storage.subscribeToGroup(member.getID(), groupID, GroupService.RW_ACCESS);
        }
        storage.close();
        invalidateMembership(new Integer(member.getID()), new Integer(groupID));
        cacheAndIndex(new Integer(member.getID()),
                      new Integer(groupID),
                      new Integer(GroupService.RW_ACCESS));
    }

    /** Subscribe this member as RO to a group */
    public void subscribeMemberToGroup(int memberID,
                                         int groupID)
    {
        Member member = getMember(memberID);
        if ( member==null ) {
            return; // weird, nobody there
        }
        // now actually do the membership entry
        // if person is already a member of this list, do nothing
        if ( isMemberOfGroup(memberID, groupID) ) {
            System.out.println(member.getEmail()+" already member of group "+groupID);
            return; // already there...nothing to do.
        }
        StorageService storage = StorageService.instance();
        storage.open();
        System.out.println(member.getEmail()+" becoming RO (new) member of group "+groupID);
        storage.subscribeToGroup(member.getID(), groupID, GroupService.RO_ACCESS);
        storage.close();
        // no need to invalidate as this membership is new
        cacheAndIndex(new Integer(member.getID()),
                      new Integer(groupID),
                      new Integer(GroupService.RO_ACCESS));
    }

    public void unSubscribeMemberToGroup(int memberID,
                                           int groupID)
    {
        Member member = getMember(memberID);
        if ( member==null ) {
            return; // weird, nobody there
        }
        // now actually do the membership entry
        // if person not member of this list, do nothing
        Vector descriptorIDs = memberGroupList.get(new Integer(memberID));
        if ( !descriptorIDs.contains(new Integer(groupID)) ) {
            return; // already there...nothing to do.
        }
        StorageService storage = StorageService.instance();
        storage.open();
        System.out.println(member.getEmail()+" unsubscribing from group "+groupID);
        storage.unSubscribeFromGroup(member.getID(), groupID);
        storage.close();
        invalidateMembership(new Integer(member.getID()), new Integer(groupID));
    }

    /** Get cached member; do not on-demand load from DB.  All members
     *  assumed to be in cache.
     */
    public Member getMember(int ID) {
        Member member = (Member)members.get(new Integer(ID));
        //System.out.println("returning cached member: "+member);
        return member;
    }

    /** Get cached member; do not on-demand load from DB.  All members
     *  assumed to be in cache.
     */
    public Member getMemberByEmail(String email) {
        if ( email==null ) {
            return null;
        }
        email = email.trim().toLowerCase();
        Member member = (Member)mapEmailToMember.get(email);
        return member;
    }

    /** Get cached member; do not on-demand load from DB.  All members
     *  assumed to be in cache.
     */
    public Member getMemberByUniqueHash(String hash) {
        Member member = (Member)mapUniqueHashToMember.get(hash);
        return member;
    }

    /** Return a Vector of Member objects that are members of this group */
    public Vector getGroupMembership(int groupID) {
        Vector memberIDs = groupMemberList.get(new Integer(groupID));
        Vector memberObjs = new Vector(memberIDs.size());
        for (int i=0; i<memberIDs.size(); i++) {
            Integer mID = (Integer)memberIDs.elementAt(i);
            Member m = getMember(mID.intValue());
            memberObjs.addElement(m);
        }
        return memberObjs;
    }

    /** Return a Vector of String emails for all members of this group
     *  that want per entry emails.
     */
    public Vector getGroupMembershipWithPerEntryNotificationEmails(int groupID) {
        Vector memberIDs = groupMemberList.get(new Integer(groupID));
        Vector memberObjs = new Vector(memberIDs.size());
        for (int i=0; i<memberIDs.size(); i++) {
            Integer mID = (Integer)memberIDs.elementAt(i);
            Member m = getMember(mID.intValue());
            if ( m!=null &&
                 m.getNotifications()==EmailService.NOTIFICATIONS_PER_ENTRY )
            {
                memberObjs.addElement(m.getEmail());
            }
        }
        return memberObjs;
    }

    /** Is this member a member of this group either RO or RW */
    public boolean isMemberOfGroup(int memberID, int groupID) {
        Vector groupIDs = memberGroupList.get(new Integer(memberID));
        if ( groupIDs!=null && groupIDs.contains(new Integer(groupID)) ) {
            return true;
        }
        return false;
    }

    public boolean isRWMemberOfGroup(int memberID, int groupID) {
        Vector memberIDs = groupMemberList.get(new Integer(groupID));
        if ( memberIDs!=null && memberIDs.contains(new Integer(memberID)) ) {
            return true;
        }
        return false;
    }

    public boolean isROMemberOfGroup(int memberID, int groupID) {
        Vector allMemberships = memberGroupList.get(new Integer(memberID));
        Vector rwMemberships = memberRWGroupList.get(new Integer(memberID));
        Integer cID = new Integer(groupID);
        if ( (allMemberships!=null && allMemberships.contains(cID)) &&
             (rwMemberships==null||!rwMemberships.contains(cID)))
        {
            // if member, but not in rw, then must be ro membership
            return true;
        }
        // else it's rw or not member
        return false;
    }

    /** Get the list of groups to which memberID is subscribed (if you are owner,
     *  you are automatically added at group creation).  This is RO and RW memberships.
     */
    public Vector getGroupMembershipDescriptors(int memberID) {
        Vector descriptorIDs = memberGroupList.get(new Integer(memberID));
        return getGroupMembershipDescriptors(memberID, descriptorIDs);
    }

    public Vector getGroupMembershipDescriptorIDs(int memberID) {
        Vector descriptorIDs = memberGroupList.get(new Integer(memberID));
        return descriptorIDs;
    }

    /** Get the list of groups to which memberID is subscribed (if you are owner,
     *  you are automatically added at group creation).  Get only RW memberhsips.
     */
    public Vector getRWGroupMembershipDescriptors(int memberID) {
        Vector descriptors = memberRWGroupList.get(new Integer(memberID));
        System.out.println("getRWGroupMembershipDescriptors("+memberID+"): "+descriptors);
        return getGroupMembershipDescriptors(memberID, descriptors);
    }

    private Vector getGroupMembershipDescriptors(int memberID, Vector descriptorIDs) {
        if ( descriptorIDs==null || descriptorIDs.size()==0 ) {
            return null;
        }
        Vector descriptorObjs = new Vector(descriptorIDs.size());
        for (int i=0; i<descriptorIDs.size(); i++) {
            Integer dID = (Integer)descriptorIDs.elementAt(i);
            GroupDescriptor cd = GroupService.instance().getGroupDescriptor(dID.intValue());
            descriptorObjs.addElement(cd);
        }
        return descriptorObjs;
    }

    public boolean canSeeGroup(Member member, int groupID) {
        if ( member!=null && member.isAdministrator() ) {
            return true;
        }
        GroupDescriptor cd = GroupService.instance().getGroupDescriptor(groupID);
        if ( cd.getAccess()==GroupDescriptor.PUBLIC_ACCESS ) {
            return true;
        }
        // or, is this person a part of a private group
        if ( member!=null &&
             isRWMemberOfGroup(member.getID(), groupID) )
        {
            return true;
        }
        return false;
    }

    /** If member is author or owner of group */
    public boolean canEditGroupEntry(Member member, int entryID) {
        if ( member==null ) {
            return false;
        }
        GroupEntry entry = GroupService.instance().getGroupEntry(entryID);
        if ( entry==null ) {
            return false;
        }
        int groupID = entry.getGroupID();
        int authorID = entry.getAuthorID();
        GroupDescriptor cd =
                GroupService.instance().getGroupDescriptor(groupID);
        if ( cd==null ) {
            return false;
        }
        int ownerID = cd.getOwnerID();
        /*
        System.out.println("canEditGroupEntry: owner="+ownerID+
                 ", authorID="+authorID+", memberID="+member.getID());
        */
        if ( ownerID==member.getID() ||
             authorID==member.getID() )
        {
            return true;
        }
        return false;
    }

    // EMAIL STUFF

    protected void sendRegistrationEmail(Member member) {
        String from = "notifications@peerscope.com";
        String to = member.getEmail();
        String subject = "PeerScope.com Registration Notice";
        StringTemplate message =
            PeerscopeApplication.stringTemplatesLib.getInstanceOf("email/registration");
        message.setAttribute("newbie", member);
        try {
            EmailService.instance().sendEmail(from,to,subject,message.toString());
        }
        catch (Exception e) {
            ErrorService.instance().error("can't email registration to "+member.getEmail(), e);
        }
    }

    protected void sendRegistrationAndMembershipEmail(Member member, GroupDescriptor cd, String note) {
        try {
            Member owner = getMember(cd.getOwnerID());
            String from = owner.getEmail();
            String to = member.getEmail();
            String subject = owner.getFirstName()+" has invited you to join a Peerscope.com group";
            StringTemplate message =
                PeerscopeApplication.stringTemplatesLib.getInstanceOf("email/registration_and_invitation");
            message.setAttribute("group", cd);
            message.setAttribute("newbie", member);
            EmailService.instance().sendEmail(from,to,subject,message.toString());
        }
        catch (Exception e) {
            ErrorService.instance().error("can't email registration and subscription to "+member.getEmail(), e);
        }
    }

    protected void sendMembershipEmail(Member member, GroupDescriptor cd, String note) {
        Member owner = getMember(cd.getOwnerID());
        String from = owner.getEmail();
        String to = member.getEmail();
        String subject = owner.getFirstName()+" has invited you to join a Peerscope.com group";
        StringTemplate message =
            PeerscopeApplication.stringTemplatesLib.getInstanceOf("email/invitation");
        message.setAttribute("group", cd);
        message.setAttribute("newbie", member);
        try {
            EmailService.instance().sendEmail(from,to,subject,message.toString());
        }
        catch (Exception e) {
            ErrorService.instance().error("can't email registration and subscription to "+member.getEmail(), e);
        }
    }

    public void notifyGroupMembersOfPosting(int groupID, String title, String comments, Member member) {
        StringTemplate message =
            PeerscopeApplication.stringTemplatesLib.getInstanceOf("email/notify_posting");
        message.setAttribute("from", member);
        message.setAttribute("title", title);
        String groupName = GroupService.instance().getGroupName(groupID);
        String subject = "["+groupName+"] "+title;
        message.setAttribute("groupName", groupName);
        message.setAttribute("groupID", new Integer(groupID));
        if ( comments!=null ) {
            message.setAttribute("comments", comments);
        }
        Vector emails = MemberService.instance()
                .getGroupMembershipWithPerEntryNotificationEmails(groupID);
        emails.remove(member.getEmail()); // don't send to publisher
        EmailService.instance().sendEmailNonBlocking(
            member.getEmail(),
            emails,
            subject,
            message.toString()
        );
    }

    //   C O O K I E  S T U F F

    /** Find a cookie by name; return first found */
    public static Cookie getCookie(HttpServletRequest request, String name) {
        Cookie[] allCookies;

        if ( name==null ) {
            throw new IllegalArgumentException("cookie name is null");
        }

        allCookies = request.getCookies();
        if (allCookies != null) {
            for (int i=0; i < allCookies.length; i++) {
                Cookie candidate = allCookies[i];
                if (name.equals(candidate.getName()) ) {
                    return candidate;
                }
            }
        }

        return null;
    }

    /** Find a cookie by name; return first found */
    public static String getCookieValue(HttpServletRequest request,
                                        String name)
    {
        Cookie c = getCookie(request, name);
        if ( c!=null ) {
            return c.getValue();
        }
        return null;
    }

    /** Set a cookie by name */
    public static void setCookieValue(HttpServletResponse response,
                                      String name,
                                      String value)
    {
        Cookie c = new Cookie(name,value);
        c.setMaxAge( 3 * 30 * 24 * 60 * 60 );
        c.setPath( "/" );
        response.addCookie( c );
        // System.out.println("cookie set: ("+c.getName()+","+c.getValue()+")");
    }

    private void killAutoLoginCookie(HttpServletResponse response) {
        Cookie c = new Cookie(COOKIE_AUTOLOGIN,"false");
        c.setMaxAge( 0 ); // An age of 0 is defined to mean "delete cookie"
        c.setPath( "/" );
        response.addCookie( c );
        // System.out.println("cookie set: ("+c.getName()+","+c.getValue()+")");
    }

    // PASSWORD GENERATION

    private static final String[] words = {
        "a", "app", "dog", "cat", "zip", "rock",
        "saw", "mac", "pc", "sing", "run", "sit",
        "act", "pat", "hit", "rig", "pun", "sun",
        "vex", "vet", "pet", "row", "bog", "biz",
        "ply", "try", "qi", "hex", "pol", "pot",
        "pan", "man", "hand", "cup", "box", "fun",
        "bit", "byte", "pass", "word", "dude",
        "cool", "wow", "hip", "say", "it", "the",
        "and", "by", "from", "to", "over", "in",
        "down", "up", "end", "beg", "fry", "doc",
        "jazz", "pick", "stun", "yawn", "manx",
        "scan", "book", "ship", "fold", "card",
        "fork", "pen", "bill", "tums", "fizz",
        "crt", "cpu", "dns", "ip", "vi", "ed",
        "csh", "bash", "sh", "tsh", "zsh", "grep",
        "awk", "sed", "arch", "ash", "awk", "bash",
        "bsh", "cat", "cp", "cpio",
        "date", "dd", "df", "echo",
        "ex", "gawk", "gzip", "host",
        "kill", "ksh", "ln", "ls",
        "mail", "more", "mt", "mv",
        "nice", "ping", "ps", "pwd",
        "red", "rm", "rpm", "rvi",
        "sort", "stty", "su", "sync",
        "tar", "tcsh", "true", "zcat"
    };

    // generate a password that is at most 20 char long
    private static String generatePassword() {
        int r1 = (int)(Math.random() * words.length);
        int r2 = (int)(Math.random() * words.length);
        int n = (int)(Math.random() * 999999); // num from 0..999,999
        String pw = words[r1]+n+words[r2];
        if ( pw.length()>20 ) {
            return pw.substring(0,20);
        }
        return pw;
    }

}

