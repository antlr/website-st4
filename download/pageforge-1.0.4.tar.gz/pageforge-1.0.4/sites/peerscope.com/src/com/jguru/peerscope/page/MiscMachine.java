/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.page;

import org.pageforge.PageStateMachine;
import com.jguru.peerscope.page.PeerscopePage;
import com.jguru.peerscope.service.PeerscopeApplication;
import com.jguru.peerscope.service.EmailService;
import com.jguru.peerscope.service.MemberService;
import com.jguru.peerscope.entity.Member;
import org.antlr.stringtemplate.StringTemplate;

import java.util.Vector;

public class MiscMachine extends PageStateMachine {

    static {
        mapState("misc", "message", MessagePage.class, "misc/message");
        mapState("misc", "privacy", PrivacyPage.class, "misc/privacy");
        mapState("misc", "contact", ContactPage.class, "misc/contact");
        mapState("misc", "terms", TermsPage.class, "misc/terms");
        mapState("misc", "about", AboutPage.class, "marketing/about");
        mapState("misc", "password", RequestPasswordPage.class, "misc/request_password");
    }

    /** Any page in this machine is of this type */
    public static class MiscMachinePage extends PeerscopePage {
        /** Do a type conversion for brevity in references.  Damn.  I'd prefer
         *  "state." intead of "state().", but strict typing prevents it.
         *  Must repeat this in every state machine. :(
         */
        protected MiscMachine state() { return (MiscMachine)state; }
    }

    public static class MessagePage extends MiscMachinePage {
        public void generateBody(StringTemplate bodyST) throws Exception {
            requireParameter("msg");
            String msg = request.getParameter("msg");
            bodyST.setAttribute("msg", msg);
        }

        public boolean mustBeLoggedIn() { return false; }

        public String getTitle() { return "Message page"; }
    }

    public static class PrivacyPage extends MiscMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public String getTitle() { return "Privacy Policy"; }
    }

    public static class TermsPage extends MiscMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public String getTitle() { return "Terms Of Service"; }
    }

    public static class AboutPage extends MiscMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public String getTitle() { return "About PeerScope.com"; }
    }

    public static class ContactPage extends MiscMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public String getTitle() { return "Contact PeerScope.com"; }

        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("submit") ) {
                requireParameters(
                             new String[] {"name","comments","email"});
                String email = request.getParameter("email").trim().toLowerCase();
                String comments = request.getParameter("comments");
                String name = request.getParameter("name");

                String contactTarget =
                        PeerscopeApplication.getProperty("site.contact");

                EmailService.instance().sendEmail(email,
                        contactTarget,
                        "Peerscope contact",
                        name+" wrote:\n\n"+comments);

                doMessageRedirect("Your message concerning has been sent to the appropriate PeerScope.com person.");
            }
            else if ( eventName.equals("cancel") ) {
                doRedirect("/");
            }
        }
    }

    public static class RequestPasswordPage extends MiscMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("submit") ) {
                requireParameter("email");
                String email = request.getParameter("email").trim().toLowerCase();
                StringTemplate message =
                    PeerscopeApplication.stringTemplatesLib.getInstanceOf("email/password");
                Member member = MemberService.instance().getMemberByEmail(email);
                if ( member==null ) {
                    doMessageRedirect("Sorry.  I don't have any accounts registered under "+email+".");
                    return;
                }
                String password = member.getPassword();
                message.setAttribute("password", password);
                message.setAttribute("member", member);

                EmailService.instance().sendEmail("notifications@peerscope.com",
                        email,
                        "Your peerscope password",
                        message.toString());

                doMessageRedirect("Your password has been sent to "+email+".");
            }
        }
        public String getTitle() { return "Request Password"; }
    }

}

