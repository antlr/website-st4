/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.service;

import java.util.*;
import java.io.*;

/** Service that let's you write messages to various log files.
 *  You may rotate logs hourly, daily, monthly, or not at all.
 *
 *  File rolling is achieved by creating a filename based upon a
 *  name+timestamp+".log" where the timestamp truncation forces
 *  rolling at the appropriate time.  For example, portal log
 *  is to be rolled daily and, hence, the files should be called
 *  portal-20001101.log, portal-20001102.log, etc...  Any timestamp
 *  created on 20001102 that is truncated to just the date will result
 *  in the appropriate portal-20001102.log filename.  When the time
 *  flips to 20001103, the truncation results in a rolled file:
 *  portal-20001103.log.  Simple: an on-demand rolling. :)
 *
 *  Files are kept open, but flushed until time to roll.
 */
public class LogService {

    public static final String DEFAULT_ROLL_FREQUENCY = "daily";

    public static String ROOT = "/var/log/peerscope";

    private Hashtable logStreams = null;

    static class LogStream {
		public String name;
		public PrintWriter out;
		public String rollFreq;
		public String timestamp;
		public LogStream(String name, PrintWriter out,
						 String rollFreq, String timestamp)
		{
			this.name = name;
			this.out = out;
			this.rollFreq = rollFreq;
			this.timestamp = timestamp;
		}
    }

    private static LogService _instance;

    static synchronized LogService instance() {
		if ( _instance == null ) {
			_instance = new LogService();
		}
		return _instance;
    }

    private LogService() {
        System.out.println("Create LogService");
		logStreams = new Hashtable(11);
    }

    /** Write a message to a named stream.  If you've not used this stream
     *  since the start of the Java VM, a default (daily) roll freq is
     *  assume and that file is opened (for append if file actually exists).
     *  If src is non null, it's sent to the file with the time stamp.
     */
    public void log(String name, String msg) {
		if ( getLogStream(name) == null ) {
			// if we've never heard of it, set it up.
			// Stuff below will open file
			setRollFrequency(name, DEFAULT_ROLL_FREQUENCY);
		}
		// must be in logStreams hashable now
		LogStream s = (LogStream)getLogStream(name);

		// Only one thread can touch and/or write to LogStream object at once
		// We sync at this high level rather than at the LogStream accessors
		synchronized ( s ) {
			try {
				open(name); // ensure it's open and that it's latest file
			}
			catch (IOException io) {
				// can't use error manaager here as you'll get into a loop
				System.err.println("can't open log name "+name);
				io.printStackTrace(System.err);
			}
			s.out.print(getCurrentTimeStamp());
			String tname = Thread.currentThread().getName();
			s.out.print("("+tname+")");
            /*
            if ( src!=null ) {
				s.out.print("("+src+")");
			}
			else if ( tname!=null ) {
				s.out.print("("+tname+")");
			}
            */
			s.out.print(": ");
			s.out.println(msg);
			s.out.flush();
		}
    }

    /** Set the frequency of rolling for existing (open or unopen)
     *  stream.  The file is not physically created until you do
     *  an actual log() write.
     */
    public void setRollFrequency(String name, String freq) {
		if ( getLogStream(name) != null ) {
			LogStream s = (LogStream)getLogStream(name);
			s.rollFreq = freq;
		}
        else {
            LogStream s = new LogStream(name, null, freq, null);
            logStreams.put(name, s);
		}
    }

    public LogStream getLogStream(String name) {
        return (LogStream)logStreams.get(name);
    }

    /** Return a filename based upon name and timestamp */
    public static String getLogFilename(String name,
                                        String stamp) {
        return name+"-"+stamp+".log";
    }

    /** Return a filename based upon name and timestamp */
    public static String getFullyQualifiedLogFilename(
            String name,
            String stamp) {
        return getLogDirectory(name)+"/"+getLogFilename(name,stamp);
    }

    /** Return base dir where a log file would reside for name */
    public static String getLogDirectory(String name) {
        return ROOT+"/"+name;
    }

    //  S T A M P  R O U T I N E S

    /** Return the current truncated timestamp for freq */
    private static String getCurrentStamp(String freq) {
		if ( freq.equalsIgnoreCase("hourly") ) {
			return getCurrentHourlyStamp();
		}
		else if ( freq.equalsIgnoreCase("daily") ) {
			return getCurrentDailyStamp();
		}
		else if ( freq.equalsIgnoreCase("monthly") ) {
			return getCurrentMonthlyStamp();
		}
		else {
			return "";
		}
    }

    /** Return a time stamp tag accurate to the hour only (no min/sec):
     *  yyyymmdd_hh.
     */
    public static String getCurrentHourlyStamp() {
		GregorianCalendar calendar = new java.util.GregorianCalendar();
		int y = calendar.get(Calendar.YEAR);
		int m = calendar.get(Calendar.MONTH)+1; // zero-based for months
		int d = calendar.get(Calendar.DAY_OF_MONTH);
		int h = calendar.get(Calendar.HOUR_OF_DAY);
		String sy = String.valueOf(y);
		String sm = m<10?"0"+m:String.valueOf(m);
		String sd = d<10?"0"+d:String.valueOf(d);
		String sh = h<10?"0"+h:String.valueOf(h);
		return sy+sm+sd+"_"+sh;
    }

    /** Return a time stamp tag accurate to the day only
     *  (no day/hr/min/sec): yyyymmdd.
     */
    public static String getCurrentDailyStamp() {
		GregorianCalendar calendar = new java.util.GregorianCalendar();
		int y = calendar.get(Calendar.YEAR);
		int m = calendar.get(Calendar.MONTH)+1; // zero-based for months
		int d = calendar.get(Calendar.DAY_OF_MONTH);
		String sy = String.valueOf(y);
		String sm = m<10?"0"+m:String.valueOf(m);
		String sd = d<10?"0"+d:String.valueOf(d);
		return sy+sm+sd;
    }

    /** Return a time stamp tag accurate to the month only
     *  (no day/hr/min/sec): yyyymm.
     */
    public static String getCurrentMonthlyStamp() {
		GregorianCalendar calendar = new java.util.GregorianCalendar();
		int y = calendar.get(Calendar.YEAR);
		int m = calendar.get(Calendar.MONTH)+1; // zero-based for months
		String sy = String.valueOf(y);
		String sm = m<10?"0"+m:String.valueOf(m);
		return sy+sm;
    }

    /** Return a time stamp tag accurate to sec: yyyymmdd_hh.mm.ss */
    public static String getCurrentTimeStamp() {
		GregorianCalendar calendar = new java.util.GregorianCalendar();
		int y = calendar.get(Calendar.YEAR);
		int m = calendar.get(Calendar.MONTH)+1; // zero-based for months
		int d = calendar.get(Calendar.DAY_OF_MONTH);
		int h = calendar.get(Calendar.HOUR_OF_DAY);
		int min = calendar.get(Calendar.MINUTE);
		int sec = calendar.get(Calendar.SECOND);
		String sy = String.valueOf(y);
		String sm = m<10?"0"+m:String.valueOf(m);
		String sd = d<10?"0"+d:String.valueOf(d);
		String sh = h<10?"0"+h:String.valueOf(h);
		String smin = min<10?"0"+min:String.valueOf(min);
		String ssec = sec<10?"0"+sec:String.valueOf(sec);
		return sy+sm+sd+"_"+sh+"."+smin+"."+ssec;
    }

    //  F I L E  R O U T I N E S

    /** Ensure that a file is open to write to stream "name".
     *  If already open, get writer from hashtable.  If not
     *  open, do a rawOpen and save in hashtable.
     *
     *  If file is open already, then check to see if it's time
     *  to roll the file (close old, open new).
     *
     *  There must be a LogStream object in the hashtable
     *  for 'name' prior to calling open.
     *
     *  Not synchronized since the call to open() is
     *  in synch'd code block.
     */
    private void open(String name) throws IOException {
		if ( getLogStream(name) != null ) {
			LogStream s = (LogStream)getLogStream(name);
			if ( s.out == null ) {
				// hasn't been opened yet
				// System.err.println(name+" not opened yet; opening...");
				s.timestamp = getCurrentStamp(s.rollFreq);
				String filename = getLogFilename(name, s.timestamp);
				String dir = getLogDirectory(name);
				s.out = rawOpen(dir, filename);
			}
			else {
				// it's open, but is it time to roll?
				String oldStamp = s.timestamp;
				String currentStamp = getCurrentStamp(s.rollFreq);
				if ( !currentStamp.equals(oldStamp) ) {
					// ah ha!  Time for new file.
					s.out.close();
					String filename = getLogFilename(name, currentStamp);
					String dir = getLogDirectory(name);
					s.out = rawOpen(dir, filename);
				}
			}
		}
		else {
			throw new IllegalArgumentException("LogStream "+name+" does not exist");
		}
    }

    /** Do the raw file opening.  In case this file exists, we
     *  seek to the end (or create if not there).  Create dir
     *  if necessary.
     */
    private PrintWriter rawOpen(String dir,
								String filename)
		throws IOException
    {
		// System.err.println("start of rawOpen "+dir+"/"+filename);
		File baseDir = new File(dir);
		if ( !baseDir.exists() ) {
			// System.err.println("does not exist "+dir);
			// make sure base directory (and parents) exist
			if ( !baseDir.mkdirs() ) {
				// a problem (permissions?)
				System.err.println("Problem creating dir: "+dir+"; permissions?");
			}
		}
		filename = dir+"/"+filename;
		// System.err.println("opening raw "+filename);
		RandomAccessFile logFile = new RandomAccessFile(filename, "rw");
        logFile.seek(logFile.length());
        FileWriter fw = new FileWriter(logFile.getFD());
        PrintWriter writer = new PrintWriter(fw);
		return writer;
    }

}
