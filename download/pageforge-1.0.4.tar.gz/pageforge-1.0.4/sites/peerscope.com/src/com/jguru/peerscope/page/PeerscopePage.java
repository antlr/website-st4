/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.page;

import org.pageforge.*;

import java.util.Vector;

import com.jguru.peerscope.service.MemberService;
import com.jguru.peerscope.entity.Member;
import org.antlr.stringtemplate.StringTemplate;

public abstract class PeerscopePage extends Page {

    public Member getMember() {
        return (Member)getUser();
    }

    public void setDefaultPageAttributes(StringTemplate pageST) {
        if ( pageST==null ) {
            return;
        }
        if ( getMember()!=null ) {
            pageST.setAttribute("member", getMember());
        }
        pageST.setAttribute("fontTag", "<font face=\"arial,verdana,sanserif\" size=\"2\">");
        pageST.setAttribute("fontFace", "Helvetica,Arial");
        pageST.setAttribute("fontSize", "2");
        pageST.setAttribute("fontTitleSize", "2");
        pageST.setAttribute("title", getTitle());
        if ( getMember()==null ) {
            pageST.setAttribute("searchScope", "public");
        }
        else {
            // in general search only their groups of interest if logged in
            pageST.setAttribute("searchScope", "mygroups");
        }

        // the gutter needs to see a list of groups, set it here.
        if ( getMember()!=null ) {
            int memberID = getMember().getID();
            Vector groups = MemberService.instance().getGroupMembershipDescriptors(memberID);
            if ( groups!=null ) {
                pageST.setAttribute("allgroups",groups);
            }
        }
        else {
            // not logged in, show marketing.  Home page gets splash
            // others get gutter marketing
            if ( request.getRequestURL().toString().endsWith(".peerscope.com/") ) {
                pageST.setAttribute("show_splash_marketing", "true");
            }
            else {
                if ( !request.getRequestURL().toString().endsWith("/misc/about") ) {
                    pageST.setAttribute("show_gutter_marketing", "true");
                }
            }
        }
    }

}

