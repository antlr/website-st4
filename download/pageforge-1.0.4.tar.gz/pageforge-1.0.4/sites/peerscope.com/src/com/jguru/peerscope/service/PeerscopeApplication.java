/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.service;

import org.antlr.stringtemplate.StringTemplateGroup;

import java.util.TimeZone;

public class PeerscopeApplication {
    public static String timeLaunched = null;

    /** Indicate we have not initialized the app yet.  PageDispatcher
     *  will call initialize upon first page invocation, which starts
     *  init process and clears this var immediately so next
     *  PeerscopePage doesn't try to init app again.
     *
     *  Only a PageController ctor should invoke intialize() so that
     *  things like command-line tools have no change of launching
     *  a complete portal init w/o meaning too.
     */
    private static boolean initialized = false;
    private static boolean initPhase = false;
    private static boolean devLaunch = true;

    /** This is the current and only "skin"; pull templates from this
     *  group.
     */
    public static StringTemplateGroup stringTemplatesLib =
            new StringTemplateGroup("default",
                                    "/usr/local/peerscope/lib/templates",
                                    "$", "$");

    static {
        // Force timezone to be CA time
        TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
        TimeZone.setDefault(tz);
        stringTemplatesLib.setRefreshInterval(0); // don't cache
	}

    public synchronized static void initialize() {
        if ( initialized || initPhase ) {  // only allow one of these threads to start
            return;
        }
        initPhase = true;
        System.out.println("initialization; first thread in="+Thread.currentThread().getName());
        // now, launch a thread to init site in background
        // original thread that started up a page will come here, launch
        // init and then immediately meditate.
        if ( devLaunch ) {
            System.out.println("PeerScope: begin initialization");
            timeLaunched = LogService.instance().getCurrentTimeStamp();
            systemInitialize();
            // don't conflict with thread that started us
            synchronized (PeerscopeApplication.class) {
                initialized = true;
                initPhase = false;  // no longer busy
            }
            System.out.println("PeerScope: end initialization");
        }
        else {
            Runnable runnable =
                    new Runnable() {
                        public void run() {
                            System.out.println("PeerScope: begin initialization");
                            timeLaunched = LogService.instance().getCurrentTimeStamp();
                            systemInitialize();
                            // don't conflict with thread that started us
                            synchronized (PeerscopeApplication.class) {
                                initialized = true;
                                initPhase = false;  // no longer busy
                            }
                            System.out.println("PeerScope: end initialization");
                        }
                    };
            new Thread(runnable).start();
        }
    }

    private static void systemInitialize() {
        LogService.instance();
        ErrorService.instance();
        GroupService.instance();
        MemberService.instance();
    }

    public static boolean openForBusiness() {
        return initialized;
    }

    public static boolean isLiveSite() {
        return true;
    }

    public static String getProperty(String name, String defaultValue) {
        if ( name==null ) {
            return null;
        }
        // hardcode for now
        if ( name.equals("smtp.server") ) {
            return "127.0.0.1";
        }
        if ( name.equals("smtp.failover") ) {
            return "127.0.0.1";
        }
        /*
        if ( name.equals("smtp.server") ) {
            return "192.168.5.101";
        }
        if ( name.equals("smtp.failover") ) {
            return "127.0.0.1";
        }
        */
        if ( name.equals("site.contact") ) {
            return "parrt@peerscope.com";
        }
        return null;
    }

    public static String getProperty(String name) {
        return getProperty(name, null);
    }

    /** Shutdown db connections etc... */
    public static void shutdown() throws Exception {
        ErrorService.instance().notice("peerscope shutdown...");
        StorageService.shutdown();
        System.exit(0);
    }

}
