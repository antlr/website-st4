/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.page.group;

import org.pageforge.*;
import org.pageforge.service.SessionService;
import org.pageforge.support.Utils;
import org.pageforge.support.StreamBuffer;
import org.pageforge.support.VerifyException;
import org.pageforge.support.MustLoginException;
import com.jguru.peerscope.page.PeerscopePage;
import com.jguru.peerscope.service.GroupService;
import com.jguru.peerscope.service.MemberService;
import com.jguru.peerscope.service.PeerscopeApplication;
import com.jguru.peerscope.support.*;
import com.jguru.peerscope.entity.GroupDescriptor;
import com.jguru.peerscope.entity.Member;
import com.jguru.peerscope.entity.GroupEntry;
import org.antlr.stringtemplate.StringTemplate;
import com.jguru.portal.service.ServiceManager;

import java.util.Vector;
import java.net.URLEncoder;

public class GroupMachine extends PageStateMachine {

    static {
        mapState("group", "view", ViewGroupPage.class, "group/view");
        mapState("group", "jguru", ViewJGuruGroupPage.class, "group/jguru");
        mapState("group", "rss", ViewGroupRSSPage.class);
        mapState("group", "add", AddGroupPage.class, "group/add");
        mapState("group", "register_add", RegisterAddGroupPage.class, "group/register_add");
        mapState("group", "list", ListGroupsPage.class, "group/list");
        mapState("group", "list_public", ListPublicGroupsPage.class, "group/list_public");
        mapState("group", "feed_button", FeedButtonPage.class, "group/feed_button");
        mapState("group", "feed_popup", FeedPopup.class, "group/feed_popup");
        mapState("group", "feed_popup_login", FeedPopupLogin.class, "member/login");
        mapState("group", "feed", Feed.class, "group/feed_popup");
        mapState("group", "feedmsg", FeedPopupMsg.class);
        mapState("group", "manage", ManageListPage.class, "group/manage");
        mapState("group", "subscribe", SubscribePage.class);
        mapState("group", "edit", EditCommentsPage.class, "group/edit");
        mapState("group", "delete", DeletePage.class, "group/delete");
        //mapState("group", "visibility", HidePage.class, "group/visibility");
    }

    /** Any page in this machine is of this type */
    public static class GroupMachinePage extends PeerscopePage {
        /** Do a type conversion for brevity in references.  Damn.  I'd prefer
         *  "state." intead of "state().", but strict typing prevents it.
         *  Must repeat this in every state machine. :(
         */
        protected GroupMachine state() { return (GroupMachine)state; }
    }

    public static class FeedButtonPage extends GroupMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public String getTitle() { return "How to feed your PeerScope groups"; }
    }

    public static class FeedPopupLogin extends GroupMachinePage {
        public StringTemplate getPageStringTemplate() {
            return PeerscopeApplication.stringTemplatesLib.getInstanceOf("group/feed_popup_page");
        }
        public boolean mustBeLoggedIn() { return false; }
        public void generateBody(StringTemplate bodyST) throws Exception {
            String redirect = request.getParameter("redirect");
            if ( redirect==null ) {
                redirect = "/group/feed_popup?url=fill+in&title=fill+in";
            }
            // reuse normal login template, just set different target
            String msg = request.getParameter("msg");
            if ( msg==null ) {
                msg = "Please log in";
            }
            bodyST.setAttribute("msg", msg);
            bodyST.setAttribute("target", "/group/feed_popup_login");
            bodyST.setAttribute("redirect",(redirect));
        }
        public String getTitle() { return "Login"; }
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("login") ) {
                requireParameters(new String[] {"email", "password"});
                String email = request.getParameter("email").toLowerCase();
                String password = request.getParameter("password");
                String redirect = request.getParameter("redirect");
                System.out.println("redirect is "+redirect);
                boolean ok =
                        SessionService.instance().login(request,response,session,email,password);
                if ( ok ) {
                    if ( redirect==null ) {
                        redirect="/group/feed_popup?url=fill+in&title=fill+in";
                    }
                    doRedirect(redirect);
                }
                else {
                    String msg = "Sorry.  Problems logging in email: "+
                    "<b><tt>"+email+"</tt></b>.  You an either try again or "+
                            "<a target=_blank href=\"/misc/password\"><b>request your password</b></a>.";
                    if ( redirect==null ) {
                        redirect="/group/feed_popup?url=fill+in&title=fill+in";
                    }
                    doRedirect("/group/feed_popup_login?redirect="+
                            URLEncoder.encode(redirect)+
                            "&msg="+URLEncoder.encode(msg));
                }
            }
        }
    }

    public static class FeedPopup extends GroupMachinePage {
        public StringTemplate getPageStringTemplate() {
            return PeerscopeApplication.stringTemplatesLib.getInstanceOf("group/feed_popup_page");
        }
        public boolean mustBeLoggedIn() { return false; }
        public void generateBody(StringTemplate bodyST) throws Exception {
            String title = request.getParameter("title");
            String url = request.getParameter("url");
            if ( title!=null ) {
                bodyST.setAttribute("title",title);
            }
            if ( url!=null ) {
                bodyST.setAttribute("url",url);
            }
            if ( getMember()==null ) {
                doRedirect("/group/feed_popup_login?redirect="+
                        URLEncoder.encode("/group/feed_popup?url="+url+"&title="+title));
                return;
            }
            bodyST.setAttribute("target",getNodeURL("feed_popup"));
            int memberID = getMember().getID();
            Vector groups = MemberService.instance().getRWGroupMembershipDescriptors(memberID);
            if ( groups==null ) {
                doRedirect("/group/feedmsg?msg=Sorry.+You+are+not+currently+a+participating+member+of+any+group.");
                return;
            }
            if ( groups!=null && groups.size()==1 ) {
                bodyST.setAttribute("onlyOneGroup","true");
            }
            bodyST.setAttribute("groups",groups);
        }
        public void processEvent(String eventName) throws Exception {
            if ( getMember()==null ) {
                doErrorRedirect("You must be logged in to feed your PeerScope.com groups.");
            }
            if ( eventName.equals("submit") ) {
                System.out.println("process event submit in FeedPopupPage");
                requireParameters(new String[] {"title","url","group"});
                String title = request.getParameter("title");
                String url = request.getParameter("url");
                int groupID = getIntParameter("group");
                if ( groupID==0 ) {
                    doErrorRedirect("You must choose a group.  Go back and try again");
                }
                String comments = request.getParameter("comments");
                int memberID = getMember().getID();
                if ( !MemberService.instance().isRWMemberOfGroup(memberID, groupID) ) {
                    String groupName = GroupService.instance().getGroupName(groupID);
                    doErrorRedirect("You do not have permission to publish on group: "+groupName);
                    return;
                }
                GroupService.instance().addGroupEntry(memberID, title, url, groupID, comments);
                MemberService.instance().notifyGroupMembersOfPosting(groupID,
                                                                       title,
                                                                       comments,
                                                                       getMember());
                doRedirect("/group/feedmsg?msg=Your+group+entry+has+been+sent+to+PeerScope.com");
            }
            else if ( eventName.equals("cancel") ) {
                doRedirect("/group/feedmsg?msg=Feed+cancelled.");
            }
        }

        public String getTitle() { return "Feed Your PeerScope Group"; }
    }

    public static class Feed extends GroupMachinePage {
        public void generateBody(StringTemplate bodyST) throws Exception {
            int memberID = getMember().getID();
            Vector groups = MemberService.instance().getRWGroupMembershipDescriptors(memberID);
            bodyST.setAttribute("message", "The best way to enjoy PeerScope.com is to get the "+
                    "<a href=/group/feed_button><b>PeerScope This! button</b></a> onto your browser toolbar."+
                    "That way, when you see an interesting page on the web, you can just click " +
                    "the button and post it to your group(s) without leaving that page.  " +
                    "Naturally, you can also post links to your group from this page.");
            bodyST.setAttribute("target",getNodeURL("feed"));
            if ( groups==null ) {
                doRedirect("/group/feedmsg?msg=Sorry.+You+are+not+currently+a+participating+member+of+any+group.");
                return;
            }
            if ( groups.size()==1 ) {
                bodyST.setAttribute("onlyOneGroup","true");
            }
            bodyST.setAttribute("groups",groups);
        }
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("submit") ) {
                System.out.println("process event submit in FeedPopupPage");
                if ( getMember()==null ) {
                    doErrorRedirect("You must be logged in to post messages");
                    return;
                }
                requireParameters(new String[] {"title","url","group"});
                String title = request.getParameter("title");
                String url = request.getParameter("url");
                int groupID = getIntParameter("group");
                if ( groupID==0 ) {
                    doErrorRedirect("You must choose a group.  Go back and try again");
                }
                String comments = request.getParameter("comments");
                int memberID = getMember().getID();
                if ( !MemberService.instance().isRWMemberOfGroup(memberID, groupID) ) {
                    String groupName = GroupService.instance().getGroupName(groupID);
                    doErrorRedirect("You do not have permission to publish on group: "+groupName);
                    return;
                }
                GroupService.instance().addGroupEntry(memberID, title, url, groupID, comments);
                MemberService.instance().notifyGroupMembersOfPosting(groupID,
                                                                       title,
                                                                       comments,
                                                                       getMember());
                doRedirect("/group/"+groupID);
            }
            else if ( eventName.equals("cancel") ) {
                doMessageRedirect("Cancelled.  Nothing was posted to your group.");
            }
        }

        public String getTitle() { return "Feed Your PeerScope Group"; }
    }

    public static class FeedPopupMsg extends GroupMachinePage {
        public StringTemplate getPageStringTemplate() {
            return PeerscopeApplication.stringTemplatesLib.getInstanceOf("group/feed_popup_msg_page");
        }
        public void generateBody(StreamBuffer out) throws Exception {
            requireParameter("msg");
            String msg = request.getParameter("msg");
            out.println(msg);
        }

        public String getTitle() { return "Feed Message"; }
    }

    public static class ViewGroupPage extends GroupMachinePage {
        int ID = 0;
        Group ch;
        public void verify() throws VerifyException {
            requireParameter("ID");
            ID = getIntParameter("ID");
            ch = GroupService.instance().getGroup(ID);
            if ( ID<0 || ch==null ) {
                throw new VerifyException("invalid group ID "+ID);
            }
            // must log in to see private groups
            if ( getMember()==null &&
                 ch.getAccess()==GroupDescriptor.PRIVATE_ACCESS ) {
                throw new MustLoginException("You must be logged in to see private PeerScope.com groups",
                        getRequestURLAllParameters());
            }
        }
        public boolean mustBeLoggedIn() {
            return false;
        }
        public boolean hasViewPermission() {
            return MemberService.instance().canSeeGroup(getMember(), ID);
        }
        public void generateBody(StringTemplate bodyST) throws Exception {
            Member owner = MemberService.instance().getMember(ch.getDescriptor().getOwnerID());
            bodyST.setAttribute("owner", owner);
            boolean viewerIsOwner = getMember()!=null&&getMember().getID()==owner.getID();
            if ( viewerIsOwner ) {
                bodyST.setAttribute("viewerIsOwner", "true");
            }
            boolean viewerIsMember =
                getMember()!=null&&
                MemberService.instance().isMemberOfGroup(getMember().getID(),ID);
            boolean viewerIsParticipant =
                getMember()!=null&&
                MemberService.instance().isRWMemberOfGroup(getMember().getID(),ID);
            if (viewerIsParticipant) {
                bodyST.setAttribute("viewerIsParticipant", "true");
            }
            if (!viewerIsMember) {
                bodyST.setAttribute("canSubscribe", "true");
            }
            if (!viewerIsOwner && viewerIsMember) {
                bodyST.setAttribute("canUnSubscribe", "true");
            }
            bodyST.setAttribute("group", ch.getDescriptor());
            int memberID = 0;
            if ( getMember()!=null ) {
                memberID = getMember().getID();
            }
            Vector entries = GroupService.instance()
                    .getContextSensitiveGroupEntries(ID,memberID);
            if ( entries!=null ) {
                int beginIndex = (pageNumber-1)*ITEMS_PER_PAGE;
                int endIndex = beginIndex + ITEMS_PER_PAGE - 1;
                Vector pageWorthOfEntries =
                        Utils.subvector(entries,beginIndex,endIndex);
                bodyST.setAttribute("pagelinks", getPageLinks(entries.size()));
                bodyST.setAttribute("entries", pageWorthOfEntries);
            }
        }
        public void setDefaultPageAttributes(StringTemplate pageST) {
            super.setDefaultPageAttributes(pageST);
            // if they search, want to search only this group
            pageST.removeAttribute("searchScope");
            pageST.setAttribute("searchScope", String.valueOf(ID));
        }
        public String getTitle() { return "Group "+ch.getName(); }
    }

    public static class ViewJGuruGroupPage extends GroupMachinePage {
        public boolean mustBeLoggedIn() {
            return false;
        }
        public void generateBody(StringTemplate bodyST) throws Exception {
            /** JGURU PORTAL CODE TO GET PEERSCOPE ENTRIES */
            Vector news = ServiceManager.getResourceManager()
                .getRecentNewsworthyResources();
            System.out.println("jguru peerscope entries: "+news);
            Member owner = MemberService.instance().getMember(1); // Ter owns it
            bodyST.setAttribute("owner", owner);
            if ( news!=null ) {
                int beginIndex = (pageNumber-1)*ITEMS_PER_PAGE;
                int endIndex = beginIndex + ITEMS_PER_PAGE - 1;
                Vector pageWorthOfEntries =
                        Utils.subvector(news,
                                        beginIndex,
                                        endIndex);
                bodyST.setAttribute("pagelinks",
                        getPageLinks(news.size()));
                bodyST.setAttribute("entries", pageWorthOfEntries);
            }
        }
        public String getTitle() { return "Group JGuru"; }
    }

    public static class ViewGroupRSSPage extends GroupMachinePage {
        int ID = 0;
        Group group;
        public void verify() throws VerifyException {
            requireParameter("ID");
            ID = getIntParameter("ID");
            group = GroupService.instance().getGroup(ID);
            if ( ID<0 || group==null ) {
                throw new VerifyException("invalid group ID "+ID);
            }
            // must log in to see private groups
            if ( getMember()==null &&
                 group.getAccess()==GroupDescriptor.PRIVATE_ACCESS ) {
                throw new MustLoginException("You must be logged in to see private PeerScope.com groups",
                        getRequestURLAllParameters());
            }
        }
        public StringTemplate getPageStringTemplate() {
            return null;
            //return PeerscopeApplication.stringTemplatesLib.getInstanceOf("rss/channel");
        }
        public boolean mustBeLoggedIn() {
            return false;
        }
        public boolean hasViewPermission() {
            return MemberService.instance().canSeeGroup(getMember(), ID);
        }

        public void generateBody(StreamBuffer out) throws Exception {
            Vector entries = GroupService.instance().getGroupEntries(ID);
            if ( entries != null ) {
                String rss =
                        RSS.generate(group.getName(),
                            "http://www.peerscope.com/group/"+group.getID(),
                            group.getDescriptor().getDescription(),
                            entries);
                out.println(rss);
            }
        }
        public String getTitle() { return "RSS For Group "+group.getName(); }
    }

    public static class EditCommentsPage extends GroupMachinePage {
        int entryID = 0;
        GroupEntry entry;
        public void verify() throws VerifyException {
            requireParameter("ID");
            entryID = getIntParameter("ID");
            entry = GroupService.instance().getGroupEntry(entryID);
            if ( entryID<0 || entry==null ) {
                throw new VerifyException("invalid group entry ID "+entryID);
            }
        }
        public boolean mustBeLoggedIn() { return true; }
        public boolean hasViewPermission() {
            Member member = getMember();
            return MemberService.instance().canEditGroupEntry(member, entryID);
        }
        public void generateBody(StringTemplate bodyST) throws Exception {
            bodyST.setAttribute("entry", entry);
        }
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("submit") ) {
                requireParameters(new String[] {"title","url","entryID"});
                String title = request.getParameter("title");
                String url = request.getParameter("url");
                String comments = request.getParameter("comments");
                entryID = getIntParameter("entryID");
                if ( !hasViewPermission() ) {
                    doErrorRedirect("You do not have permission to edit this entry.");
                    return;
                }
                GroupService.instance().updateGroupEntry(entryID, title, url, comments);
                entry = GroupService.instance().getGroupEntry(entryID);
                if ( entry!=null ) {
                    doRedirect("/group/"+entry.getGroupID());
                }
            }
            else if ( eventName.equals("cancel") ) {
                doRedirect("/");
            }
        }

        public String getTitle() { return "Edit Group Entry"; }
    }

    public static class DeletePage extends GroupMachinePage {
        int entryID = 0;
        GroupEntry entry;
        public void verify() throws VerifyException {
            requireParameter("ID");
            entryID = getIntParameter("ID");
            entry = GroupService.instance().getGroupEntry(entryID);
            if ( entryID<0 || entry==null ) {
                throw new VerifyException("invalid group entry ID "+entryID);
            }
        }
        public boolean mustBeLoggedIn() { return true; }
        public boolean hasViewPermission() {
            Member member = getMember();
            return MemberService.instance().canEditGroupEntry(member, entryID);
        }
        public void generateBody(StringTemplate bodyST) throws Exception {
            bodyST.setAttribute("entry", entry);
        }
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("delete") ) {
                requireParameters(new String[] {"ID"});
                entryID = getIntParameter("ID");
                if ( !hasViewPermission() ) {
                    doErrorRedirect("You do not have permission to delete this entry.");
                    return;
                }
                entry = GroupService.instance().getGroupEntry(entryID);
                if ( entry!=null ) {
                    GroupService.instance().hideGroupEntry(entryID);
                    GroupDescriptor gd = GroupService.instance()
                            .getGroupDescriptor(entry.getGroupID());
                    doRedirect("/group/"+gd.getID());
                }
            }
            else if ( eventName.equals("cancel") ) {
                doRedirect("/");
            }
        }

        public String getTitle() { return "Delete Group Entry Confirmation"; }
    }

    public static class ListGroupsPage extends GroupMachinePage {
        public boolean hasViewPermission() {
            return getMember().isAdministrator();
        }

        public void generateBody(StringTemplate bodyST) throws Exception {
            Vector groups = GroupService.instance().getAllGroups();
            if ( groups!=null ) {
                bodyST.setAttribute("groups",groups);
            }
        }
        public String getTitle() { return "All PeerScope Groups"; }
    }

    public static class ListPublicGroupsPage extends GroupMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public void generateBody(StringTemplate bodyST) throws Exception {
            Vector groups = GroupService.instance().getPublicGroupDescriptors();
            if ( groups!=null ) {
                bodyST.setAttribute("groups",groups);
            }
        }
        public void setDefaultPageAttributes(StringTemplate pageST) {
            super.setDefaultPageAttributes(pageST);
            // if they search, want to search public groups
            pageST.removeAttribute("searchScope");
            pageST.setAttribute("searchScope", "public");
        }
        public String getTitle() { return "Public Group List"; }
    }

    public static class ManageListPage extends GroupMachinePage {
        int ID;
        public void verify() throws VerifyException {
            ID = getIntParameter("ID");
            if ( ID<=0 ) {
                throw new VerifyException("Invalid ID: "+ID);
            }
        }

        public void generateBody(StringTemplate bodyST) throws Exception {
            if ( !GroupService.instance().isOwnerOfGroup(getMember().getID(),ID) ) {
                doErrorRedirect("You are not the owner of this group");
                return;
            }
            // show a particular group's members
            GroupDescriptor cd = GroupService.instance().getGroupDescriptor(ID);
            if ( cd==null ) {
                doMessageRedirect("Invalid Group ID "+ID);
            }
            else {
                // list members
                Vector members = MemberService.instance().getGroupMembership(ID);
                bodyST.setAttribute("group", cd);
                if ( cd.getAccess()==GroupDescriptor.PRIVATE_ACCESS ) {
                    bodyST.setAttribute("isPrivate", "true");
                }
                bodyST.setAttribute("members", members);
                String note = request.getParameter("note");
                if ( note!=null ) {
                    bodyST.setAttribute("note", note);
                }
            }
        }

        public String getTitle() { return "Manage Group"; }
    }

    /*
    public static class VisibilityPage extends GroupMachinePage {
        int entryID = 0;
        GroupEntry entry;
        public void verify() throws VerifyException {
            requireParameter("ID");
            entryID = getIntParameter("ID");
            entry = GroupService.instance().getGroupEntry(entryID);
            if ( entryID<0 || entry==null ) {
                throw new VerifyException("invalid group entry ID "+entryID);
            }
        }
        public boolean mustBeLoggedIn() { return true; }
        public boolean hasViewPermission() {
            Member member = getMemberContext().getMember();
            return MemberService.instance().canEditGroupEntry(member, entryID);
        }
        public void generateBody(StringTemplate bodyST) throws Exception {
            bodyST.setAttribute("entry", entry);
        }
        public void processEvent(String eventName) throws Exception {
            requireParameter("ID");
            String targetVisibility = request.getParameter(""
            int groupID = getIntParameter("ID");
            if ( groupID<=0 ) {
                throw new VerifyException("Invalid ID: "+groupID);
            }
            if ( eventName.equals("public") ) {
                GroupService.instance()
                        .updateGroupVisibility(groupID,
                                GroupDescriptor.PUBLIC_ACCESS);
            }
            else if ( eventName.equals("private") ) {
                GroupService.instance()
                        .updateGroupVisibility(groupID,
                                GroupDescriptor.PUBLIC_ACCESS);
            }
            else {
                doErrorRedirect("Invalid visiblity change event");
            }
            doMessageRedirect("That group is now: "+eventName);
        }

        public String getTitle() { return "Change Group Visibility Confirmation"; }
    }
    */

    public static class AddGroupPage extends GroupMachinePage {
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("createGroup") ) {
                requireParameters(new String[] {"groupName"});
                String groupName = request.getParameter("groupName");
                String comments = request.getParameter("comments");
                String accessStr = request.getParameter("access");
                int access = GroupDescriptor.PRIVATE_ACCESS;
                if ( accessStr==null ) {
                    access = GroupDescriptor.PUBLIC_ACCESS;
                }

                int memberID = getMember().getID();
                int groupID =
                    GroupService.instance().addGroupDescriptor(groupName,
                                                                   memberID,
                                                                   access,
                                                                   comments);
                doRedirect(getNodeURL("view?ID="+groupID));
            }
            else if ( eventName.equals("cancel") ) {
                doRedirect("/");
            }
            else {
                System.out.println("unknown event");
            }
        }
        public String getTitle() { return "Create PeerScope Group"; }
    }

    public static class RegisterAddGroupPage extends GroupMachinePage {
        public boolean mustBeLoggedIn() {
            return false;
        }

        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("registerAndCreateGroup") ) {
                requireParameters(new String[] {"groupName","email",
                                                "firstName", "lastName",
                                                "password"});
                String groupName = request.getParameter("groupName");
                String comments = request.getParameter("comments");
                String accessStr = request.getParameter("access");
                int access = GroupDescriptor.PRIVATE_ACCESS;
                if ( accessStr==null ) {
                    access = GroupDescriptor.PUBLIC_ACCESS;
                }

                // REGISTER THEM FIRST
                String firstName = request.getParameter("firstName");
                String lastName = request.getParameter("lastName");
                String email = request.getParameter("email").trim().toLowerCase();
                String password = request.getParameter("password");
                Member member =
                    MemberService.instance().getMemberByEmail(email);
                if ( member!=null ) {
                    doMessageRedirect("User "+email+" already registered.");
                }
                else {
                    member = MemberService.instance().registerMember(firstName,lastName,email,password);
                    SessionService.instance().login(request, response, session, member);

                    // NOW ADD THE GROUP
                    int memberID = member.getID();
                    int groupID =
                        GroupService.instance().addGroupDescriptor(groupName,
                                                                       memberID,
                                                                       access,
                                                                       comments);
                    doRedirect(getNodeURL("view?ID="+groupID));
                }
            }
            else if ( eventName.equals("cancel") ) {
                doRedirect("/");
            }
            else {
                System.out.println("unknown event");
            }
        }
        public String getTitle() { return "Create PeerScope Group"; }
    }

    public static class SubscribePage extends GroupMachinePage {
        public String getTitle() {return "";} // unused
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("subscribe") ) {
                // entry point for manager adding people by email
                requireParameter("email");
                requireParameter("ID");
                String email = request.getParameter("email");
                String note = request.getParameter("note");
                int groupID = getIntParameter("ID");
                if ( !GroupService.instance().isOwnerOfGroup(getMember().getID(),groupID) ) {
                    doErrorRedirect("You are not the owner of group "+groupID);
                    return;
                }
                MemberService.instance().subscribeEmailToGroup(groupID, email, note);
                doRedirect(getNodeURL("manage?ID="+groupID+"&note="+URLEncoder.encode(note)));
            }
            else if ( eventName.equals("subscribeMe") ) {    // public lists
                requireParameter("ID");
                int groupID = getIntParameter("ID");
                if ( !GroupService.instance().isPublicGroup(groupID) ) {
                    doErrorRedirect("Group "+groupID+" is not a public group");
                    return;
                }
                MemberService.instance().subscribeMemberToGroup(getMember().getID(),
                                                                 groupID);
                doRedirect(getNodeURL("view?ID="+groupID));
            }
            else if ( eventName.equals("unSubscribeMe") ) {
                requireParameter("ID");
                int groupID = getIntParameter("ID");
                MemberService.instance().unSubscribeMemberToGroup(getMember().getID(),
                                                                    groupID);
                doRedirect(getNodeURL("view?ID="+groupID));
            }
            else if ( eventName.equals("unSubscribe") ) {
                requireParameter("ID");
                requireParameter("email");
                int groupID = getIntParameter("ID");
                String email = request.getParameter("email");
                if ( !GroupService.instance().isOwnerOfGroup(getMember().getID(),groupID) ) {
                    doErrorRedirect("You are not the owner of group "+groupID);
                    return;
                }
                Member member = MemberService.instance().getMemberByEmail(email);
                if ( member==null ) {
                    doErrorRedirect("Member "+email+" does not exist");
                    return;
                }
                MemberService.instance().unSubscribeMemberToGroup(member.getID(), groupID);
                doRedirect(getNodeURL("manage?ID="+groupID));
            }
            else if ( eventName.equals("cancel") ) {
                doRedirect("/");
            }
            else {
                System.out.println("internal problem: invalid event name: "+eventName);
                doErrorRedirect("internal problem: invalid event name: "+eventName);
            }
        }
    }

}
