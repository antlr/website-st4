/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.service;

import org.pageforge.lib.service.SMTPClient;

import java.util.Vector;

public class EmailService {
    public static final int NOTIFICATIONS_NONE = 0;
    public static final int NOTIFICATIONS_PER_ENTRY = 1;
    public static final int NOTIFICATIONS_DAILY = 2;

    private static EmailService _instance;

    public static synchronized EmailService instance() {
        if (_instance == null) {
            _instance = new EmailService();
        }
        return _instance;
    }

    private EmailService() {
    }

    /** Launch a thread to send a message/subject to an email list */
    public void sendEmailNonBlocking(final String from,
                                     final Vector emailAddrs,
                                     final String subject,
                                     final String message)
    {
        Runnable r = new Runnable() {
            public void run() {
                for (int i = 0; emailAddrs != null && i < emailAddrs.size(); i++) {
                    String email = (String) emailAddrs.elementAt(i);
                    try {
                        sendEmail(from,
                                  email,
                                  subject,
                                  message);
                    }
                    catch (Exception ee) {
                        if (!email.equals("parrt@jguru.com")) {
                            try {
                                sendEmail(
                                    from,
                                    "parrt@jguru.com",
                                    "Error running thread notification",
                                    "Exception in sendEmailNonBlocking: " + ee + "; i'll keep going though");
                            }
                            catch (Exception eee) {
                                // crap out; error even to parrt
                                ErrorService.instance().error("error in sendEmailNonBlocking: can't even email parrt about a problem", eee);
                            }
                        }
                        else {
                            ErrorService.instance().error("error in sendEmailNonBlocking", ee);
                        }
                    }
                }
            }
        };
        Thread mailThread = new Thread(r);
        mailThread.setName("email-"+emailAddrs+"-from-"+from);
        mailThread.start(); // launch loop in thread to send email
    }

    /** Launch a thread to send a message/subject to an email list */
    public void sendEmail(String from,
                          Vector emailAddrs,
                          String subject,
                          String message,
                          boolean showStatus)
        throws Exception {
        int n = emailAddrs.size();
        int chunk = (int) Math.ceil((double) n / 72.0); // chunks per 72 chr wide
        for (int i = 0; emailAddrs != null && i < emailAddrs.size(); i++) {
            String email = (String) emailAddrs.elementAt(i);
            try {
                if (showStatus && i % chunk == 0) {
                    System.out.print('.');
                }
                sendEmail(from,
                          email,
                          subject,
                          message);
            }
            catch (Exception ee) {
                if (!email.equals("parrt@jguru.com")) {
                    try {
                        sendEmail(
                            from,
                            "parrt@jguru.com",
                            "Error running thread notification",
                            "Exception in sendEmail: " + ee + "; i'll keep going though");
                    }
                    catch (Exception eee) {
                        // crap out; error even to parrt
                        ErrorService.instance().error("error in sendEmail: can't even email parrt about a problem", eee);
                    }
                }
                else {
                    ErrorService.instance().error("error in sendEmail", ee);
                }
            }
        }
        if (showStatus) {
            System.out.println();
        }
    }

    public void sendEmail(String to,
                          String subject,
                          String message)
        throws Exception {
        sendEmailWithBcc("notifications@peerscope.com", to, null, subject, message);
    }

    public void sendEmail(String from,
                          String to,
                          String subject,
                          String message)
        throws Exception {
        sendEmailWithBcc(from, to, null, subject, message);
    }

    public void sendEmailWithBcc(String to,
                                 String bcc,
                                 String subject,
                                 String message)
        throws Exception {
        sendEmailWithBcc("notifications@peerscope.com", to, bcc, subject, message);
    }

    /** second to last stop before mail goes out...checks for smtp server failure. */
    public void sendEmailWithBcc(String from,
                                 String to,
                                 String bcc,
                                 String subject,
                                 String message)
        throws Exception {
        String failoverServer = null;
        String smtpServer = PeerscopeApplication.getProperty("smtp.server", "localhost");
        try {
            rawSendmail(smtpServer, from, to, bcc, subject, message);
        }
        catch (Exception e) {
            String msg = e.getMessage();
            System.out.println("error during send mail: " + msg);
            if (msg.indexOf("SMTPClient.Connect") >= 0) {
                System.out.println("smtp " + smtpServer + " failed, trying failover");
                // can't connect to the smtp server
                failoverServer = PeerscopeApplication.getProperty("smtp.failover");
                if (failoverServer == null) {
                    System.out.println("no failover smtp throwing exception");
                    // hm...no failover
                    throw e;
                }
            }
            else {
                // don't recognize, rethrow
                throw e;
            }
            // retry to failover
            rawSendmail(failoverServer, from, to, bcc, subject, message);
        }
    }

    private void rawSendmail(String smtpServer,
                             String from,
                             String to,
                             String bcc,
                             String subject,
                             String message)
        throws Exception {
        if (!(to.equals("parrt@jguru.com") ||
            to.equals("parrt@antlr.org") ||
            to.equals("mel@jguru.com") ||
            to.equals("tombu@jguru.com") ||
            PeerscopeApplication.isLiveSite())) {
            System.out.println("Simulated email from " + from + " to " + to + ": " + subject + "\nBODY:\n" + message);
            return;
        }
        if (bcc == null) {
            System.out.println("email to " + to);
            SMTPClient.sendmail(smtpServer,
                    from,
                    to,
                    subject,
                    message);
        }
        else {
            Vector toV = new Vector();
            Vector bccV = new Vector();
            toV.addElement(to);
            bccV.addElement(bcc);
            System.out.println("email to " + to + ", bcc=" + bcc);
            SMTPClient.sendmail(smtpServer,
                    from,
                    toV,
                    null,
                    bccV,
                    subject,
                    message);
        }
        LogService.instance().log("email", to + ": " + subject);
    }
}
