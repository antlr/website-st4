/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.service;

import com.jguru.peerscope.entity.Member;
import com.jguru.peerscope.entity.GroupDescriptor;
import com.jguru.peerscope.entity.GroupEntry;
import com.jguru.peerscope.support.Group;
import com.jguru.peerscope.support.MultivaluedHashtable;
import com.jguru.peerscope.support.QueryResultSet;
import com.jguru.peerscope.support.MemberContextEntryWrapper;

import java.util.Vector;
import java.util.Hashtable;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.sql.Date;

/** The interface between between the page generation code and the
 *  raw storage layer.
 */
public class GroupService {
    public static final int RW_ACCESS = 1; // default membership access
    public static final int RO_ACCESS = 2;

    private static GroupService _instance = null;

    public static GroupService instance() {
        if(_instance == null) {
            _instance = new GroupService();
        }
        return _instance;
    }

    /** Maps Integer group descriptor IDs to GroupDescriptor objects */
    protected Hashtable descriptors = null;

    protected Vector publicGroupIDs = null;

    /** Maps Integer entry IDs to GroupEntry objects */
    protected Hashtable entries = null;

    /** List of Integer entry IDs to all publicly-visible GroupEntry objects */
    protected Vector publicEntryIDs = null;

    protected Vector allGroupDescriptorIDs = null;

    protected MultivaluedHashtable mapGroupToEntries = null;

    protected MultivaluedHashtable mapOwnerIDToDescriptorIDs = null;

    private GroupService() {
        System.out.println("Create GroupService");
        StorageService storage = StorageService.instance();
        storage.open();

        mapOwnerIDToDescriptorIDs = new MultivaluedHashtable(1001);

        // GROUP DESCRIPTORS
        Vector allGroupDescriptors = storage.getAllGroupDescriptors();
        // map group descriptor IDs to GroupDescriptor objects
        System.out.println("allGroupDescriptorIDs = "+allGroupDescriptorIDs);
        descriptors = new Hashtable(1001);
        allGroupDescriptorIDs = new Vector();
        publicGroupIDs = new Vector(100);
        for (int i=0; i<allGroupDescriptors.size(); i++) {
            GroupDescriptor cd = (GroupDescriptor)allGroupDescriptors.elementAt(i);
            cacheAndIndex(cd);
        }
        System.out.println("descriptors upon startup: "+descriptors);

        // GROUP ENTRIES
        Vector v = storage.getAllGroupEntries();
        // map group entry IDs to GroupEntry objects
        entries = new Hashtable(3001);
        publicEntryIDs = new Vector(1001);
        mapGroupToEntries = new MultivaluedHashtable(3001);
        for (int i=0; i<v.size(); i++) {
            GroupEntry e = (GroupEntry)v.elementAt(i);
            cacheAndIndex(e, false);
        }

        storage.close();
    }

    private void cacheAndIndex(GroupEntry e, boolean onTheFlyAddition) {
        GroupDescriptor cd = getGroupDescriptor(e.getGroupID());
        if ( cd!=null ) {
            // only add if there is a valid descriptor.
            entries.put(new Integer(e.getID()), e);
            if ( cd.getAccess()==GroupDescriptor.PUBLIC_ACCESS ) {
                if ( onTheFlyAddition ) {
                    // add to the head since we want in reverse created order
                    publicEntryIDs.insertElementAt(new Integer(e.getID()), 0);
                }
                else {
                    // add to the end
                    publicEntryIDs.addElement(new Integer(e.getID()));
                }
            }
            boolean addToEnd = !onTheFlyAddition;  // reverse order for on the fly addition
            mapGroupToEntries.put(new Integer(e.getGroupID()),
                                    new Integer(e.getID()),
                                    addToEnd);
        }
    }

    private void updateCache(GroupEntry e) {
        entries.put(new Integer(e.getID()), e);  // replace
    }

    private void invalidateEntryCache(int entryID) {
        Integer ID = new Integer(entryID);
        GroupEntry e = (GroupEntry)entries.remove(ID); // remove object itself
        // remove from all indices
        publicEntryIDs.remove(ID);
        mapGroupToEntries.remove(new Integer(e.getGroupID()), ID);
    }

    private void cacheAndIndex(GroupDescriptor cd) {
        descriptors.put(new Integer(cd.getID()), cd);
        mapOwnerIDToDescriptorIDs.put(new Integer(cd.getOwnerID()),
                                      new Integer(cd.getID()));
        Integer cdID = new Integer(cd.getID());
        allGroupDescriptorIDs.addElement(cdID);
        if ( cd.getAccess()==GroupDescriptor.PUBLIC_ACCESS ) {
            publicGroupIDs.addElement(cdID);
        }
    }

    public Vector getAllGroupEntries() {
        StorageService storage = StorageService.instance();
        storage.open();
        Vector v = storage.getAllGroupEntries();
        storage.close();
        return v;
    }

    public GroupDescriptor getGroupDescriptor(int ID) {
        GroupDescriptor cd = (GroupDescriptor)descriptors.get(new Integer(ID));
        return cd;
    }

    public String getGroupName(int ID) {
        GroupDescriptor cd = getGroupDescriptor(ID);
        if ( cd!=null ) {
            return cd.getName();
        }
        return null;
    }

    /** Return a group (descriptor/items) given its ID; must be in cache */
    public Group getGroup(int ID) {
        GroupDescriptor cd = getGroupDescriptor(ID);
        if ( cd==null ) {
            return null;
        }
        Group c = new Group();
        c.setDescriptor(cd);
        Vector entryIDs = mapGroupToEntries.get(new Integer(ID));
        // get a vector or GroupEntries not IDs now
        if ( entryIDs!=null ) {
            Vector entriesV = convertIDsToEntries(entryIDs);
            c.setEntries(entriesV);
        }
        System.out.println("Group "+ID+"="+c);
        return c;
    }

    public GroupEntry getGroupEntry(int entryID) {
        return (GroupEntry)entries.get(new Integer(entryID));
    }

    public Vector getGroupEntryIDs(int groupID) {
        Vector entryIDs = mapGroupToEntries.get(new Integer(groupID));
        return entryIDs;
    }

    public Vector getGroupEntries(int groupID) {
        Vector IDs = getGroupEntryIDs(groupID);
        return convertIDsToEntries(IDs);
    }

    public Vector getContextSensitiveGroupEntries(int groupID,
                                                     int memberID)
    {
        Vector IDs = getGroupEntryIDs(groupID);
        return convertIDsToContextSensitiveEntries(IDs, memberID);
    }

    private Vector convertIDsToEntries(Vector entryIDs) {
        return convertIDsToContextSensitiveEntries(entryIDs, 0);
    }

    private Vector convertIDsToContextSensitiveEntries(Vector entryIDs,
                                                       int memberID) {
        System.out.println("Getting context sensitive entries for "+memberID);
        if ( entryIDs==null ) {
            return null;
        }
        Vector entriesV = new Vector(entryIDs.size());
        Member member = MemberService.instance().getMember(memberID);
        for (int i=0; i<entryIDs.size(); i++) {
            Integer eID = (Integer)entryIDs.elementAt(i);
            GroupEntry entry = (GroupEntry)entries.get(eID);
            entriesV.addElement(new MemberContextEntryWrapper(member, entry));
        }
        return entriesV;
    }

    public Vector getPublicGroupDescriptors() {
        return convertIDsToDescriptors(publicGroupIDs);
    }

    public boolean isPublicGroup(int groupID) {
        GroupDescriptor cd = getGroupDescriptor(groupID);
        return cd!=null&&cd.getAccess()==GroupDescriptor.PUBLIC_ACCESS;
    }

    /** Get a Vector of group descriptor IDs for this user */
    public Vector getGroupIDsOwnedByMember(int userID) {
        Vector groupIDs = mapOwnerIDToDescriptorIDs.get(new Integer(userID));
        return groupIDs;
    }

    /** Get a Vector of all group descriptor IDs */
    public Vector getAllGroupIDs() {
        return allGroupDescriptorIDs;
    }

    /** Get a Vector of all group descriptors */
    public Vector getAllGroups() {
        return convertIDsToDescriptors(allGroupDescriptorIDs);
    }

    public boolean isOwnerOfGroup(int memberID, int groupID) {
        GroupDescriptor cd = getGroupDescriptor(groupID);
        if ( cd!=null && cd.getOwnerID()==memberID ) {
            return true;
        }
        return false;
    }

    private Vector convertIDsToDescriptors(Vector groupIDs) {
        Vector v = null;
        if ( groupIDs!=null ) {
            v = new Vector(groupIDs.size());
            for (int i=0; i<groupIDs.size(); i++) {
                int id = ((Integer)groupIDs.elementAt(i)).intValue();
                GroupDescriptor c = getGroupDescriptor(id);
                v.addElement(c);
            }
        }
        return v;
    }

    /** Add a descriptor */
    public int addGroupDescriptor(String name, int ownerID, int access, String description)
    {
        // First, write through to DB
        StorageService storage = StorageService.instance();
        storage.open();
        int ID = storage.insertGroupDescriptor(name, ownerID, access, description);
        GroupDescriptor cd = storage.getGroupDescriptor(ID);
        // add owner to membership list
        storage.subscribeToGroup(ownerID, ID, RW_ACCESS);
        storage.close();

        // if ok, cache it
        cacheAndIndex(cd);
        // update membership cache
        MemberService.instance().notifyMembershipAddition(cd.getOwnerID(), cd.getID(), RW_ACCESS);
        return ID;
    }

    /** Add a descriptor */
    public int addGroupEntry(int authorID,
                               String title,
                               String url,
                               int groupID,
                               String comments)
    {
        // First, write through to DB
        StorageService storage = StorageService.instance();
        storage.open();
        int ID = storage.insertGroupEntry(authorID,groupID,title,url,comments);
        GroupEntry e = storage.getGroupEntry(ID);
        storage.close();

        // add to search db
        SearchService.instance().indexGroupEntry(e);

        // if ok, cache it
        cacheAndIndex(e, true);
        return ID;
    }

    public void updateGroupEntry(int entryID,
                                   String title,
                                   String url,
                                   String comments)
    {
        // First, update DB
        StorageService storage = StorageService.instance();
        storage.open();
        storage.updateGroupEntry(entryID,title,url,comments);
        // fetch fresh from DB; if we introduce errors, see right away
        GroupEntry e = storage.getGroupEntry(entryID);
        storage.close();

        // update search db
        SearchService.instance().updateGroupEntry(e);

        // update cache
        updateCache(e);
    }

    /*
    public void updateGroupVisibility(int groupID,
                                        int access)
    {
        // First, update DB
        StorageService storage = StorageService.instance();
        storage.open();
        storage.updateGroupVisibility(groupID,access);
        // fetch fresh from DB; if we introduce errors, see right away
        GroupDescriptor cd = storage.getGroupDescriptor(entryID);
        storage.close();

        // update search db
        SearchService.instance().updateGroupEntry(e);

        // update cache
        updateCache(e);
    }
    */

    public void hideGroupEntry(int entryID)
    {
        // First, update DB
        StorageService storage = StorageService.instance();
        storage.open();
        storage.hideGroupEntry(entryID);
        storage.close();

        // update search db
        SearchService.instance().removeGroupEntryFromIndex(entryID);

        // update cache
        invalidateEntryCache(entryID);
    }

    /** Get a merged list of all public entries */
    public Vector getPublicEntries() {
        return convertIDsToContextSensitiveEntries(publicEntryIDs, 0);
    }

    /** Get a merged list of all entries in all subscribed groups for memberID */
    public Vector getEntriesForMember(int memberID) {
        Vector groupIDs = MemberService.instance().getGroupMembershipDescriptorIDs(memberID);
        if ( groupIDs==null ) {
            return null;
        }
        // get a list of all groups then their entries into a QueryResultSet and then
        // just sort for now.  Can cache later.
        QueryResultSet merged = new QueryResultSet(100,2);
        for (int i = 0; i < groupIDs.size(); i++) {
            Integer cID = (Integer) groupIDs.elementAt(i);
            Vector entries = getGroupEntryIDs(cID.intValue());
            for (int j = 0; entries!=null && j < entries.size(); j++) {
                Integer eID = (Integer) entries.elementAt(j);
                GroupEntry entry = getGroupEntry(eID.intValue());
                java.sql.Timestamp created = entry.getCreated();
                merged.addRow(new Object[] {eID,new Long(created.getTime())});
            }
        }
        if ( merged.numRows()==0 ) {
            return null;
        }
        merged.sort(1,-1);
        Vector mergedIDs = merged.toVector(0);
        return convertIDsToContextSensitiveEntries(mergedIDs, memberID);
    }
}
