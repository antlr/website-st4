/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.page.search;

import org.pageforge.*;
import org.pageforge.support.VerifyException;
import com.jguru.peerscope.page.PeerscopePage;
import com.jguru.peerscope.entity.Member;
import com.jguru.peerscope.service.MemberService;
import com.jguru.peerscope.service.GroupService;
import com.jguru.peerscope.service.SearchService;
import com.jguru.peerscope.support.SearchResult;
import org.antlr.stringtemplate.StringTemplate;

import java.util.Vector;

/** Manage search pages. */
public class SearchMachine extends PageStateMachine {

    static {
        mapState("search", "results", SearchMachine.ResultsPage.class, "search/results");
    }

    /** Any page in this machine is of this type */
    public static class SearchMachinePage extends PeerscopePage {
        /** Do a type conversion for brevity in references.  Damn.  I'd prefer
         *  "state." intead of "state().", but strict typing prevents it.
         *  Must repeat this in every state machine. :(
         */
        protected SearchMachine state() { return (SearchMachine)state; }
    }

    public static class ResultsPage extends SearchMachine.SearchMachinePage {
        protected String query;
        protected String scope;
        protected int groupID;
        boolean exact = false;

        public boolean mustBeLoggedIn() {
            return false;
        }

        public void verify() throws VerifyException {
            requireParameter("query");
            query = request.getParameter("query");
            // scope is in set {public, an int (group), mygroups}
            scope = request.getParameter("scope");
            if ( scope==null || scope.trim().length()==0 ) {
                scope = "public";
            }
            if ( Character.isDigit(scope.charAt(0)) ) {
                groupID = Integer.parseInt(scope);
            }
            if ( request.getParameter("exact")!=null ) {
                exact = true;
            }
        }

        public void generateBody(StringTemplate bodyST) throws Exception {
            SearchResult sr = null;
            bodyST.setAttribute("query",query);
            if ( Character.isDigit(scope.charAt(0)) ) {
                String groupName =
                           GroupService.instance().getGroupName(groupID);
                if ( !MemberService.instance().canSeeGroup(getMember(), groupID) ) {
                    throw new VerifyException("You do not have permission to search group "+
                            groupName);
                }
                bodyST.setAttribute("scopeName", "group "+groupName);
                sr = SearchService.instance().searchGroup(query,groupID,0,10,exact);
            }
            else if ( getMember()==null || scope.equals("public") ) {
                bodyST.setAttribute("scopeName", "all public groups");
                sr = SearchService.instance().searchPublic(query,0,10,exact);
            }
            else if ( scope.equals("mygroups") ) {
                if ( getMember()==null ) {
                    throw new VerifyException("You must be logged in to search your groups");
                }
                bodyST.setAttribute("scopeName", "your groups");
                Member member = getMember();
                Vector groupIDs =
                    MemberService.instance().getGroupMembershipDescriptorIDs(member.getID());
                sr = SearchService.instance().searchGroupList(query,groupIDs,0,10,exact);
            }
            if ( sr!=null ) {
                bodyST.setAttribute("results", sr.getResults());
            }
        }

        public String getTitle() { return "Search Results"; }
    }
}
