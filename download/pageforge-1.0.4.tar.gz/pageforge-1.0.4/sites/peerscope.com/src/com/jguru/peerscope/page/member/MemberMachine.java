/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.page.member;

import org.pageforge.*;
import org.pageforge.service.SessionService;
import org.pageforge.support.VerifyException;
import com.jguru.peerscope.page.PeerscopePage;
import com.jguru.peerscope.service.MemberService;
import com.jguru.peerscope.service.EmailService;
import com.jguru.peerscope.entity.Member;
import org.antlr.stringtemplate.StringTemplate;

import java.net.URLEncoder;

public class MemberMachine extends PageStateMachine {

    static {
        mapState("member", "login", LoginPage.class, "member/login");
        mapState("member", "logout", LogoutPage.class, "member/logout");
        mapState("member", "login_failed", LoginFailedPage.class, "member/login_failed");
        mapState("member", "register", RegisterPage.class, "member/register");
        mapState("member", "view", ViewPage.class, "member/view");
        mapState("member", "edit", EditPage.class, "member/edit");
    }

    /** Any page in this machine is of this type */
    public static class MemberMachinePage extends PeerscopePage {
        /** Do a type conversion for brevity in references.  Damn.  I'd prefer
         *  "state." intead of "state().", but strict typing prevents it.
         *  Must repeat this in every state machine. :(
         */
        protected MemberMachine state() { return (MemberMachine)state; }
    }

    public static class ViewPage extends MemberMachinePage {
        public void verify() throws VerifyException {
            // TODO add code to handle ID parameter
        }
        public void generateBody(StringTemplate bodyST) {
            String notify = "You do not currently receive email notifications.";
            Member member = getMember();
            if ( member.getNotifications()==EmailService.NOTIFICATIONS_DAILY ) {
                notify = "You currently receive a PeerScope.com activity digest daily.";
            }
            if ( member.getNotifications()==EmailService.NOTIFICATIONS_PER_ENTRY ) {
                notify = "You currently receive email every time someone posts to a group you are member of.";
            }
            bodyST.setAttribute("notifications", notify);
        }
        public String getTitle() { return "Member PeerscopePage"; }
    }

    public static class EditPage extends MemberMachinePage {
        public void generateBody(StringTemplate bodyST) {
            String msg = request.getParameter("msg");
            Member member = getMember();
            bodyST.setAttribute("member",member);
            if ( msg!=null ) {
                bodyST.setAttribute("msg", msg);
            }
            if ( member.getNotifications()==EmailService.NOTIFICATIONS_NONE ) {
                bodyST.setAttribute("nonechecked", "checked");
            }
            if ( member.getNotifications()==EmailService.NOTIFICATIONS_PER_ENTRY ) {
                bodyST.setAttribute("perchecked", "checked");
            }
        }
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("edit") ) {
                requireParameters(new String[] {"firstName","lastName","email",
                                                "notification",
                                                "password","password2"});
                String firstName = request.getParameter("firstName");
                String lastName = request.getParameter("lastName");
                String email = request.getParameter("email").trim().toLowerCase();
                String password = request.getParameter("password").trim();
                String password2 = request.getParameter("password2").trim();
                String notificationStr = request.getParameter("notification");
                int notifications = EmailService.NOTIFICATIONS_NONE;
                if ( notificationStr.equals("per") ) {
                    notifications = EmailService.NOTIFICATIONS_PER_ENTRY;
                }
                Member existingMemberWithEmail = MemberService.instance().getMemberByEmail(email);
                if ( existingMemberWithEmail!=null &&
                    existingMemberWithEmail.getID()!=getMember().getID())
                {
                    System.out.println("email taken");
                    doRedirect(getNodeURL("edit")+"?msg="+URLEncoder.encode("Sorry.  Email is already in use by someone."));
                    return;
                }
                if ( !password.equals(password2) ) {
                    System.out.println("passwords don't match");
                    doRedirect(getNodeURL("edit")+"?msg="+URLEncoder.encode("Passwords don't match"));
                    return;
                }
                Member member = getMember();
                member = MemberService.instance().updateMember(member.getID(),
                                                               firstName,
                                                               lastName,
                                                               email,
                                                               password,
                                                               notifications);
                doRedirect(getNodeURL("view"));
            }
            else if ( eventName.equals("cancel") ) {
                System.out.println("process event cancel in Editpage");
                doRedirect(getNodeURL("view"));
            }
        }
        public String getTitle() { return "Edit Member Information"; }
    }

    public static class LoginPage extends MemberMachinePage {
        public void generateBody(StringTemplate bodyST) {
            String redirect = request.getParameter("redirect");
            if ( redirect!=null ) {
                bodyST.setAttribute("redirect", redirect);
            }
            String message = request.getParameter("msg");
            if ( message!=null ) {
                bodyST.setAttribute("msg", message);
            }
        }

        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("login") ) {
                requireParameters(new String[] {"email", "password"});
                String email = request.getParameter("email").toLowerCase();
                String password = request.getParameter("password");
                String redirect = request.getParameter("redirect");
                boolean ok =
                        SessionService.instance().login(request,response,session,email,password);
                if ( ok ) {
                    if ( redirect!=null ) {
                        doRedirect(redirect);
                    }
                    else {
                        doRedirect("/");
                    }
                }
                else {
                    if ( redirect!=null ) {
                    doRedirect("/member/login?msg="+
                               URLEncoder.encode("Login failed.  Please try again.")+
                               "&redirect="+redirect);
                    }
                    else {
                        doRedirect("/member/login_failed?email="+email);
                    }
                }
            }
        }

        public boolean mustBeLoggedIn() { return false; }

        public String getTitle() { return "Login"; }
    }

    public static class LoginFailedPage extends MemberMachinePage {

        public boolean mustBeLoggedIn() { return false; }

        public String getTitle() { return "Login failed"; }

        public void generateBody(StringTemplate bodyST) {
            String email = request.getParameter("email");
            bodyST.setAttribute("email", email);
        }
    }

    public static class LogoutPage extends MemberMachinePage {
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("logout") ) {
                SessionService.instance().logout(request,response,session);
                doRedirect("/");
            }
        }
    }

    public static class RegisterPage extends MemberMachinePage {
        public boolean mustBeLoggedIn() { return false; }

        public void generateBody(StringTemplate bodyST) {
            String email = request.getParameter("email");
            bodyST.setAttribute("email", email);
        }
        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("register") ) {
                requireParameters(new String[] {"firstName","lastName","email","password"});
                String firstName = request.getParameter("firstName");
                String lastName = request.getParameter("lastName");
                String email = request.getParameter("email").toLowerCase();
                String password = request.getParameter("password");
                Member member =
                        MemberService.instance().getMemberByEmail(email);
                if ( member!=null ) {
                    doMessageRedirect("User "+email+" already registered.");
                }
                else {
                    member = MemberService.instance().registerMember(firstName,lastName,email,password);
                    SessionService.instance().login(request, response, session, member);
                    doRedirect(getNodeURL("view"));
                }
            }
            else if ( eventName.equals("cancel") ) {
                System.out.println("process event cancel in RegisterPage");
                doRedirect("/");
            }
        }
        public String getTitle() { return "Register with PeerScope"; }
    }
}
