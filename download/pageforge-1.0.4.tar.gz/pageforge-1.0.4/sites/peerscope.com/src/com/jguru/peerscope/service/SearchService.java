/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.service;

import org.apache.lucene.document.Field;
import org.apache.lucene.document.DateField;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.Token;
import org.apache.lucene.search.*;

import java.util.*;
import java.io.*;

import org.pageforge.lib.html.HTMLUtils;
import com.jguru.peerscope.entity.GroupEntry;
import com.jguru.peerscope.entity.GroupDescriptor;
import com.jguru.peerscope.support.SearchResultItem;
import com.jguru.peerscope.support.SearchResult;
import com.jguru.peerscope.support.PeerscopeStopAnalyzer;

/** Manages the lucene search engine.  You can add new group entries
 *  and look for keywords and remove a entrie group or refresh it.
 */
public class SearchService {
    /** Field indexed/unstored, but used to clump all searchable data together */
    public static final String CONTENTS_FIELD = "contents";
    public static final String ACCESS_FIELD = "access";
    public static final String ID_FIELD = "ID";
    public static final String GROUPID_FIELD = "groupID";
    public static final String URL_FIELD = "url";
    public static final String TITLE_FIELD = "title";
    public static final String DATE_FIELD = "date";
    public static final String DESCRIPTION_FIELD = "description";

    public static final String SEARCH_DB_ROOT = "/var/data/peerscope/search";

    /** How many docs to add before optimizing/merging index */
    public static final int DYNAMIC_MERGE_FACTOR = 5;

    public static final int PHRASE_SLOP = 10000; // allow words to be anywhere in text

    /** How often between heartbeats to do service thread work */
    private static final int HEARTBEAT_PERIOD = 30*1000; // 30s

    /** How many documents you can add before an optimize should occur. */
    private static final int ADDITIONS_BEFORE_OPTIMIZE = 10;

    protected int documentsAddedSinceLastOptimization = 0;

    /** All writes and optimizes are synchronized with this */
    private static Object searchDBWriteSemaphore = new Object();

    private static SearchService _instance;

    static {
        // launch a search db optimization thread once no matter
        // how many SearchService instances get made
        Runnable serviceRunnable = new Runnable() {
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(HEARTBEAT_PERIOD);
                    }
                    catch (InterruptedException ie) {
                        ;
                    }
                    SearchService.instance().heartbeat();
                }
            }
        };
        Thread serviceThread = new Thread(serviceRunnable);
        serviceThread.setName("SearchService Heartbeat");
        serviceThread.start();
}

    public static synchronized SearchService instance() {
		if ( _instance == null ) {
            GroupService.instance(); // dependency: make sure this is around
			_instance = new SearchService();
		}
		return _instance;
    }

    private SearchService() {
        System.out.println("Create SearchService");
        File f = new File(SEARCH_DB_ROOT);
        if ( !f.exists() ) {
            f.mkdir();
        }
        if ( !indexExists() ) {
            indexAllGroupEntries();
        }
    }

    // MAIN INTERFACE

    public SearchResult searchPublic(String keywords,
                                     int offset,
                                     int batchSize,
                                     boolean exact)
    {
        Query query = preparePublicGroupsQuery(keywords, exact);
        if ( query==null ) {
            return null;
        }
        SearchResult result = luceneSearch(query,offset,batchSize);
        return result;
    }

    public SearchResult searchGroup(String keywords,
                                      int groupID,
                                      int offset,
                                      int batchSize,
                                     boolean exact)
    {
        Query query = prepareSpecificGroupQuery(keywords,groupID,exact);
        if ( query==null ) {
            return null;
        }
        SearchResult result = luceneSearch(query,offset,batchSize);
        return result;
    }

    public SearchResult searchGroupList(String keywords,
                                          Vector groupIDs,
                                          int offset,
                                          int batchSize,
                                          boolean exact)
    {
        Query query =
                prepareGroupListQuery(keywords,groupIDs,exact);
        if ( query==null ) {
            return null;
        }
        SearchResult result = luceneSearch(query,offset,batchSize);
        return result;
    }

    public SearchResult luceneSearch(Query luceneQuery, // not keywords
                                     int offset,
                                     int batchSize)
    {
        System.out.println("search: "+luceneQuery.toString(DESCRIPTION_FIELD));
        if ( luceneQuery==null ) {
            return null;
        }
        if ( offset<0 ) {
            offset = 0;
        }
        Searcher searcher = null;
        boolean error = false;
        SearchResult result = new SearchResult();
        try {
            searcher =
                    new IndexSearcher(SEARCH_DB_ROOT);

            System.out.println("lucene searching for: '" +
                    luceneQuery.toString(DESCRIPTION_FIELD)+"'");
            Hits hits = searcher.search(luceneQuery);

            System.out.println(new GregorianCalendar().getTime()+": has "+
                    hits.length() + " total matching documents");

            if ( hits==null || hits.length()==0 ) {
                result.setResults(null);
                result.setNumberOfResults(0);
                result.setTotalNumberOfResults(0);
                searcher.close();
                return result;
            }

            int numberOfResults = 0;
            int totalNumberOfResults = hits.length();
            if (offset+batchSize > hits.length() ) {
                numberOfResults = hits.length()-offset;
            }
            else {
                numberOfResults = batchSize;
            }
            System.out.println("num results= "+numberOfResults);

            if ( numberOfResults<=0 ) {
                ErrorService.instance().error("Bad num results in lucene query '"+
                        luceneQuery+"':"+
                        "offset="+offset+", batchSize="+batchSize+", hits.length()="+
                        hits.length()+
                        ", numresults="+numberOfResults);
                result.setResults(null);
                result.setNumberOfResults(0);
                result.setTotalNumberOfResults(0);
                searcher.close();
                return result;
            }

            Vector results = new Vector(numberOfResults);

            for (int i = offset; i<(offset+numberOfResults); i++) {
                SearchResultItem item = createSearchResultItem(hits.doc(i));
                results.addElement(item);
                item.setScore(hits.score(i));
            }

            result.setTotalNumberOfResults(totalNumberOfResults);
            result.setNumberOfResults(numberOfResults);
            result.setResults(results);

            searcher.close();
            searcher = null;
        }
        catch (Exception e) {
            ErrorService.instance().error("problem searching for '"+luceneQuery+"'", e);
            // try to close search db
            if ( searcher!=null ) {
                try {
                    searcher.close();
                }
                catch (Exception ee) {
                    ErrorService.instance().error("problem closing search index for '"+
                            luceneQuery+"'", ee);
                }
            }
            result = null;
        }
        finally {
            if ( searcher!=null ) {
                try {
                    searcher.close();
                }
                catch (Exception e) {
                    ErrorService.instance().error("problem closing search index for '"+
                            luceneQuery+"'", e);
                }
            }
        }
        return result;
    }

    private SearchResultItem createSearchResultItem(Document doc) throws IOException {
        SearchResultItem item = new SearchResultItem();
        item.setID(Integer.parseInt(doc.get(ID_FIELD)));
        item.setGroupID(Integer.parseInt(doc.get(GROUPID_FIELD)));
        item.setURL(doc.get(URL_FIELD));
        item.setTitle(doc.get(TITLE_FIELD));
        item.setDescription(doc.get(DESCRIPTION_FIELD));
        item.setAccess(Integer.parseInt(doc.get(ACCESS_FIELD)));
        String createdStr = doc.get(DATE_FIELD);
        Date created = null;
        if ( createdStr!=null ) {
            created = DateField.stringToDate(createdStr);
        }
        item.setCreated(created);
        return item;
     }

    /** What to do every heartbeat */
    protected void heartbeat() {
        if ( documentsAddedSinceLastOptimization>=ADDITIONS_BEFORE_OPTIMIZE ) {
            optimize();
            documentsAddedSinceLastOptimization = 0;
        }
    }

    // SEARCH ENTRY ADDITIONS

    public void indexGroupEntry(GroupEntry entry) {
        System.out.println("indexGroupEntry: "+entry);
        try {
            IndexWriter writer =
                    new IndexWriter(SEARCH_DB_ROOT,
                            new PeerscopeStopAnalyzer(),
                            false);
            writer.mergeFactor = DYNAMIC_MERGE_FACTOR;
            Document doc = getGroupEntrySearchDocument(entry);
            writer.addDocument(doc);
            documentsAddedSinceLastOptimization++;
            writer.optimize();
            writer.close();
        }
        catch (Exception e) {
            ErrorService.instance().error("Cannot add entry to search index", e);
        }
    }

    public void indexAllGroupEntries() {
        IndexWriter writer = null;
        try {
            ErrorService.instance().notice("SearchService: rebuilding entire search db");
            long t1 = System.currentTimeMillis();
            writer =new IndexWriter(SEARCH_DB_ROOT,
                        new PeerscopeStopAnalyzer(),
                        true);
            writer.mergeFactor = DYNAMIC_MERGE_FACTOR;
            Vector entries = GroupService.instance().getAllGroupEntries();
            for (int i = 0; i < entries.size(); i++) {
                GroupEntry entry = (GroupEntry) entries.elementAt(i);
                Document doc = getGroupEntrySearchDocument(entry);
                writer.addDocument(doc);
            }
            writer.optimize();
            writer.close();
            long t2 = System.currentTimeMillis();
            ErrorService.instance().notice("SearchService: rebuilt search DB in "+((t2-t1)/1000)+"sec");
        }
        catch (Exception e) {
            ErrorService.instance().error("Cannot create search db", e);
            if ( writer!=null ) {
                try {
                    writer.close();
                }
                catch (IOException ioe) {
                    ErrorService.instance().error("Can't close search db", ioe);
                }
            }
        }
    }

    public void updateGroupEntry(GroupEntry entry) {
        removeGroupEntryFromIndex(entry.getID());
        indexGroupEntry(entry);
    }

    /** Remove a document from db's index */
    public void removeGroupEntryFromIndex(int entryID) {
        System.out.println("remove search document ID="+entryID);
        try {
            IndexReader reader = IndexReader.open(SEARCH_DB_ROOT);
            Term term = new Term("ID", String.valueOf(entryID));
            reader.delete(term); // remove this entry
            reader.close();
        }
        catch (Exception e) {
            ErrorService.instance().error("Cannot remove ID "+entryID+" from search db", e);
        }
    }

    // SUPPORT

	protected Document getGroupEntrySearchDocument(GroupEntry entry) {
        Document doc = new Document();
        doc.add(getFieldCONTENTS(getGroupEntrySearchContents(entry)));
        doc.add(getFieldID(String.valueOf(entry.getID())));
        doc.add(getFieldGROUPID(String.valueOf(entry.getGroupID())));
        doc.add(getFieldURL(entry.getUrl()));
        doc.add(getFieldTITLE(entry.getTitle()));
        doc.add(getFieldDESCRIPTION(entry.getComments()));
        Date created = new Date(entry.getCreated().getTime());
        doc.add(getFieldDATE(created));
        GroupDescriptor cd =
                GroupService.instance().getGroupDescriptor(entry.getGroupID());
        if ( cd==null ) {
            ErrorService.instance().error("Can't get descriptor for group "+entry.getGroupID());
        }
        else {
            doc.add(getFieldACCESS(cd.getAccess()));
        }
        return doc;
    }

    /** What text should be searched when figuring out if a group entry
     *  should be returned from a search.  For now, it does not include
     *  the URL though that may be interesting later.
     */
    protected String getGroupEntrySearchContents(GroupEntry entry) {
        StringBuffer buf = new StringBuffer(400);
        buf.append(entry.getTitle());
        buf.append(' ');
        buf.append(entry.getComments());
        return buf.toString();
    }

    protected void optimize() {
        synchronized (searchDBWriteSemaphore) {
            System.out.println("optimizing search db");
            try {
                IndexWriter writer =
                        new IndexWriter(SEARCH_DB_ROOT,
                                new PeerscopeStopAnalyzer(),
                                false);
                writer.optimize();
                writer.close();
            }
            catch (Exception e) {
                ErrorService.instance().error("Cannot optimize search index", e);
            }
        }
    }

    protected boolean indexExists() {
        boolean exists = false;
        try {
            exists = IndexReader.indexExists(SEARCH_DB_ROOT);
        }
        catch (Exception e) {
            ErrorService.instance().error("Cannot check index for existence", e);
        }
        return exists;
    }

    /*
    protected String preparePublicGroupQueryString(String query,
                                                     boolean makeANDs)
    {
        String keywordStr = prepareLuceneKeywordQueryString(query,makeANDs);
        String qstr = ACCESS_FIELD+":"+GroupDescriptor.PUBLIC_ACCESS+" AND "+keywordStr;
        return qstr;
    }

    protected String prepareSpecificGroupQueryString(String query,
                                                       int groupID,
                                                       boolean makeANDs)
    {
        String keywordStr = prepareLuceneKeywordQueryString(query,makeANDs);
        String qstr = GROUPID_FIELD+":"+groupID+" AND "+keywordStr;
        return qstr;
    }
    */
    /*
    protected String prepareGroupListQueryString(String query,
                                                   Vector groupIDs,
                                                   boolean makeANDs)
    {
        String keywordStr = prepareLuceneKeywordQueryString(query,makeANDs);
        StringBuffer buf=new StringBuffer();
        for (int i = 0; i < groupIDs.size(); i++) {
            Integer groupID = (Integer) groupIDs.elementAt(i);
            buf.append(GROUPID_FIELD+":"+groupID);
            if ((i+1)<groupIDs.size()) {
                buf.append(" AND ");
            }
        }
        String qstr = "("+buf.toString()+") AND "+keywordStr;
        return qstr;
    }

    protected String prepareLuceneKeywordQueryString(String query,
                                                     boolean makeANDs)
    {
        Vector words = new Vector();
        query = normalizedQueryString(query);
        // get list of words
        StringTokenizer st = new StringTokenizer(query);
        while ( st.hasMoreElements() ) {
            String word = (String)st.nextElement();
            words.addElement(word);
        }
        if ( makeANDs ) {
            // TODO: they want every word not just best fit
        }
        String titleQuery =
                catKeywords(words, makeANDs, TITLE_FIELD);
        String contentsQuery =
                catKeywords(words, makeANDs, DESCRIPTION_FIELD);
        String normalizedQuery = "("+titleQuery+" OR "+contentsQuery+")";
        System.out.println("prepareLuceneQueryString("+query+")="+normalizedQuery);
        return normalizedQuery;
    }
    */

    /** Like this access:2 AND (title:(keywords) OR description:(keywords)) */
    protected Query preparePublicGroupsQuery(String keywords, boolean exact) {
        Vector keywordsV = normalizedQueryString(keywords);
        if ( keywordsV==null ) {
            return null;
        }
        Term accessTerm =
                new Term(ACCESS_FIELD,String.valueOf(GroupDescriptor.PUBLIC_ACCESS));

        PhraseQuery keywordsTerm = prepareFieldQuery(CONTENTS_FIELD,keywordsV);
        if ( !exact ) {
            keywordsTerm.setSlop(PHRASE_SLOP);
        }
        BooleanQuery overallQuery = new BooleanQuery();
        overallQuery.add(new TermQuery(accessTerm),true,false);
        overallQuery.add(keywordsTerm,true,false);
        return overallQuery;
    }

    /** Like this groupID:4 AND (title:(keywords) OR description:(keywords)) */
    protected Query prepareSpecificGroupQuery(String keywords,
                                                int groupID,
                                                boolean exact)
    {
        Vector keywordsV = normalizedQueryString(keywords);
        if ( keywordsV==null ) {
            return null;
        }
        Term groupTerm =
                new Term(GROUPID_FIELD,String.valueOf(groupID));

        PhraseQuery keywordsTerm = prepareFieldQuery(CONTENTS_FIELD,keywordsV);
        if ( !exact ) {
            keywordsTerm.setSlop(PHRASE_SLOP);
        }

        BooleanQuery overallQuery = new BooleanQuery();
        overallQuery.add(new TermQuery(groupTerm),true,false);
        overallQuery.add(keywordsTerm,true,false);
        return overallQuery;
    }

    /** Like this (groupID:4 OR groupID:2) AND
     *    (title:(keywords) OR description:(keywords))
     */
    protected Query prepareGroupListQuery(String keywords,
                                            Vector groupIDs,
                                            boolean exact)
    {
        Vector keywordsV = normalizedQueryString(keywords);
        if ( keywordsV==null ) {
            return null;
        }

        BooleanQuery groupQuery = new BooleanQuery();
        for (int i = 0; i < groupIDs.size(); i++) {
            Integer groupID = (Integer) groupIDs.elementAt(i);
            Term groupTerm =
                    new Term(GROUPID_FIELD,String.valueOf(groupID));
            groupQuery.add(new TermQuery(groupTerm), false, false);
        }

        PhraseQuery keywordsTerm = prepareFieldQuery(CONTENTS_FIELD,keywordsV);
        if ( !exact ) {
            keywordsTerm.setSlop(PHRASE_SLOP);
        }

        BooleanQuery overallQuery = new BooleanQuery();
        overallQuery.add(groupQuery,true,false);
        overallQuery.add(keywordsTerm,true,false);
        return overallQuery;
    }

    private String catKeywords(Vector words,
                               boolean makeANDs,
                               String fieldName) {
        if ( words==null || words.size()==0 ) {
            return null;
        }
        StringBuffer normalizedQuery =
            new StringBuffer(words.size()*10);
        if ( fieldName!=null ) {
            normalizedQuery.append(fieldName);
            normalizedQuery.append(":(");
        }
        for (int i=0; words!=null && i<words.size(); i++) {
            if ( i>0 && makeANDs ) {
                normalizedQuery.append(" AND ");
            }
            else {
                normalizedQuery.append(' ');
            }
            String w = (String)words.elementAt(i);
            if ( w.startsWith("*") ) {
                w = w.substring(1,w.length()); // remove * prefixes
            }
            normalizedQuery.append(w);
        }
        if ( fieldName!=null ) {
            normalizedQuery.append(')');
        }
        return normalizedQuery.toString();
    }

    /** Return a vector of words that have been processed by the
     *  same analyzer used to index stuff.
     */
    protected Vector normalizedQueryString(String query) {
        // lower case, etc...
        query = HTMLUtils.stripHTML(query);
        Analyzer analyzer = new PeerscopeStopAnalyzer();
        TokenStream source = analyzer.tokenStream(new StringReader(query));
        Vector words = new Vector();
        try {
            Token tok = source.next();
            while ( tok!=null ) {
                words.addElement(tok.termText());
                tok = source.next();
            }
            source.close();
        }
        catch (IOException ioe) {
            ErrorService.instance().error("can't parse query string", ioe);
            words = null;
        }
        if ( words.size()==0 ) {
            words = null;
        }
        System.out.println("Normalized query words: "+words);
        return words;
    }

    protected PhraseQuery prepareFieldQuery(String field, Vector keywords) {
        if ( keywords==null || keywords.size()==0 ) {
            return null;
        }
        PhraseQuery q = new PhraseQuery();
        for (int i=0; i<keywords.size(); i++) {
          q.add(new Term(field, (String)keywords.elementAt(i)));
        }
        return q;
    }

    // FIELD DEFINITIONS

    /** This field should be a clump of all stuff that is included in search */
    public Field getFieldCONTENTS(String v) {
        return Field.UnStored(CONTENTS_FIELD, v);
    }

    public Field getFieldID(String v) {
         return Field.Keyword(ID_FIELD, v);
    }

    public Field getFieldGROUPID(String v) {
         return Field.Keyword(GROUPID_FIELD, v);
    }

    public static Field getFieldACCESS(int v) {
        return Field.Keyword(ACCESS_FIELD, String.valueOf(v));
    }

    public Field getFieldDATE(java.util.Date v) {
        return Field.Keyword(DATE_FIELD,
                             DateField.dateToString(v));
    }

    public Field getFieldTITLE(String v) {
         return Field.UnIndexed(TITLE_FIELD, v);
    }

    public Field getFieldDESCRIPTION(String v) {
         return Field.UnIndexed(DESCRIPTION_FIELD, v);
    }

    public Field getFieldURL(String v) {
         return Field.Keyword(URL_FIELD, v);
    }

}
