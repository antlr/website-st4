/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr, jGuru.com
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.jguru.peerscope.support;

import java.util.Hashtable;
import java.util.Vector;

/** A hashtable of vectors with nonunique elements.
 *  Put 1 then 2 to "a" and then "a" -> [1,2].  Getting "a"
 *  returns the vector.
 */
public class MultivaluedHashtable {
    protected Hashtable table;

    public MultivaluedHashtable(int sz) {
        table = new Hashtable(sz);
    }

    public MultivaluedHashtable() {
        table = new Hashtable();
    }

    public void put(Object key, Object value) {
        put(key,value,true);
    }

    public void put(Object key, Object value, boolean addToEnd) {
        Vector v = get(key);
        if ( v==null ) {
            v = new Vector();
            table.put(key, v);
        }
        if ( addToEnd ) {
            v.addElement(value);
        }
        else {
            v.insertElementAt(value, 0);
        }
    }


    public Vector remove(Object key) {
        return (Vector)table.remove(key);
    }

    public void remove(Object key, Object value) {
        Vector v = get(key);
        if ( v==null ) {
            return;
        }
        v.remove(value);
        // if nothing left, remove from table
        if ( v.size()==0 ) {
            table.remove(key);
        }
    }

    public Vector get(Object key) {
        return (Vector)table.get(key);
    }
}

