--- sample data
--- assumes entity sequence is new

-- ID = 1
insert into member (ID,created,firstname,lastname,email,password)
VALUES (ENTITYSEQUENCE.NEXTVAL,'2003-02-21','Terence','Parr','parrt@jguru.com','ick');

-- ID = 2
insert into member (ID,created,firstname,lastname,email,password)
VALUES (ENTITYSEQUENCE.NEXTVAL,'2003-02-21','Tom','Burns','tombu@jguru.com','icky');

-- ID = 3
insert into member (ID,created,firstname,lastname,email,password)
VALUES (ENTITYSEQUENCE.NEXTVAL,'2003-02-22','Mel','Berman','mel@jguru.com','hi');

-- ID = 4 owned by ter
insert into descriptor (ID,created,owner,name,description)
VALUES (ENTITYSEQUENCE.NEXTVAL,'2003-02-21',1,'computer languages','all about programming and other computer languages');

-- ID = 5 owned by tombu
insert into descriptor (ID,created,owner,name,description)
VALUES (ENTITYSEQUENCE.NEXTVAL,'2003-02-21',2,'jguru','anything related to jguru.com');

-- we are all members of 'jguru'
insert into membership (MEMBER,GROUP) VALUES (1,5);
insert into membership (MEMBER,GROUP) VALUES (2,5);
insert into membership (MEMBER,GROUP) VALUES (3,5);

-- tom/me members of 'computer languages'
insert into membership (MEMBER,GROUP) VALUES (1,4);
insert into membership (MEMBER,GROUP) VALUES (2,4);

insert into entry (ID,created,author,group,title,url,comments)
VALUES (ENTITYSEQUENCE.NEXTVAL,'2003-02-22',
