Example site: http://www.antlr.org

SETUP

You need resin in /usr/local and set up properly.

You need /var/data/lime/resources and ../descriptors data directories

Logs go to /var/log/lime/http/ (according to my resin setup)

/usr/local/site/lime has the .class files for me.

