/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.lime.page;

import org.pageforge.*;
import org.antlr.stringtemplate.StringTemplate;
import org.antlr.lime.service.LimeApplication;
import org.antlr.lime.service.ContentService;

import java.util.List;

public class HomeMachine extends PageStateMachine {
    public static final int NUM_TO_SHOW_ON_HOMEPAGE = 4;

    static {
        mapState("home", "view", HomePage.class, "home.content");
    }

    /** Any page in this machine is of this type */
    public static class HomeMachinePage extends LimePage {
        /** Do a type conversion for brevity in references.  Damn.  I'd prefer
         *  "state." intead of "state().", but strict typing prevents it.
         *  Must repeat this in every state machine. :(
         */
        protected HomeMachine state() { return (HomeMachine)state; }
    }

    public static class HomePage extends HomeMachinePage {
        public void generateBody(StringTemplate bodyST) throws Exception {
            List articles = ContentService.getDescriptors("article");
            if ( articles!=null ) {
                bodyST.setAttribute("articles", trimmed(articles));
            }
            List showcases = ContentService.getDescriptors("showcase");
            if ( showcases!=null ) {
                bodyST.setAttribute("showcases", trimmed(showcases,3));
            }
            List docs = ContentService.getDescriptors("documentation");
            if ( docs!=null ) {
                bodyST.setAttribute("docs", trimmed(docs));
            }
            List testimonials = ContentService.getDescriptors("testimonial");
            if ( testimonials!=null ) {
                bodyST.setAttribute("testimonials", trimmed(testimonials,3));
            }
            List news = ContentService.getDescriptors("news");
            if ( news!=null ) {
                bodyST.setAttribute("news", trimmed(news));
            }
            List grammars = ContentService.getDescriptors("grammar");
            if ( grammars!=null ) {
                bodyST.setAttribute("grammars", trimmed(grammars));
            }
            List sharing = ContentService.getDescriptors("share");
            if ( sharing!=null ) {
                bodyST.setAttribute("sharing", trimmed(sharing));
            }
        }

        public StringTemplate getPageStringTemplate() {
            return LimeApplication.stringTemplatesLib.getInstanceOf("home.page");
        }

        public String getTitle() { return "Home page"; }

        private List trimmed(List list) {
            return trimmed(list, NUM_TO_SHOW_ON_HOMEPAGE);
        }

        private List trimmed(List list, int max) {
            if ( list==null ) {
                return null;
            }
            int n = max;
            int min = Math.min(list.size(),n);
            return list.subList(0,min);
        }
    }
}

