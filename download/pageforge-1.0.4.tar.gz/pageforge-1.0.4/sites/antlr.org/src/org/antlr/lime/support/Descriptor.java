/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.lime.support;

import org.pageforge.support.Utils;
import org.pageforge.lib.service.ErrorService;
import org.pageforge.lib.html.HTMLUtils;

import java.util.Date;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.antlr.lime.service.PersistenceService;

/** A lime server descriptor for a local or remote resource.  For example,
 *  you can have a showcase descriptor that points to another site or an
 *  uploaded grammar that points to the local file system.
 */
public class Descriptor implements Comparable {
    protected String title;
    protected String link;
    protected String author;
    protected String description;
    protected Date created;

    public Descriptor() {
        setFilename( PersistenceService.getUniqueFileName() );
    }

    /** Is this an article, showcase, or what?  This is computed from
     *  its location under the descriptors root.  root/article/12332434
     *  implies a type of "article".  This property is not stored in
     *  serialized form, but is rather implied by file location.
     */
    protected String type;

    /** Filename within "<docroot>/descriptors/<type>" dir; just the filename */
    protected String filename;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRelativeFilename() {
        return getType()+"/"+getFilename();
    }

    /** Given foo.html return <type>/<descriptorFilename> where a resource
     *  would be stored.
     */
    public String getRelativeResourceDirectory() {
        return getType()+"/"+getFilename();
    }

    /** Get just the filename of this descriptor (no type dir or anything) */
    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getAuthor() {
        return author;
    }

    public String getAbbreviatedAuthor() {
        return Utils.abbrevString(author,40,2);
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDescription() {
        return description;
    }

    public String getAbbreviatedDescription() {
        return Utils.abbrevString(description,70,10);
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreated() {
        return created;
    }

    public String getCreatedSimpleFormat() {
        if ( getCreated()==null ) {
            return "";
        }
        SimpleDateFormat df = new SimpleDateFormat ("EEE MMM d, yyyy HH:mm");
        return df.format(getCreated());
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public void setCreated(String createdStr) {
        if ( createdStr!=null ) {
            try {
                SimpleDateFormat df = new SimpleDateFormat ("yyyy-MM-dd HH:mm");
                this.created = df.parse(createdStr);
            }
            catch (ParseException pe) {
                ErrorService.warning("Bad formatted date in "+getType()+"/"+
                                     getFilename(), pe);
            }
        }
    }

    /** Make sure all the fields are cool.  No newlines and escaped HTML. */
    public void sanitize() {
        stripNewlinesIfNotNull(title);
        stripNewlinesIfNotNull(link);
        stripNewlinesIfNotNull(author);
        stripNewlinesIfNotNull(description);
        escapeHTMLIfNotNull(title);
        escapeHTMLIfNotNull(description);
        stripHTMLIfNotNull(author);
    }

    /** Return a string suitable for saving/restoring this object.
     *  Destructive: newlines are removed to ensure one property / line.
     */
    public String serialize() {
        String nl = System.getProperty("line.separator");
        sanitize();
        StringBuffer buf = new StringBuffer(400);
        buf.append("title="+title); buf.append(nl);
        buf.append("link="+link); buf.append(nl);
        buf.append("author="+author); buf.append(nl);
        // store date as formatted string so I can edit on disk
        SimpleDateFormat df = new SimpleDateFormat ("yyyy-MM-dd HH:mm");
        if ( created!=null ) {
            String createdStr = df.format(created);
            buf.append("created="+createdStr); buf.append(nl);
        }
        buf.append("description="+description); buf.append(nl);
        return buf.toString();
    }

    public void deserialize(String[] serializedProperties) {
        try {
            // walk lines, setting properties of 'this' according to prop name
            for (int i = 0; i < serializedProperties.length; i++) {
                String assignment = serializedProperties[i];
                // format is "property=value"
                if ( assignment==null ) {
                    // blank line in file; ignore
                    continue;
                }
                int equalsIndex = assignment.indexOf('=');
                String propertyName = assignment.substring(0,equalsIndex);
                String propertyValue =
                    assignment.substring(equalsIndex+1,assignment.length());
                if ( propertyValue!=null && propertyValue.trim().length()==0 ) {
                    // don't save "" empty string type values
                    propertyValue = null;
                }
                try {
                    // use reflection to set property for flexibility
                    Utils.setStringProperty(this, propertyName, propertyValue);
                }
                catch (Exception e) {
                    ErrorService.error("Can't set property "+propertyName+
                                       " for descriptor "+getType()+"/"+
                                       getFilename(), e);
                }
            }
        }
        catch (Exception e) {
            ErrorService.error("Problems parsing properties for "+
                               getType()+"/"+getFilename()+
                               " (ignoring descriptor)", e);
        }
    }

    private String stripNewlinesIfNotNull(String value) {
        if ( value!=null ) {
            value = Utils.replace(value, "\n", " "); // replace newline with ' '
            value = Utils.replace(value, "\r", null); // kill \r
        }
        return value;
    }

    private String escapeHTMLIfNotNull(String value) {
        if ( value!=null ) {
            value = HTMLUtils.escapeHTML(value);
        }
        return value;
    }

    private String stripHTMLIfNotNull(String value) {
        if ( value!=null ) {
            value = HTMLUtils.stripHTML(value);
        }
        return value;
    }

    public int compareTo(Object o) {
        Date thatDate = ((Descriptor)o).getCreated();
        Date thisDate = getCreated();
        if ( thatDate==null ) {
            return -1;
        }
        if ( thisDate==null ) {
            return -1;
        }
        return thisDate.compareTo(thatDate);
    }

    /** Print out properties */
    public String toString() {
        StringBuffer buf = new StringBuffer(400);
        buf.append("title="+title);
        buf.append("link="+link);
        buf.append("author="+author);
        buf.append("description="+description);
        buf.append("created="+created);
        return buf.toString();
    }
}
