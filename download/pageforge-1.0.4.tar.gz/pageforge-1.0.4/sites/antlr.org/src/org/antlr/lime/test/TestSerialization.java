/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.lime.test;

import org.pageforge.unit.TestSuite;
import org.pageforge.support.Utils;
import org.antlr.lime.support.Descriptor;

import java.util.Date;

public class TestSerialization extends TestSuite {
    static String[] sampleSerializedDescriptorLines = {
        "title=A simple descriptor",
        "link=http://www.antlr.org",
        "created=1054596545930", // 4:29PM on June 2, 2003
        "author=Ter",
        "description=blah blah blah."
    };

    static String[] sampleSerializedDescriptorLines2 = {
        "title=A simple descriptor",
        "author=Ter",
        "description=blah blah blah."
    };

    public TestSerialization() {
    }

    public void runTests() throws Exception {
        runTest("testDeserialization");
        runTest("testDeserializationWithEmptyValues");
        runTest("testSerialization");
	}

    public void testDeserialization() throws Exception {
        Descriptor d = new Descriptor();
        d.deserialize(sampleSerializedDescriptorLines);
        for (int i = 0; i < sampleSerializedDescriptorLines.length; i++) {
            String assignment = sampleSerializedDescriptorLines[i];
            if ( assignment==null ) {
                continue;
            }
            assertAssignmentTrue(d, assignment);
        }
        assertTrue(true);
    }

    public void testDeserializationWithEmptyValues() throws Exception {
        Descriptor d = new Descriptor();
        d.deserialize(sampleSerializedDescriptorLines2);
        for (int i = 0; i < sampleSerializedDescriptorLines2.length; i++) {
            String assignment = sampleSerializedDescriptorLines2[i];
            if ( assignment==null ) {
                continue;
            }
            assertAssignmentTrue(d, assignment);
        }
        assertTrue(true);
    }

    public void testSerialization() throws Exception {
        // Make a sample object
        Descriptor d = new Descriptor();
        d.deserialize(sampleSerializedDescriptorLines);

        // serialize it
        String data = d.serialize();
        // now compare
        String[] lines = Utils.splitIntoLines(data);
        for (int i = 0; i < lines.length; i++) {
            String assignment = lines[i];
            if ( assignment==null ) {
                continue;
            }
            assertAssignmentTrue(d, assignment);
        }

        assertTrue(true);
    }

    // SUPPORT CODE

    private void assertAssignmentTrue(Descriptor descriptor, String assignment)
        throws Exception
    {
        int equalsIndex = assignment.indexOf('=');
        String propertyName = assignment.substring(0,equalsIndex);
        String propertyValue =
            assignment.substring(equalsIndex+1,assignment.length());
        Object value = Utils.getProperty(descriptor,propertyName);
        assertTrue(value!=null,
                   "property "+propertyName+" not in descriptor");
        // icky special case for date
        if ( propertyName.equals("created") ) {
            assertTrue(((Date)value).getTime()==Long.parseLong(propertyValue),
                       "assignment '"+assignment+"' differs from descriptor value='"+value+"'");
        }
        else {
            assertTrue(value.toString().equals(propertyValue),
                       "assignment '"+assignment+"' differs from descriptor value='"+value+"'");
        }
    }
}
