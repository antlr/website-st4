/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.lime.page;

import org.pageforge.PageDispatcher;
import org.pageforge.PageForgeApplication;
import org.antlr.lime.service.LimeApplication;
import org.antlr.lime.LimePageForgeGlue;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.File;
import java.util.StringTokenizer;

public class LimePageDispatcher extends PageDispatcher {
    protected boolean rewrite(HttpServletRequest request,
                              HttpServletResponse response)
        throws ServletException, IOException
    {
        // handle .html files and other files to process
        String uri = request.getRequestURI();

        if ( uri.toUpperCase().endsWith(".HTML") ||
             uri.toUpperCase().endsWith(".ST") ||
             uri.toUpperCase().endsWith(".TML") ) {
            forward("/misc/get?file="+uri,
                    request,
                    response);
            return true;
        }

        // route /xxx/list to /misc/listresources?type=xxx
        if ( uri.endsWith("/list") ) {
            StringTokenizer st = new StringTokenizer(uri, "/?");
            String type = null;
            if ( st.hasMoreTokens() ) {
                type = st.nextToken();
            }
            if ( type!=null && uri.equals("/"+type+"/list") ) {
                forward("/misc/listresources?type="+type,
                        request,
                        response);
                return true;
            }
        }

        // route directory name xxx under /resources to /misc/listdir?name=xxx
        if ( !uri.equals("/") ) { // don't route home page ;)
            File dir = new File(LimeApplication.getProperty("document.root")+uri);
            if ( dir.exists() && dir.isDirectory() ) {
                forward("/misc/listdir?name="+uri, request, response);
                return true;
            }
        }

        return false;
    }

    public PageForgeApplication createPageForgeApplication() {
        return new LimePageForgeGlue();
    }
}
