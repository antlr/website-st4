/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.lime.page;

import org.pageforge.PageStateMachine;
import org.pageforge.support.VerifyException;
import org.pageforge.support.Utils;
import org.pageforge.support.StreamBuffer;
import org.antlr.stringtemplate.*;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Iterator;
import java.io.File;

import org.antlr.lime.support.Descriptor;
import org.antlr.lime.service.ContentService;
import org.apache.commons.fileupload.FileUpload;
import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;

public class SubmitMachine extends PageStateMachine {
    static {
        mapState("submit", "edit", SubmitOrEditResourcePage.class, "submit/edit");
        mapState("submit", "process", SubmitProcessPage.class);
    }

    /** Any page in this machine is of this type */
    public static class SubmitMachinePage extends LimePage {
        /** Do a type conversion for brevity in references.  Damn.  I'd prefer
         *  "state." intead of "state().", but strict typing prevents it.
         *  Must repeat this in every state machine. :(
         */
        protected SubmitMachine state() { return (SubmitMachine)state; }
    }

    public static class SubmitOrEditResourcePage extends SubmitMachinePage {
        String type = null;
        public void verify() throws VerifyException {
            requireParameter("type");
            type = request.getParameter("type");
            if ( !ContentService.isValidResourceType(type) ) {
                throw new VerifyException("Resource type "+type+" is not valid.");
            }
        }

        public void generateBody(StringTemplate bodyST) throws Exception {
            bodyST.setAttribute("type", type);
        }

        public String getTitle() { return "Submit "+type; }
    }

    public static class SubmitProcessPage extends SubmitMachinePage {
        /** Used in lieu of processEvent since Page Machine does not know
         *  how to pull the event parameter out of a multi-part form.  We
         *  need to make a process page the old-fashioned way.
         */
        public void generateBody(StreamBuffer out) throws Exception {
            String type = null;
            // goal is to fill this descriptor
            Descriptor descriptor = new Descriptor();
            // do they want me to unzip file?
            boolean unzip = false;
            // assume post
            // fill in the descriptor to submit/edit with incoming values
            boolean isMultipart = FileUpload.isMultipartContent(request);
            if ( isMultipart ) {
                DiskFileUpload upload = new DiskFileUpload();

                // Parse the upload request
                List /* of FileItem */ items = upload.parseRequest(request);
                // Parse all parameters first as we need "type"
                Iterator iter = items.iterator();
                List validFields = Utils.toArrayList(
                        new Object[] {"title","link","author","type",
                                      "description"}
                );
                while (iter.hasNext()) {
                    FileItem item = (FileItem) iter.next();
                    // Process a regular form field
                    String fieldName = item.getFieldName();
                    String value = item.getString();
                    if ( fieldName.equals("unzip") ) {
                        unzip = value.equals("on");
                        System.out.println("unzip set to "+value+"="+unzip);
                    }
                    else if (item.isFormField() && validFields.contains(fieldName) ) {
                        Utils.setStringProperty(descriptor,
                                                fieldName,
                                                value);
                        if ( fieldName.equals("type") ) {
                            type = value;
                        }
                    }
                }
                if ( type==null || !ContentService.isValidResourceType(type) ) {
                    throw new VerifyException("Resource type "+type+" is not valid.");
                }
                // Now walk again looking for file upload
                iter = items.iterator();
                while (iter.hasNext()) {
                    FileItem item = (FileItem) iter.next();
                    // Process a regular form field
                    if (!item.isFormField()) {
                        // Process file upload; store in resources area
                        String fileName = item.getName();
                        if ( fileName==null || fileName.trim().length()==0 ) {
                            continue;
                        }
                        System.out.print("normalizing "+fileName+" to ");
                        // normalize file
                        // scan backwards until you find /, \, :
                        int i = fileName.length()-1;
                        while ( i>=0 &&
                                fileName.charAt(i)!='/' &&
                                fileName.charAt(i)!='\\' &&
                                fileName.charAt(i)!=':' )
                        {
                            i--;
                        }
                        // take just filename part; no path
                        fileName = fileName.substring(i+1,fileName.length());
                        System.out.println(fileName);
                        if ( fileName.indexOf(' ')>=0 ) {
                            throw new VerifyException("You cannot have a space in filenames on UNIX.  Sorry.");
                        }
                        ContentService.addResource(descriptor, item, fileName, unzip);
                    }
                }
            }
            else {
                descriptor.setTitle(request.getParameter("title"));
                descriptor.setLink(request.getParameter("link"));
                descriptor.setAuthor(request.getParameter("author"));
                descriptor.setDescription(request.getParameter("description"));
                descriptor.setType(request.getParameter("type"));
            }

            // STORE DESCRIPTOR FOR EITHER LINK OR UPLOADED FILE
            ContentService.addDescriptor(descriptor);

            doRedirect("/"+descriptor.getType()+"/list");
        }

        public String getTitle() {
            return "processing...";
        }
    }


}
