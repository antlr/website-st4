/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.lime.service;

import org.pageforge.lib.service.LogService;
import org.pageforge.lib.service.ErrorService;
import org.pageforge.lib.service.EmailService;
import org.pageforge.lib.service.EmailServiceListener;
import org.pageforge.support.Utils;
import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateErrorListener;

import java.util.TimeZone;
import java.util.ArrayList;

public class LimeApplication {
    static String DOCUMENT_ROOT = "/var/data/lime/resources";
    static String DESCRIPTORS_ROOT = "/var/data/lime/descriptors";
    static String ABOUT_FILENAME = "about.st";
    static String HIGHLIGHT_FILENAME = "highlight";

    static final String[] requiredResourceTypes = {
        "article",
        "documentation",
        "showcase"
    };

    static String timeLaunched = null;

    /** Indicate we have not initialized the app yet.  PageDispatcher
     *  will call initialize upon first page invocation, which starts
     *  init process and clears this var immediately so next
     *  PeerscopePage doesn't try to init app again.
     *
     *  Only a PageController ctor should invoke intialize() so that
     *  things like command-line tools have no change of launching
     *  a complete portal init w/o meaning too.
     */
    private static boolean initialized = false;
    private static boolean initPhase = false;
    private static boolean devLaunch = true;

    /** This is the current and only "skin"; pull templates from this
     *  group.
     */
    public static org.antlr.stringtemplate.StringTemplateGroup stringTemplatesLib =
            new org.antlr.stringtemplate.StringTemplateGroup("default",
                                    "/usr/local/site/lime/lib/templates",
                                    "$", "$");

    static {
        // Force timezone to be CA time
        TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
        TimeZone.setDefault(tz);
        stringTemplatesLib.setRefreshInterval(0); // don't cache
	}

    public synchronized static void initialize() {
        if ( initialized || initPhase ) {  // only allow one of these threads to start
            return;
        }
        initPhase = true;
        // now, launch a thread to init site in background
        // original thread that started up a page will come here, launch
        // init and then immediately meditate.
        if ( devLaunch ) {
            System.out.println("Lime: begin initialization");
            timeLaunched = LogService.getCurrentTimeStamp();
            systemInitialize();
            // don't conflict with thread that started us
            synchronized (LimeApplication.class) {
                initialized = true;
                initPhase = false;  // no longer busy
            }
            System.out.println("Lime: end initialization");
        }
        else {
            Runnable runnable =
                    new Runnable() {
                        public void run() {
                            System.out.println("Lime: begin initialization");
                            timeLaunched = LogService.getCurrentTimeStamp();
                            systemInitialize();
                            // don't conflict with thread that started us
                            synchronized (LimeApplication.class) {
                                initialized = true;
                                initPhase = false;  // no longer busy
                            }
                            System.out.println("Lime: end initialization");
                        }
                    };
            new Thread(runnable).start();
        }
    }

    private static void systemInitialize() {
        //StringTemplate.setDebugMode(true);

        // LOGGING SETUP
        LogService.setRootDirectory("/var/log/lime");

        // EMAIL SETUP
        EmailService.setSMTPServer("127.0.0.1");
        ArrayList me = new ArrayList();
        me.add("parrt@antlr.org");
        EmailService.setAlwaysContact(me);
        EmailService.setListener(
            new EmailServiceListener() {
                public void error(String s, Exception e) {
                    ErrorService.error(s,e);
                }
                public void simulated(String from, String to, String subject, String message) {
                    System.out.println("From "+from+" to "+to+": "+subject);
                }
                public void log(String from, String to, String subject, String message) {
                    LogService.log("email", "From "+from+" to "+to+": "+subject);
                }
            }
        );

        // LOAD CONTENT
        ContentService.sanityCheck(
            Utils.toArrayList(requiredResourceTypes)
        );
    }

    public static boolean openForBusiness() {
        return initialized;
    }

    public static boolean isLiveSite() {
        return true;
    }

    public static String getProperty(String name, String defaultValue) {
        if ( name==null ) {
            return null;
        }
        // hardcode for now
        if ( name.equals("smtp.server") ) {
            return "127.0.0.1";
        }
        if ( name.equals("smtp.failover") ) {
            return "127.0.0.1";
        }
        if ( name.equals("site.contact") ) {
            return "parrt@antlr.org";
        }
        if ( name.equals("descriptors.root") ) {
            return DESCRIPTORS_ROOT;
        }
        if ( name.equals("document.root") ) {
            return DOCUMENT_ROOT;
        }
        if ( name.equals("about.filename") ) {
            return ABOUT_FILENAME;
        }
        if ( name.equals("highlight.filename") ) {
            return HIGHLIGHT_FILENAME;
        }
        return null;
    }

    public static String getProperty(String name) {
        return getProperty(name, null);
    }

    public static void shutdown() throws Exception {
        ErrorService.notice("lime shutdown...");
        System.exit(0);
    }

}
