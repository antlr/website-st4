/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.lime.service;

import org.pageforge.support.Utils;
import org.pageforge.support.ListApplicator;
import org.pageforge.lib.service.ErrorService;

import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.io.*;

import org.antlr.lime.support.Descriptor;
import org.apache.commons.fileupload.FileItem;

/** A layer over the persistence service that caches data and provides
 *  utility routines for displaying data on the site.
 */

public class ContentService {
    /** A unique 1-to-1 map from filename (<type>/<file>) to Descriptor object.
     *  All other indices map to this unique identifier rather than to an actual
     *  object so I can edit objects w/o updating every index.
     */
    static Map fileNameToDescriptorMap = new HashMap();

    /** Cache the descriptors for each type */
    static Map typeToDescriptorsMap = new HashMap();

    //static Map typeToAboutMap = new HashMap();

    static {
        init();
        System.out.println("type map "+typeToDescriptorsMap);
    }

    private ContentService() {
    }

    /** A totally UNSAFE reload of the data.  Somebody could ask for data or try
     *  to add while I'm blasting this, but it will be rare and noncatastrophic.
     *  This service is not set up properly (design-wise) to be reloaded safely.
     */
    public static void reload() {
        fileNameToDescriptorMap = new HashMap();
        typeToDescriptorsMap = new HashMap();
        init();
    }

    public static void init() {
        // GET RESOURCE TYPES
        List types = PersistenceService.getDescriptorTypes();
        Iterator iterator = types.iterator();
        try {
            while (iterator.hasNext()) {
                String type = (String) iterator.next();
                // GET ALL RESOURCE DESCRIPTORS
                List descriptors = PersistenceService.loadDescriptors(type);

                // MAP FILENAMES (unique IDs) to DESCRIPTOR OBJECTS
                Iterator iter = descriptors.iterator();
                while ( iter.hasNext() ) {
                    Descriptor d = (Descriptor)iter.next();
                    fileNameToDescriptorMap.put(d.getRelativeFilename(), d);
                }

                // MAP TYPE TO LIST OF DESCRIPTOR IDS
                List descriptorFilenames = new LinkedList();
                iter = descriptors.iterator();
                while ( iter.hasNext() ) {
                    Descriptor d = (Descriptor)iter.next();
                    descriptorFilenames.add(d.getRelativeFilename());
                }
                typeToDescriptorsMap.put(type, descriptorFilenames);

                /*
                // GET RESOURCE ABOUT DESCRIPTIONS
                String about = PersistenceService.loadAbout(type);
                if ( about!=null ) {
                    typeToAboutMap.put(type, about);
                }
                */
            }
        }
        catch (IOException ioe) {
            ErrorService.panic("Can't load content types",null);
        }
    }

    /** Get a list of descriptor objects */
    public static List getDescriptors(String type) {
        List descriptorFilenames = (List)typeToDescriptorsMap.get(type);
        // System.out.println("Type list for "+type+" returned from map "+descriptorFilenames);
        return fileNamesToDescriptors(descriptorFilenames);
    }

    private static List fileNamesToDescriptors(List descriptorFilenames) {
        if ( descriptorFilenames==null ) {
            return null;
        }
        List descriptors = new LinkedList();
        Iterator iter = descriptorFilenames.iterator();
        while (iter.hasNext()) {
            String filename = (String)iter.next();
            Descriptor d = getDescriptor(filename);
            descriptors.add(d);
        }
        return descriptors;
    }

    public static Descriptor getDescriptor(String filename) {
        return (Descriptor)fileNameToDescriptorMap.get(filename);
    }

    public static String getAbout(String type) {
        String about = null;
        try {
            about = PersistenceService.loadAbout(type);
        }
        catch (IOException ioe) {
            ErrorService.warning("No about splash for type "+type, ioe);
        }
        return about;
    }

    public static List getHighlights(String type) {
        List descriptors = null;
        try {
            List filenames = PersistenceService.loadHighlights(type);
            descriptors = fileNamesToDescriptors(filenames);
        }
        catch (IOException ioe) {
            ErrorService.warning("No highlights for type "+type, ioe);
        }
        return descriptors;
    }

    public static String addDescriptor(Descriptor d) {
        if ( d==null || d.getType()==null ) {
            ErrorService.error("addDescriptor: Descriptor or resource type null",null);
            return null;
        }
        try {
            // PERSIST
            PersistenceService.addDescriptor(d);

            // NOW, add to index
            fileNameToDescriptorMap.put(d.getRelativeFilename(), d);
            List descriptorFilenames = (List)typeToDescriptorsMap.get(d.getType());
            descriptorFilenames.add(0,d.getRelativeFilename()); // insert at head
            // System.out.println("list for type "+d.getType()+" is "+descriptorFilenames);
        }
        catch (IOException ioe) {
            ErrorService.error("addDescriptor: can't add new descriptor of type "+
                               d.getType(),ioe);
        }
        return d.getFilename();
    }

    /** Add a resource file. */
    public static void addResource(Descriptor descriptor,
                                   FileItem item,
                                   String fileName,
                                   boolean unzip)
    {
        try {
            if ( unzip && fileName.toUpperCase().endsWith(".ZIP") ) {
                PersistenceService.unzipUploadedFile(descriptor, item);
            }
            /*
            else if ( unzip && fileName.toUpperCase().endsWith("TAR.GZ") ) {
                PersistenceService.unTAZUploadedFile(descriptor, item);
            }
            */
            else {
                // simple file upload
                File f = PersistenceService.getFileForResource(descriptor,fileName);
                item.write(f);
                descriptor.setLink("/"+
                                   descriptor.getRelativeResourceDirectory()+
                                   "/"+fileName);
            }
        }
        catch (Exception ioe) {
            ErrorService.error("addDescriptor: can't add new resource of type "+
                               descriptor.getType()+"; resource name="+fileName,ioe);
        }
    }

    public static boolean isValidResourceType(String type) {
        Set keys = typeToDescriptorsMap.keySet();
        return keys.contains(type);
    }

    /** Send in a list of types the application expects.  Return true if ok. */
    public static boolean sanityCheck(List types) {
        Iterator iterator = types.iterator();
        boolean ok = true;
        while (iterator.hasNext()) {
            String type = (String) iterator.next();
            if ( typeToDescriptorsMap.get(type)==null ) {
                ErrorService.panic("Required resource type "+type+" not found",null);
                ok=false;
            }
        }
        return ok;
    }
}
