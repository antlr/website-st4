/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.lime.service;

import org.antlr.lime.support.Descriptor;
import org.apache.commons.fileupload.FileItem;
import org.pageforge.support.FileUtils;
import org.pageforge.support.Utils;
import org.pageforge.lib.service.ErrorService;

import java.io.*;
import java.util.*;
import java.util.jar.JarInputStream;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipFile;

/** Read / write descriptors.  The file format of a descriptor is
 *  essentially that of a Java property file.  I reimplement so
 *  that "property=value\n" calls setProperty() on the descriptor.
 *  Very easy way to allow for future properties in Descriptor
 *  w/o having to modify the code that reads/writes properties.
 *  The filename for a descriptor is the system time in MS
 *  for uniqueness (or any other unique integer in case you do
 *  a descriptor by hand).
 *
 *  The directory under the descriptors.root holds the "type" like
 *  /usr/local/site/lime/descriptors/article
 *  /usr/local/site/lime/descriptors/showcase
 *
 *  This makes the software flexible in that new types don't force you to
 *  recode/modify software, but you loose static typing. :(  An object that
 *  sits on type could do static typing like getArticleDescriptors().
 */
public class PersistenceService {
    static String descriptorsRoot =
        LimeApplication.getProperty("descriptors.root");
    static String documentRoot =
        LimeApplication.getProperty("document.root");

    private PersistenceService() {
    }

    public static List getDescriptorTypes() {
        File root = new File(descriptorsRoot);
        if ( !root.exists() ) {
            ErrorService.panic("Descriptor root does not exist!", null);
            return null;
        }
        String[] types = root.list();
        List list = Utils.toArrayList(types);
        System.out.println("list of types: "+list);
        return list;
    }

    /** Load all descriptor files in, say, "article" but not about.st.
     *  Return a non-null empty list if the type exists, but has no entries.
     */
    public static List loadDescriptors(String type)
        throws IOException
    {
        File descriptorsDir = new File(descriptorsRoot+"/"+type);
        if ( !descriptorsDir.exists() ) {
            return null;
        }
        String[] descriptors = descriptorsDir.list();
        List list = new LinkedList();
        for (int i = 0; i < descriptors.length; i++) {
            String descriptorFileName = descriptors[i];
            if ( descriptorFileName.equals(LimeApplication.getProperty("about.filename")) ) {
                continue;
            }
            if ( descriptorFileName.equals(LimeApplication.getProperty("highlight.filename")) ) {
                continue;
            }
            Descriptor d = load(type, descriptorFileName);
            list.add(d);
        }
        // SORT BY REVERSE CREATED
        //Collections.sort(list);
        Collections.sort(list, Collections.reverseOrder());

        return list;
    }

    public static String loadAbout(String type)
        throws IOException
    {
        File descriptorsDir = new File(descriptorsRoot+"/"+type);
        if ( !descriptorsDir.exists() ) {
            return null;
        }
        String aboutFilename = descriptorsRoot+"/"+type+"/"+
            LimeApplication.getProperty("about.filename");
        File resourceTypeAbout = new File(aboutFilename);
        if ( !resourceTypeAbout.exists() ) {
            return null;
        }
        return FileUtils.getFileContents(aboutFilename).toString();
    }

    /** Load a descriptor such as article/1054596545930 */
    public static Descriptor load(String type, String name)
        throws IOException
    {
        String filename = descriptorsRoot+"/"+type+"/"+name;
        System.out.println("loading descr: "+filename);
        String[] properties = FileUtils.getFileContentsAsLines(filename);
        if ( properties==null ) {
            return null;
        }
        Descriptor d = new Descriptor();
        d.setFilename(name);
        d.setType(type);
        d.deserialize(properties);
        return d;
    }

    /** Load a file containing a list of filenames to highlight on site within
     *  this type.  Return a list of <type>/<filename> strings.
     */
    public static List loadHighlights(String type)
        throws IOException
    {
        String filename = descriptorsRoot+"/"+
            type+"/"+
            LimeApplication.getProperty("highlight.filename");
        System.out.println("loading highlight file: "+filename);
        String[] filenames = FileUtils.getFileContentsAsLines(filename);
        if ( filenames==null ) {
            return null;
        }
        List list = new ArrayList(filenames.length);
        for (int i = 0; i < filenames.length; i++) {
            String f = filenames[i];
            f = type+"/"+f;
            File a = new File(descriptorsRoot+"/"+f);
            if ( a.exists() ) {
                list.add(i, f);
            }
        }
        if ( list.size()==0 ) {
            list = null;
        }
        return list;
    }

    /** Write descriptor to a unique file under "<docroot>/descriptors/<type>".
     *  Set the filename property of the descriptor as you write.  This does
     *  not update a descriptor--it writes a new file.
     */
    public static String addDescriptor(Descriptor descriptor)
        throws IOException
    {
        if ( descriptor == null || descriptor.getType() == null ) {
            return null;
        }
        String freezeDriedData = descriptor.serialize();
        String filename =
            descriptorsRoot+"/"+
            descriptor.getRelativeFilename();
        System.out.println("writing descriptor: "+filename);
        FileUtils.putFileContents(filename, freezeDriedData);
        return filename;
    }

    /** People will upload files with random names and extensions.  The only
     *  The only safe thing to do is write upload files to:
     *
     *   "resources/type/timestamp/filename"
     */
    public static File getFileForResource(Descriptor descriptor, String name)
    {
        String filename = documentRoot+"/"+descriptor.getRelativeResourceDirectory()+"/"+name;
        System.out.println("requesting file for "+filename);
        File f = new File(filename);
        File parent = new File(f.getParent());
        parent.mkdirs(); // make sure the path exists
        return f;
    }

    /** pull apart the gzip file and then untar to disk.
     *  Shit.  This doesn't work.  It does write a valid tar file to disk,
     *  JarFile doesn't seem to load tar files!
     */
    public static void unTAZUploadedFile(Descriptor descriptor,
                                         FileItem item)
        throws IOException
    {
        String indexFile = null;
        String tempFilename = "/tmp/"+System.currentTimeMillis()+".tar";
        FileOutputStream fos =
            new FileOutputStream(tempFilename);
        InputStream is = item.getInputStream();
        GZIPInputStream gzis = new GZIPInputStream(is);
        byte[] buf = new byte[8192]; // 8k buffer
        int nr = gzis.read(buf);
        while ( nr!=-1 ) {
            fos.write(buf, 0, nr);
            nr = gzis.read(buf);
        }
        gzis.close();
        is.close();
        fos.close();

        System.out.println("uncompressed "+item);

        // read back as tar file and write files
        File tf = new File(tempFilename);
        JarFile jf = new JarFile(tf, false, ZipFile.OPEN_READ);
        Enumeration enum = jf.entries();
        while ( enum.hasMoreElements() ) {
            JarEntry entry = (JarEntry)enum.nextElement();
            System.out.println("tar entry "+entry);
            String filename = entry.getName();
            if ( filename.toUpperCase().endsWith("INDEX.HTML") ) {
                indexFile = filename;
            }
            // Write entry to disk
            long decompressedSize = entry.getSize();
            byte[] uncompressedBuf = new byte[(int)decompressedSize];
            InputStream eis = jf.getInputStream(entry);
            eis.read(uncompressedBuf);
            eis.close();
            writeFile(descriptor,
                      filename,
                      uncompressedBuf);
        }
        jf.close();
        System.out.println("index file is "+indexFile);
    }

    /** pull apart the zip file and write to disk. */
    public static void unzipUploadedFile(Descriptor descriptor,
                                         FileItem item)
        throws IOException
    {
        // root under doc root
        InputStream is = item.getInputStream();
        ZipInputStream zis = new ZipInputStream(new BufferedInputStream(is));
        String indexFile = null;

        ZipEntry entry = zis.getNextEntry();
        while (entry != null) {
            System.out.println("entry "+entry);
            String filename = entry.getName();
            if ( filename.toUpperCase().endsWith("INDEX.HTML") ) {
                indexFile = filename;
            }
            if ( !entry.isDirectory() ) {
                // Write entry to disk
                long decompressedSize = entry.getSize();
                byte[] uncompressedBuf = new byte[(int)decompressedSize];
                int n = zis.read();
                int i = 0;
                while ( n!=-1 ) {
                    uncompressedBuf[i] = (byte)n;
                    i++;
                    n = zis.read();
                }
                System.out.println("read "+i+" bytes");
                //zis.read(uncompressedBuf);
                writeFile(descriptor,
                          filename,
                          uncompressedBuf);
            }
            entry = zis.getNextEntry();
        }
        System.out.println("index file is "+indexFile);
        descriptor.setLink("/"+
                           descriptor.getRelativeResourceDirectory()+"/"+
                           indexFile);
        System.out.println("link is "+"/"+
                           descriptor.getRelativeResourceDirectory()+"/"+
                           indexFile);
        zis.close();
    }

    /** Write a file (usually zip entry) associated with a descriptor */
    public static void writeFile(Descriptor descriptor,
                                 String filename,
                                 byte[] data)
        throws IOException
    {
        String absoluteFilename =
            documentRoot+"/"+descriptor.getRelativeResourceDirectory()+"/"+filename;
        File f = new File(absoluteFilename);
        File parent = f.getParentFile();
        System.out.println("making dir "+parent);
        parent.mkdirs(); // ensure pareent dir exists
        // write file
        FileOutputStream fos = new FileOutputStream(f);
        System.out.println("writing absolute zip file entry "+f);
        fos.write(data);
        fos.close();
    }

    /** Get a unique filename.  Since it is based up on the system MS count,
     *  don't ask for a new filename more than once per ms ;)
     */
    public static String getUniqueFileName() {
        long ms = System.currentTimeMillis();
        return Long.toString(ms);
    }

    public static String getUniqueDirName() {
        return getUniqueFileName();
    }

}
