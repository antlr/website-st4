/*
 [The "BSD licence"]
 Copyright (c) 2003 Terence Parr
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.antlr.lime.page;

import org.pageforge.PageStateMachine;
import org.pageforge.support.StreamBuffer;
import org.pageforge.support.VerifyException;
import org.pageforge.support.FileUtils;
import org.pageforge.support.Utils;
import org.antlr.stringtemplate.*;
import org.pageforge.lib.service.EmailService;
import org.pageforge.lib.service.ErrorService;
import org.pageforge.lib.html.HTMLUtils;
import org.antlr.lime.service.LimeApplication;
import org.antlr.lime.service.ContentService;
import org.antlr.tml.DefaultTMLEngine;
import org.antlr.tml.HTMLTarget;
import org.antlr.tml.TMLTranslator;

import java.util.List;
import java.io.StringReader;
import java.io.BufferedReader;
import java.io.StringWriter;
import java.io.File;

public class MiscMachine extends PageStateMachine {

    static {
        mapState("misc", "message", MessagePage.class, "misc/message");
        mapState("misc", "contact", ContactPage.class, "misc/contact");
        mapState("misc", "get", AddLookNFeelToContentPage.class);
        mapState("misc", "listresources", ListDescriptorsPage.class, "descriptor/list");
        mapState("misc", "listdir", ListDirPage.class, "misc/dir");
        mapState("misc", "reload", ReloadDataPage.class);
    }

    /** Any page in this machine is of this type */
    public static class MiscMachinePage extends LimePage {
        /** Do a type conversion for brevity in references.  Damn.  I'd prefer
         *  "state." intead of "state().", but strict typing prevents it.
         *  Must repeat this in every state machine. :(
         */
        protected MiscMachine state() { return (MiscMachine)state; }
    }

    public static class ContactPage extends MiscMachinePage {
        public boolean mustBeLoggedIn() { return false; }
        public String getTitle() { return "Contact ANTLR.org"; }

        public void processEvent(String eventName) throws Exception {
            if ( eventName.equals("submit") ) {
                requireParameters(
                             new String[] {"name","comments","email"});
                String email = request.getParameter("email").trim().toLowerCase();
                String comments = request.getParameter("comments");
                String name = request.getParameter("name");

                String contactTarget = "parrt@antlr.org";

                EmailService.sendEmail(email,
                        contactTarget,
                        "antlr.org contact",
                        name+" wrote:\n\n"+comments);

                doMessageRedirect("Your message concerning has been sent to the appropriate PeerScope.com person.");
            }
            else if ( eventName.equals("cancel") ) {
                doRedirect("/");
            }
        }
    }

    /** This is the page for displaying messages like confirmations etc... */
    public static class MessagePage extends MiscMachinePage {
        public void generateBody(StringTemplate bodyST) throws Exception {
            requireParameter("msg");
            String msg = request.getParameter("msg");
            bodyST.setAttribute("msg", msg);
        }

        public String getTitle() { return "Message page"; }
    }

    public static class AddLookNFeelToContentPage extends MiscMachinePage {
        String title = null;
        String body = null;
        String uri = null;

        public void verify() throws VerifyException {
            requireParameter("file");
            String resourceRoot = LimeApplication.getProperty("document.root");
            uri = request.getParameter("file");
            String completeFilename = resourceRoot+uri;
            try {
                if ( uri.toUpperCase().endsWith(".TML") ) {
                    System.out.println("going to TML translate "+completeFilename);
                    String tml = FileUtils.getFileContents(completeFilename).toString();
                    StringReader sr = new StringReader(tml);
                    BufferedReader br = new BufferedReader(sr);
                    title = br.readLine(); // title is first line
                    // Process the TML
                    StringWriter output = new StringWriter();
                    TMLTranslator target = new HTMLTarget(output); // default
                    DefaultTMLEngine engine = new DefaultTMLEngine(br);
                    try {
                        engine.translate(target);
                    }
                    catch (Exception atse) {
                        ErrorService.error("TML lexer error", atse);
                    }
                    br.close();
                    sr.close();
                    output.close();
                    body = output.getBuffer().toString();
                }
                else {
                    StringBuffer titleBuf = new StringBuffer(100);
                    body = FileUtils.getHTMLFileBodyAndTitle(completeFilename, titleBuf);
                    title = titleBuf.toString();
                }
            }
            catch (Exception e) {
                throw new VerifyException("Problems extracting content/title from file "+
                                          uri+": "+HTMLUtils.escapeHTML(e.getMessage()));
            }
        }

        public void generateBody(StreamBuffer out) throws Exception {
            // if no body string template, this will be called.
            out.print(body);
        }

        public StringTemplate getBodyStringTemplate() {
            if ( uri.toUpperCase().endsWith(".ST") ) {
                return new StringTemplate(LimeApplication.stringTemplatesLib,
                                          body);
            }
            return null; // if HTML or something other than .st, no template
        }

        public String getTitle() { return title; }
    }

    public static class ListDescriptorsPage extends MiscMachinePage {
        String type = null;
        public void verify() throws VerifyException {
            requireParameter("type");
            type = request.getParameter("type");
            if ( !ContentService.isValidResourceType(type) ) {
                throw new VerifyException("No such resource type: "+type);
            }
        }

        public void generateBody(StringTemplate bodyST) throws Exception {
            bodyST.setAttribute("type", type);
            String about = ContentService.getAbout(type);
            if ( about!=null ) {
                bodyST.setAttribute("about",
                                    new StringTemplate(LimeApplication.stringTemplatesLib,
                                                       about));
            }
            List highlights = ContentService.getHighlights(type);
            if ( highlights!=null ) {
                // set in body in case they want to display without an about
                // the about.st template will inherit this value so it can use
                System.out.println("highlights: "+highlights);
                bodyST.setAttribute("highlights", highlights);
            }
            List descriptors = ContentService.getDescriptors(type);
            if ( descriptors!=null ) {
                bodyST.setAttribute("descriptors", descriptors);
            }
        }

        public String getTitle() { return Utils.capitalize(type)+" List"; }
    }

    public static class ListDirPage extends MiscMachinePage {
        String name = null;
        File dirFile = null;
        public void verify() throws VerifyException {
            requireParameter("name");
            name = request.getParameter("name");
            String docRoot = LimeApplication.getProperty("document.root");
            dirFile = new File(docRoot+name);
            if ( !dirFile.exists() ) {
                throw new VerifyException("Directory "+name+" does not exist");
            }
        }

        public void generateBody(StringTemplate bodyST) throws Exception {
            bodyST.setAttribute("name", name);
            bodyST.setAttribute("dir", dirFile);
            /*
            String about = ContentService.getAbout(type);
            if ( about!=null ) {
                bodyST.setAttribute("about",
                                    new StringTemplate(LimeApplication.stringTemplatesLib,
                                                       about));
            }
            */
            File[] filesArray = dirFile.listFiles();
            List files = Utils.toArrayList(filesArray);
            if ( files!=null ) {
                bodyST.setAttribute("files", files);
            }
        }

        public String getTitle() { return "Files in directory "+name; }
    }

    public static class ReloadDataPage extends MiscMachinePage {
        public void generateBody(StreamBuffer out) throws Exception {
            ContentService.reload();
            out.println("Data reloaded...");
        }

        public String getTitle() { return "Reload Data"; }
    }

}
