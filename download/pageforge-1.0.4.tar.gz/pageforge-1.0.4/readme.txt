The PageForge

Version 1.0.4
March 23, 2004

(c) 2003-2004 Terence Parr, jGuru.com [terence@parr.us]

ABSTRACT

The "PageForge" contains the essence of what I learned building
jGuru.com.  The main component is a state machine and string template
mechanism for pumping out web pages where separation of code and data
is strictly enforced (e.g., making multiple "skins" for a website is
trivial).  If you have used jGuru you know that pageforge is very
fast.

I have also dumped in a bunch of other really useful pieces of code,
some of which are meant as examples rather than as directly usable
objects.

This library is the core of the following websites:

http://www.jguru.com
http://www.knowspam.net
http://www.peerscope.com (source included here)
http://www.antlr.org (source included here)

I wanted to push this library out as soon as possible so documentation
is pretty much the code itself and the included samples sites at this
point.  You'll have to just dig around the code for now.  Sorry about
that.  I'll fix that later.  Note that I will have a forum/faq at
jGuru to "support" this software:

http://www.jguru.com/faq/PageForge

This software is available under the BSD license: "use it any way you
want; just don't sue me."

CONTENTS

Ok, here is a list of the major components

1. PageForge: org.pageforge.*

Contains the page state machine, session management (login/logout),
html utilities, sample pages, RSS reader/writer, useful services like
EmailService/LogService, and my own junit look-alike.

2. StringTemplate: org.antlr.stringtemplate.*

This thing kicks ass.  An amazingly useful template language.
Available separately from http://www.stringtemplate.org.

A StringTemplate is a "document" with holes in it where you can stick
values.  StringTemplate breaks up your template into chunks of text
and attribute expressions, which are by default enclosed in angle
brackets: <attribute-expression>.  StringTemplate ignores everything
outside of attribute expressions, treating it as just text to spit out
when you call StringTemplate.toString().

StringTemplate is not a "system" or "engine" or "server"; it's a
library with two classes of interest: StringTemplate and
StringTemplateGroup.  You can directly create a StringTemplate in Java
code or you can load a template from a file.

Don't forget to look at the TestStringTemplate class to see a bunch of
examples.

3. Site: antlr.org

Source and some sample data for antlr.org website

4. Site: peerscope.com

Source for all of peerscope.com except for the jguru peerscope part
(it needs to ask jGuru for its peerscope data).  So, this site is
mainly available to you as a big example use of pageforge.

BINARIES

All .java files and .class files are tar'd up with this distribution.
If you want a jar of the components, you can make one really quick. ;)

DEPENDENCIES

To make all this stuff work, you need lots of other libraries
unfortunately.  I didn't want to include them all as I might violate a
redistribution license.  Sorry.

1. PageForge

A web server like resin (http://www.caucho.com).  jsdk23.jar,
stringtemplate (included), antlr 2.7.2 and beyond
(http://www.antlr.org)

2. StringTemplate (included)

3. Site: antlr.org

A web server like resin stringtemplate, antlr 2.7.2, pageforge,
jsdk23, tml (included in antlr.org/lib/jars), commons-fileupload
(http://jakarta.apache.org/commons/sandbox/fileupload/)

4. Site: peerscope.com

A web server like resin JDBC driver from your database vendor, lucene
search engine (http://jakarta.apache.org/lucene/docs/index.html),
jsdk23, antlr 2.7.2, stringtemplate, pageforge, jguru (you don't have
the source to this).

CREDITS

Tom Burns, CEO of jGuru.com, contributed significant intellectual
effort to jGuru and the other sites.  He and I discussed and refined
the ideas in pageforge and stringtemplate for years.  Many of the good
ideas are his. :)



